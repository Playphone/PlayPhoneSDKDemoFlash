//
//  MNCommon.m
//  MultiNet client
//
//  Created by Sergey Prokhorchuk on 6/4/09.
//  Copyright 2009 PlayPhone. All rights reserved.
//

#import "MNCommon.h"

NSString* MNClientAPIVersion = @"1_7_1";
