//
//  MNServerInfoProviderExtDelegate.h
//  MultiNet Extension Wrapper
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "MNServerInfoProvider.h"

#import "MNExtWrapperEventDispatcher.h"

@interface MNServerInfoProviderExtDelegate : NSObject<MNServerInfoProviderDelegate>

- (id)initWithDispatcher:(id<MNExtWrapperEventDispatcher>)eventDispatcher;
- (void)dealloc;

@end
