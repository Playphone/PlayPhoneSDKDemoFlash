//
//  MNScoreProgressProviderExtDelegate.h
//  MultiNet Extension Wrapper
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "MNScoreProgressProvider.h"

#import "MNExtWrapperEventDispatcher.h"

@interface MNScoreProgressProviderExtDelegate : NSObject<MNScoreProgressProviderDelegate>

- (id)initWithDispatcher:(id<MNExtWrapperEventDispatcher>)eventDispatcher;
- (void)dealloc;

@end
