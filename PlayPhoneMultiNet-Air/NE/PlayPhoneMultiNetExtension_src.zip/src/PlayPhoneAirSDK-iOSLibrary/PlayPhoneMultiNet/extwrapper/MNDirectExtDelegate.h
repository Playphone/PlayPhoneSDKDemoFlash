//
//  MNDirectExtDelegate.h
//  MultiNet Extension Wrapper
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "MNDirect.h"

#import "MNExtWrapperEventDispatcher.h"

@interface MNDirectExtDelegate : NSObject<MNDirectDelegate>

- (id)initWithDispatcher:(id<MNExtWrapperEventDispatcher>)eventDispatcher;
- (void)dealloc;

@end
