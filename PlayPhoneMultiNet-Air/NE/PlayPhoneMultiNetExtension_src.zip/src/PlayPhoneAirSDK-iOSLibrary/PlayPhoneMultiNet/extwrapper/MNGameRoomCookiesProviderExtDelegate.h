//
//  MNGameRoomCookiesProviderExtDelegate.h
//  MultiNet Extension Wrapper
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "MNGameRoomCookiesProvider.h"

#import "MNExtWrapperEventDispatcher.h"

@interface MNGameRoomCookiesProviderExtDelegate : NSObject<MNGameRoomCookiesProviderDelegate>

- (id)initWithDispatcher:(id<MNExtWrapperEventDispatcher>)eventDispatcher;
- (void)dealloc;

@end
