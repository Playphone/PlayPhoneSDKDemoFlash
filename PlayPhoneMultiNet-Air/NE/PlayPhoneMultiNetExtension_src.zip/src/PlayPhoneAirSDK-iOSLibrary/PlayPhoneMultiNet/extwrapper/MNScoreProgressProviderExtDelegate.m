//
//  MNScoreProgressProviderExtDelegate.m
//  MultiNet Extension Wrapper
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "MNExtWrapperDefs.h"
#import "MNScoreProgressProviderExtDelegate.h"


@interface MNScoreProgressProviderExtDelegate()
@property (nonatomic,retain) id<MNExtWrapperEventDispatcher> eventDispatcher;
@end

@implementation MNScoreProgressProviderExtDelegate
@synthesize eventDispatcher = _eventDispatcher;

- (id)initWithDispatcher:(id<MNExtWrapperEventDispatcher>)eventDispatcher
 {
  if (self = [super init])
   {
    self.eventDispatcher = eventDispatcher;
   }
  
  return self;
 }

- (void)dealloc
 {
  self.eventDispatcher = nil;

  [super dealloc];
 }

- (void)scoresUpdated:(NSArray*)scoreBoard
 {
  MARK;
  NSArray *paramsArray     = [NSArray arrayWithObjects:(scoreBoard == nil ? [NSNull null] : scoreBoard),nil];
  NSArray *paramNamesArray = [NSArray arrayWithObjects:@"scoreBoard",nil];

  [self.eventDispatcher dispatchEvent:@"onScoresUpdated" withParams:paramsArray andParamsNames:paramNamesArray];
 }

@end
