//
//  MNDirectExtDelegate.m
//  MultiNet Extension Wrapper
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "MNExtWrapperDefs.h"
#import "MNDirectExtDelegate.h"


@interface MNDirectExtDelegate()
@property (nonatomic,retain) id<MNExtWrapperEventDispatcher> eventDispatcher;
@end

@implementation MNDirectExtDelegate
@synthesize eventDispatcher = _eventDispatcher;

- (id)initWithDispatcher:(id<MNExtWrapperEventDispatcher>)eventDispatcher
 {
  if (self = [super init])
   {
    self.eventDispatcher = eventDispatcher;
   }
  
  return self;
 }

- (void)dealloc
 {
  self.eventDispatcher = nil;

  [super dealloc];
 }

- (void)mnDirectDoStartGameWithParams:(MNGameParams*)params
 {
  MARK;
  NSArray *paramsArray     = [NSArray arrayWithObjects:(params == nil ? [NSNull null] : params),nil];
  NSArray *paramNamesArray = [NSArray arrayWithObjects:@"params",nil];

  [self.eventDispatcher dispatchEvent:@"mnDirectDoStartGameWithParams" withParams:paramsArray andParamsNames:paramNamesArray];
 }

- (void)mnDirectDoFinishGame
 {
  MARK;
  [self.eventDispatcher dispatchEvent:@"mnDirectDoFinishGame" withParams:nil andParamsNames:nil];
 }

- (void)mnDirectDoCancelGame
 {
  MARK;
  [self.eventDispatcher dispatchEvent:@"mnDirectDoCancelGame" withParams:nil andParamsNames:nil];
 }

- (void)mnDirectViewDoGoBack
 {
  MARK;
  [self.eventDispatcher dispatchEvent:@"mnDirectViewDoGoBack" withParams:nil andParamsNames:nil];
 }

- (void)mnDirectDidReceiveGameMessage:(NSString*)message from:(MNUserInfo*)sender
 {
  MARK;
  NSArray *paramsArray     = [NSArray arrayWithObjects:(message == nil ? [NSNull null] : message),(sender == nil ? [NSNull null] : sender),nil];
  NSArray *paramNamesArray = [NSArray arrayWithObjects:@"message",@"sender",nil];

  [self.eventDispatcher dispatchEvent:@"mnDirectDidReceiveGameMessage" withParams:paramsArray andParamsNames:paramNamesArray];
 }

- (void)mnDirectSessionStatusChangedTo:(NSUInteger)newStatus
 {
  MARK;
  NSArray *paramsArray     = [NSArray arrayWithObjects:[NSNumber numberWithUnsignedInteger:newStatus],nil];
  NSArray *paramNamesArray = [NSArray arrayWithObjects:@"newStatus",nil];

  [self.eventDispatcher dispatchEvent:@"mnDirectSessionStatusChanged" withParams:paramsArray andParamsNames:paramNamesArray];
 }

- (void)mnDirectErrorOccurred:(MNErrorInfo*)error
 {
  MARK;
  NSArray *paramsArray     = [NSArray arrayWithObjects:(error == nil ? [NSNull null] : error),nil];
  NSArray *paramNamesArray = [NSArray arrayWithObjects:@"error",nil];

  [self.eventDispatcher dispatchEvent:@"mnDirectErrorOccurred" withParams:paramsArray andParamsNames:paramNamesArray];
 }

- (void)mnDirectSessionReady:(MNSession*)session
 {
  MARK;
  [self.eventDispatcher dispatchEvent:@"mnDirectSessionReady" withParams:nil andParamsNames:nil];
 }

@end
