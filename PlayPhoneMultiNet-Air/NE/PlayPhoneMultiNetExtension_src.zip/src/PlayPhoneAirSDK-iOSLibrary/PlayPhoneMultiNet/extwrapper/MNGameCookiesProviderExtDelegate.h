//
//  MNGameCookiesProviderExtDelegate.h
//  MultiNet Extension Wrapper
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "MNGameCookiesProvider.h"

#import "MNExtWrapperEventDispatcher.h"

@interface MNGameCookiesProviderExtDelegate : NSObject<MNGameCookiesProviderDelegate>

- (id)initWithDispatcher:(id<MNExtWrapperEventDispatcher>)eventDispatcher;
- (void)dealloc;

@end
