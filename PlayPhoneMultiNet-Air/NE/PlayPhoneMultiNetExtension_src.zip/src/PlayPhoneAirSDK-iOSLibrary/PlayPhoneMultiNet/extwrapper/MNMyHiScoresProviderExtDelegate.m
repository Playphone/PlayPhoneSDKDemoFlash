//
//  MNMyHiScoresProviderExtDelegate.m
//  MultiNet Extension Wrapper
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "MNExtWrapperDefs.h"
#import "MNMyHiScoresProviderExtDelegate.h"


@interface MNMyHiScoresProviderExtDelegate()
@property (nonatomic,retain) id<MNExtWrapperEventDispatcher> eventDispatcher;
@end

@implementation MNMyHiScoresProviderExtDelegate
@synthesize eventDispatcher = _eventDispatcher;

- (id)initWithDispatcher:(id<MNExtWrapperEventDispatcher>)eventDispatcher
 {
  if (self = [super init])
   {
    self.eventDispatcher = eventDispatcher;
   }
  
  return self;
 }

- (void)dealloc
 {
  self.eventDispatcher = nil;

  [super dealloc];
 }

- (void)hiScoreUpdated:(long long)newScore gameSetId:(int)gameSetId periodMask:(unsigned int)periodMask
 {
  MARK;
  NSArray *paramsArray     = [NSArray arrayWithObjects:[NSNumber numberWithLong:newScore],[NSNumber numberWithInt:gameSetId],[NSNumber numberWithInt:periodMask],nil];
  NSArray *paramNamesArray = [NSArray arrayWithObjects:@"newScore",@"gameSetId",@"periodMask",nil];

  [self.eventDispatcher dispatchEvent:@"onNewHiScore" withParams:paramsArray andParamsNames:paramNamesArray];
 }

@end
