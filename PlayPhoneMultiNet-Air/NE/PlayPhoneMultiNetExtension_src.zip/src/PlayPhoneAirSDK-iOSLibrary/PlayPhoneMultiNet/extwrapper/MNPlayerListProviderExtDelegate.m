//
//  MNPlayerListProviderExtDelegate.m
//  MultiNet Extension Wrapper
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "MNExtWrapperDefs.h"
#import "MNPlayerListProviderExtDelegate.h"


@interface MNPlayerListProviderExtDelegate()
@property (nonatomic,retain) id<MNExtWrapperEventDispatcher> eventDispatcher;
@end

@implementation MNPlayerListProviderExtDelegate
@synthesize eventDispatcher = _eventDispatcher;

- (id)initWithDispatcher:(id<MNExtWrapperEventDispatcher>)eventDispatcher
 {
  if (self = [super init])
   {
    self.eventDispatcher = eventDispatcher;
   }
  
  return self;
 }

- (void)dealloc
 {
  self.eventDispatcher = nil;

  [super dealloc];
 }

- (void)onPlayerJoin:(MNUserInfo*)player
 {
  MARK;
  NSArray *paramsArray     = [NSArray arrayWithObjects:(player == nil ? [NSNull null] : player),nil];
  NSArray *paramNamesArray = [NSArray arrayWithObjects:@"player",nil];

  [self.eventDispatcher dispatchEvent:@"onPlayerJoin" withParams:paramsArray andParamsNames:paramNamesArray];
 }

- (void)onPlayerLeft:(MNUserInfo*)player
 {
  MARK;
  NSArray *paramsArray     = [NSArray arrayWithObjects:(player == nil ? [NSNull null] : player),nil];
  NSArray *paramNamesArray = [NSArray arrayWithObjects:@"player",nil];

  [self.eventDispatcher dispatchEvent:@"onPlayerLeft" withParams:paramsArray andParamsNames:paramNamesArray];
 }

@end
