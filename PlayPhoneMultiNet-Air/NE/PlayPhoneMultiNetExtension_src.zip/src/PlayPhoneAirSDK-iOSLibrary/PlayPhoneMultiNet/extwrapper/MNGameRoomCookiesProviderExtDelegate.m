//
//  MNGameRoomCookiesProviderExtDelegate.m
//  MultiNet Extension Wrapper
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "MNExtWrapperDefs.h"
#import "MNGameRoomCookiesProviderExtDelegate.h"


@interface MNGameRoomCookiesProviderExtDelegate()
@property (nonatomic,retain) id<MNExtWrapperEventDispatcher> eventDispatcher;
@end

@implementation MNGameRoomCookiesProviderExtDelegate
@synthesize eventDispatcher = _eventDispatcher;

- (id)initWithDispatcher:(id<MNExtWrapperEventDispatcher>)eventDispatcher
 {
  if (self = [super init])
   {
    self.eventDispatcher = eventDispatcher;
   }
  
  return self;
 }

- (void)dealloc
 {
  self.eventDispatcher = nil;

  [super dealloc];
 }

- (void)gameRoomCookieForRoom:(int)roomSFId withKey:(int)key downloadSucceeded:(NSString*)cookie
 {
  MARK;
  NSArray *paramsArray     = [NSArray arrayWithObjects:[NSNumber numberWithInt:roomSFId],[NSNumber numberWithInt:key],(cookie == nil ? [NSNull null] : cookie),nil];
  NSArray *paramNamesArray = [NSArray arrayWithObjects:@"roomSFId",@"key",@"cookie",nil];

  [self.eventDispatcher dispatchEvent:@"onGameRoomCookieDownloadSucceeded" withParams:paramsArray andParamsNames:paramNamesArray];
 }

- (void)gameRoomCookieForRoom:(int)roomSFId withKey:(int)key downloadFailedWithError:(NSString*)error
 {
  MARK;
  NSArray *paramsArray     = [NSArray arrayWithObjects:[NSNumber numberWithInt:roomSFId],[NSNumber numberWithInt:key],(error == nil ? [NSNull null] : error),nil];
  NSArray *paramNamesArray = [NSArray arrayWithObjects:@"roomSFId",@"key",@"error",nil];

  [self.eventDispatcher dispatchEvent:@"onGameRoomCookieDownloadFailedWithError" withParams:paramsArray andParamsNames:paramNamesArray];
 }


@end
