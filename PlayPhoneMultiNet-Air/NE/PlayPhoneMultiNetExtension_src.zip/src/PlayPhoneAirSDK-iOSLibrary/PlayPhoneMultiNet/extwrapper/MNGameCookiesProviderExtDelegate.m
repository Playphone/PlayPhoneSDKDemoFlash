//
//  MNGameCookiesProviderExtDelegate.m
//  MultiNet Extension Wrapper
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "MNExtWrapperDefs.h"
#import "MNGameCookiesProviderExtDelegate.h"


@interface MNGameCookiesProviderExtDelegate()
@property (nonatomic,retain) id<MNExtWrapperEventDispatcher> eventDispatcher;
@end

@implementation MNGameCookiesProviderExtDelegate
@synthesize eventDispatcher = _eventDispatcher;

- (id)initWithDispatcher:(id<MNExtWrapperEventDispatcher>)eventDispatcher
 {
  if (self = [super init])
   {
    self.eventDispatcher = eventDispatcher;
   }
  
  return self;
 }

- (void)dealloc
 {
  self.eventDispatcher = nil;

  [super dealloc];
 }

- (void)gameCookie:(int)key downloadSucceeded:(NSString*)cookie
 {
  MARK;
  NSArray *paramsArray     = [NSArray arrayWithObjects:[NSNumber numberWithInt:key],(cookie == nil ? [NSNull null] : cookie),nil];
  NSArray *paramNamesArray = [NSArray arrayWithObjects:@"key",@"cookie",nil];

  [self.eventDispatcher dispatchEvent:@"onGameCookieDownloadSucceeded" withParams:paramsArray andParamsNames:paramNamesArray];
 }

- (void)gameCookie:(int)key downloadFailedWithError:(NSString*)error
 {
  MARK;
  NSArray *paramsArray     = [NSArray arrayWithObjects:[NSNumber numberWithInt:key],(error == nil ? [NSNull null] : error),nil];
  NSArray *paramNamesArray = [NSArray arrayWithObjects:@"key",@"error",nil];

  [self.eventDispatcher dispatchEvent:@"onGameCookieDownloadFailedWithError" withParams:paramsArray andParamsNames:paramNamesArray];
 }

- (void)onGameCookieUploadSucceeded:(int)key
 {
  MARK;
  NSArray *paramsArray     = [NSArray arrayWithObjects:[NSNumber numberWithInt:key],nil];
  NSArray *paramNamesArray = [NSArray arrayWithObjects:@"key",nil];

  [self.eventDispatcher dispatchEvent:@"onGameCookieUploadSucceeded" withParams:paramsArray andParamsNames:paramNamesArray];
 }

- (void)gameCookie:(int)key uploadFailedWithError:(NSString*)error
 {
  MARK;
  NSArray *paramsArray     = [NSArray arrayWithObjects:[NSNumber numberWithInt:key],(error == nil ? [NSNull null] : error),nil];
  NSArray *paramNamesArray = [NSArray arrayWithObjects:@"key",@"error",nil];

  [self.eventDispatcher dispatchEvent:@"onGameCookieUploadFailedWithError" withParams:paramsArray andParamsNames:paramNamesArray];
 }

@end
