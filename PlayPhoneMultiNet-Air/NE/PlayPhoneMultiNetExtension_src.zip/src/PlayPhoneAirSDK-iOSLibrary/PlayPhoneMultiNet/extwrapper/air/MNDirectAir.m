//
//  MNDirectAir.m
//  MultiNet Extension Wrapper Air
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "FlashRuntimeExtensions.h"
#import "MNExtWrapperDefs.h"
#import "MNExtWrapperAir.h"
#import "MNFRETools.h"

#import "MNDirect.h"

#import "MNExtWrapperEventDispatcherAir.h"
#import "MNDirectExtDelegate.h"


EXTERN_C FREObject MNDirect_init(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int gameId;
  NSString* gameSecret;

  if (argc >= 2)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&gameId)];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&gameSecret withType:[NSString class] fromFREObject:argv[1]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [MNExtWrapperEventDispatcherAir shared].freContext = ctx;

  MNDirectExtDelegate *mnDirectDelegate = [[MNDirectExtDelegate alloc]initWithDispatcher:[MNExtWrapperEventDispatcherAir shared]];

  [MNDirect prepareSessionWithGameId:gameId gameSecret:gameSecret andDelegate:mnDirectDelegate];

  return NULL;
 }

EXTERN_C FREObject MNDirect_makeGameSecretByComponents(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int secret1;
  int secret2;
  int secret3;
  int secret4;

  if (argc >= 4)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&secret1)];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[1],&secret2)];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[2],&secret3)];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[3],&secret4)];
   }

  if (!argResult)
   {
    return NULL;
   }

  NSString* result;
  result = [MNDirect makeGameSecretByComponents:secret1 secret2:secret2 secret3:secret3 secret4:secret4];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from NSString");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNDirect_shutdownSession(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  [MNDirect shutdownSession];

  return NULL;
 }

EXTERN_C FREObject MNDirect_isOnline(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [MNDirect isOnline];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNDirect_isUserLoggedIn(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [MNDirect isUserLoggedIn];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNDirect_getSessionStatus(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  int result;
  result = [MNDirect getSessionStatus];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromInt(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from int");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNDirect_postGameScore(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  long long score;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsLongLong(argv[0],&score)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [MNDirect postGameScore:score];

  return NULL;
 }

EXTERN_C FREObject MNDirect_postGameScorePending(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  long long score;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsLongLong(argv[0],&score)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [MNDirect postGameScorePending:score];

  return NULL;
 }

EXTERN_C FREObject MNDirect_cancelGame(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  [MNDirect cancelGame];

  return NULL;
 }

EXTERN_C FREObject MNDirect_setDefaultGameSetId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int gameSetId;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&gameSetId)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [MNDirect setDefaultGameSetId:gameSetId];

  return NULL;
 }

EXTERN_C FREObject MNDirect_getDefaultGameSetId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  int result;
  result = [MNDirect getDefaultGameSetId];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromInt(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from int");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNDirect_sendAppBeacon(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSString* actionName;
  NSString* beaconData;

  if (argc >= 2)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&actionName withType:[NSString class] fromFREObject:argv[0]]];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&beaconData withType:[NSString class] fromFREObject:argv[1]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [MNDirect sendAppBeacon:actionName beaconData:beaconData];

  return NULL;
 }

EXTERN_C FREObject MNDirect_execAppCommand(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSString* name;
  NSString* param;

  if (argc >= 2)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&name withType:[NSString class] fromFREObject:argv[0]]];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&param withType:[NSString class] fromFREObject:argv[1]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [MNDirect execAppCommand:name withParam:param];

  return NULL;
 }

EXTERN_C FREObject MNDirect_sendGameMessage(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSString* message;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&message withType:[NSString class] fromFREObject:argv[0]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [MNDirect sendGameMessage:message];

  return NULL;
 }

