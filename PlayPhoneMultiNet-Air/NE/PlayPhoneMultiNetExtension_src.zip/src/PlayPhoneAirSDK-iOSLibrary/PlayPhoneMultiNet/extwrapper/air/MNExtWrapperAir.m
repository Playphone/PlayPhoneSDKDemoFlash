//
//  MNExtWrapperAir.m
//  MultiNet Extension Wrapper Air
//
//  Created by Vladislav Ogol on 30.07.12.
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "MNExtWrapperAir.h"

static MNFRETools *MNExtWrapperFREToolsShared = nil;

@implementation MNExtWrapperAir

+ (MNFRETools*)freTools
 {
  if (MNExtWrapperFREToolsShared == nil)
   {
    MNExtWrapperFREToolsShared  =[[MNFRETools alloc]init];
   }
  
  return MNExtWrapperFREToolsShared;
 }

@end
