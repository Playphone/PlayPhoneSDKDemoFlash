//
//  MNFRETools.h
//  MultiNet Extension Wrapper Air
//
//  Created by Vladislav Ogol on 04.07.12.
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//
#import "MNExtWrapperDefs.h"
#import "FlashRuntimeExtensions.h"


@interface MNFRETools : NSObject
- (FREResult)getObject:(id*)value withType:(Class)objectType fromFREObject:(FREObject)freObject;
- (FREResult)getArray:(NSArray**)array withElementTypeEncode:(const char*)elementEncode fromFREObject:(FREObject)freArray;
- (FREResult)getArray:(NSArray**)array withElementTypeClass:(Class)elementType fromFREObject:(FREObject)freArray;
- (FREResult)getDictionary:(NSDictionary**) dictonary withKeyType:(Class)keyType valueType:(Class)valueType fromFREObject:(FREObject)freDictionary;

- (FREResult)getFREObject:(FREObject*) freObject fromObject:(id)object;
@end


@interface MNFREResult : NSObject

@property (nonatomic,assign) NSUInteger totalStepNumber;
@property (nonatomic,assign) NSUInteger failedStepNumber;
@property (nonatomic,assign) FREResult  freResult;

+ (MNFREResult*)result;

- (id)init;
- (void)dealloc;

- (BOOL)collectResult:(FREResult)freResult;
- (BOOL)isResultOk;
@end


EXTERN_C FREResult MNFREGetObjectAsInt       (FREObject freObject,int          *value);
EXTERN_C FREResult MNFREGetObjectAsUInt      (FREObject freObject,unsigned int *value);
EXTERN_C FREResult MNFREGetObjectAsDouble    (FREObject freObject,double       *value);
EXTERN_C FREResult MNFREGetObjectAsBOOL      (FREObject freObject,BOOL         *value);
EXTERN_C FREResult MNFREGetObjectAsLongLong  (FREObject freObject,long long    *value);

EXTERN_C FREResult MNFRENewObjectFromInt     (int          value,FREObject *freObject);
EXTERN_C FREResult MNFRENewObjectFromUInt    (unsigned int value,FREObject *freObject);
EXTERN_C FREResult MNFRENewObjectFromDouble  (double       value,FREObject *freObject);
EXTERN_C FREResult MNFRENewObjectFromBOOL    (BOOL         value,FREObject *freObject);
EXTERN_C FREResult MNFRENewObjectFromLongLong(long long    value,FREObject *freObject);

EXTERN_C NSString* FREResultToString(FREResult freResult);

