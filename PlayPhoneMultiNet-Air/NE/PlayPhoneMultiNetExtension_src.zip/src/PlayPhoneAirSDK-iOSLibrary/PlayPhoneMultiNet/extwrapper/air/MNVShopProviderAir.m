//
//  MNVShopProviderAir.m
//  MultiNet Extension Wrapper Air
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "FlashRuntimeExtensions.h"
#import "MNExtWrapperDefs.h"
#import "MNExtWrapperAir.h"
#import "MNFRETools.h"

#import "MNDirect.h"
#import "MNVShopProvider.h"

#import "MNExtWrapperEventDispatcherAir.h"
#import "MNVShopProviderExtDelegate.h"


EXTERN_C FREObject MNVShopProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  return NULL;
 }

EXTERN_C FREObject MNVShopProvider_getVShopPackList(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  NSArray *result;
  result = [[MNDirect vShopProvider] getVShopPackList];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from MNVShopPackInfo[]");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNVShopProvider_getVShopCategoryList(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  NSArray *result;
  result = [[MNDirect vShopProvider] getVShopCategoryList];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from MNVShopCategoryInfo[]");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNVShopProvider_findVShopPackById(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int _id;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&_id)];
   }

  if (!argResult)
   {
    return NULL;
   }

  MNVShopPackInfo* result;
  result = [[MNDirect vShopProvider] findVShopPackById:_id];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from MNVShopPackInfo");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNVShopProvider_findVShopCategoryById(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int _id;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&_id)];
   }

  if (!argResult)
   {
    return NULL;
   }

  MNVShopCategoryInfo* result;
  result = [[MNDirect vShopProvider] findVShopCategoryById:_id];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from MNVShopCategoryInfo");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNVShopProvider_isVShopInfoNeedUpdate(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [[MNDirect vShopProvider] isVShopInfoNeedUpdate];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNVShopProvider_doVShopInfoUpdate(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  [[MNDirect vShopProvider] doVShopInfoUpdate];

  return NULL;
 }

EXTERN_C FREObject MNVShopProvider_getVShopPackImageURL(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int packId;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&packId)];
   }

  if (!argResult)
   {
    return NULL;
   }

  NSString* result;
  result = [[[MNDirect vShopProvider] getVShopPackImageURL:packId]absoluteString];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from NSString");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNVShopProvider_execCheckoutVShopPacks(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSArray *packIdArray;
  NSArray *packCountArray;
  long long clientTransactionId;

  if (argc >= 3)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getArray:&packIdArray withElementTypeEncode:@encode(int) fromFREObject:argv[0]]];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getArray:&packCountArray withElementTypeEncode:@encode(int) fromFREObject:argv[1]]];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsLongLong(argv[2],&clientTransactionId)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect vShopProvider] execCheckoutVShopPacks:packIdArray packCount:packCountArray clientTransactionId:clientTransactionId];

  return NULL;
 }

EXTERN_C FREObject MNVShopProvider_procCheckoutVShopPacksSilent(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSArray *packIdArray;
  NSArray *packCountArray;
  long long clientTransactionId;

  if (argc >= 3)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getArray:&packIdArray withElementTypeEncode:@encode(int) fromFREObject:argv[0]]];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getArray:&packCountArray withElementTypeEncode:@encode(int) fromFREObject:argv[1]]];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsLongLong(argv[2],&clientTransactionId)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect vShopProvider] procCheckoutVShopPacksSilent:packIdArray packCount:packCountArray clientTransactionId:clientTransactionId];

  return NULL;
 }

EXTERN_C FREObject MNVShopProvider_isVShopReady(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [[MNDirect vShopProvider] isVShopReady];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

static BOOL eventHandlerAdded = NO;

EXTERN_C FREObject MNVShopProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  if (!eventHandlerAdded)
   {
    eventHandlerAdded = YES;
    [[MNDirect vShopProvider] addDelegate:[[MNVShopProviderExtDelegate alloc]initWithDispatcher:[MNExtWrapperEventDispatcherAir shared]]];
   }

  return NULL;
 }

