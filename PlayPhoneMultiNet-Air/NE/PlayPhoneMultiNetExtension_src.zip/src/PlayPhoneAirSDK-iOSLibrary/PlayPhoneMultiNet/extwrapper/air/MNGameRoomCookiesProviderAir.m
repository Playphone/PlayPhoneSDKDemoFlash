//
//  MNGameRoomCookiesProviderAir.m
//  MultiNet Extension Wrapper Air
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "FlashRuntimeExtensions.h"
#import "MNExtWrapperDefs.h"
#import "MNExtWrapperAir.h"
#import "MNFRETools.h"

#import "MNDirect.h"
#import "MNGameRoomCookiesProvider.h"

#import "MNExtWrapperEventDispatcherAir.h"
#import "MNGameRoomCookiesProviderExtDelegate.h"


EXTERN_C FREObject MNGameRoomCookiesProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  return NULL;
 }

EXTERN_C FREObject MNGameRoomCookiesProvider_downloadGameRoomCookie(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int roomSFId;
  int key;

  if (argc >= 2)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&roomSFId)];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[1],&key)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect gameRoomCookiesProvider] downloadGameRoomCookieForRoom:roomSFId withKey:key];

  return NULL;
 }

EXTERN_C FREObject MNGameRoomCookiesProvider_setCurrentGameRoomCookie(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int key;
  NSString* cookie;

  if (argc >= 2)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&key)];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&cookie withType:[NSString class] fromFREObject:argv[1]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect gameRoomCookiesProvider] setCurrentGameRoomCookieWithKey:key andCookie:cookie];

  return NULL;
 }

EXTERN_C FREObject MNGameRoomCookiesProvider_getCurrentGameRoomCookie(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int key;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&key)];
   }

  if (!argResult)
   {
    return NULL;
   }

  NSString* result;
  result = [[MNDirect gameRoomCookiesProvider] currentGameRoomCookieWithKey:key];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from NSString");
   }

  return freObjectResult;
 }

static BOOL eventHandlerAdded = NO;

EXTERN_C FREObject MNGameRoomCookiesProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  if (!eventHandlerAdded)
   {
    eventHandlerAdded = YES;
    [[MNDirect gameRoomCookiesProvider] addDelegate:[[MNGameRoomCookiesProviderExtDelegate alloc]initWithDispatcher:[MNExtWrapperEventDispatcherAir shared]]];
   }

  return NULL;
 }

