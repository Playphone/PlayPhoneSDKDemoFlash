//
//  MNAchievementsProviderAir.m
//  MultiNet Extension Wrapper Air
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "FlashRuntimeExtensions.h"
#import "MNExtWrapperDefs.h"
#import "MNExtWrapperAir.h"
#import "MNFRETools.h"

#import "MNDirect.h"
#import "MNAchievementsProvider.h"

#import "MNExtWrapperEventDispatcherAir.h"
#import "MNAchievementsProviderExtDelegate.h"


EXTERN_C FREObject MNAchievementsProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  return NULL;
 }

EXTERN_C FREObject MNAchievementsProvider_getGameAchievementsList(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  NSArray *result;
  result = [[MNDirect achievementsProvider] getGameAchievementList];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from MNGameAchievementInfo[]");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNAchievementsProvider_findGameAchievementById(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int _id;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&_id)];
   }

  if (!argResult)
   {
    return NULL;
   }

  MNGameAchievementInfo* result;
  result = [[MNDirect achievementsProvider] findGameAchievementById:_id];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from MNGameAchievementInfo");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNAchievementsProvider_isGameAchievementListNeedUpdate(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [[MNDirect achievementsProvider] isGameAchievementListNeedUpdate];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNAchievementsProvider_doGameAchievementListUpdate(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  [[MNDirect achievementsProvider] doGameAchievementListUpdate];

  return NULL;
 }

EXTERN_C FREObject MNAchievementsProvider_isPlayerAchievementUnlocked(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int _id;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&_id)];
   }

  if (!argResult)
   {
    return NULL;
   }

  BOOL result;
  result = [[MNDirect achievementsProvider] isPlayerAchievementUnlocked:_id];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNAchievementsProvider_unlockPlayerAchievement(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int _id;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&_id)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect achievementsProvider] unlockPlayerAchievement:_id];

  return NULL;
 }

EXTERN_C FREObject MNAchievementsProvider_getPlayerAchievementsList(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  NSArray *result;
  result = [[MNDirect achievementsProvider] getPlayerAchievementList];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from PlayerAchievementInfo[]");
   }

  return freObjectResult;
 }

static BOOL eventHandlerAdded = NO;

EXTERN_C FREObject MNAchievementsProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  if (!eventHandlerAdded)
   {
    eventHandlerAdded = YES;
    [[MNDirect achievementsProvider] addDelegate:[[MNAchievementsProviderExtDelegate alloc]initWithDispatcher:[MNExtWrapperEventDispatcherAir shared]]];
   }

  return NULL;
 }

EXTERN_C FREObject MNAchievementsProvider_getAchievementImageURL(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int _id;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&_id)];
   }

  if (!argResult)
   {
    return NULL;
   }

  NSString* result;
  result = [[[MNDirect achievementsProvider] getAchievementImageURL:_id]absoluteString];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from NSString");
   }

  return freObjectResult;
 }

