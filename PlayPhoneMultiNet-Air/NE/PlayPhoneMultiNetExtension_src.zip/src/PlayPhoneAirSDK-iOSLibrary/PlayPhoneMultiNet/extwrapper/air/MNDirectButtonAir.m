//
//  MNDirectButtonAir.m
//  MultiNet Extension Wrapper Air
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "FlashRuntimeExtensions.h"
#import "MNExtWrapperDefs.h"
#import "MNExtWrapperAir.h"
#import "MNFRETools.h"

#import "MNDirect.h"
#import "MNDirectButton.h"


EXTERN_C FREObject MNDirectButton_isVisible(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [MNDirectButton isVisible];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNDirectButton_isHidden(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [MNDirectButton isHidden];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNDirectButton_initWithLocation(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int location;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&location)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [MNDirectButton initWithLocation:location];

  return NULL;
 }

EXTERN_C FREObject MNDirectButton_show(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  [MNDirectButton show];

  return NULL;
 }

EXTERN_C FREObject MNDirectButton_hide(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  [MNDirectButton hide];

  return NULL;
 }

EXTERN_C FREObject MNDirectButton_setVShopEventAutoHandleEnabled(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  BOOL isEnabled;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsBOOL(argv[0],&isEnabled)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [MNDirectButton setVShopEventAutoHandleEnabled:isEnabled];

  return NULL;
 }

