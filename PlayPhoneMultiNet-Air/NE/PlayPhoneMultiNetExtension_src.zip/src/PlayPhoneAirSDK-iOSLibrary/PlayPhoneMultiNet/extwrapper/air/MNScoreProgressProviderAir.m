//
//  MNScoreProgressProviderAir.m
//  MultiNet Extension Wrapper Air
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "FlashRuntimeExtensions.h"
#import "MNExtWrapperDefs.h"
#import "MNExtWrapperAir.h"
#import "MNFRETools.h"

#import "MNDirect.h"
#import "MNScoreProgressProvider.h"

#import "MNExtWrapperEventDispatcherAir.h"
#import "MNScoreProgressProviderExtDelegate.h"


EXTERN_C FREObject MNScoreProgressProvider_setRefreshIntervalAndUpdateDelay(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int refreshInterval;
  int updateDelay;

  if (argc >= 2)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&refreshInterval)];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[1],&updateDelay)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect scoreProgressProvider] setRefreshInterval:refreshInterval andUpdateDelay:updateDelay];

  return NULL;
 }

EXTERN_C FREObject MNScoreProgressProvider_start(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  [[MNDirect scoreProgressProvider] start];

  return NULL;
 }

EXTERN_C FREObject MNScoreProgressProvider_stop(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  [[MNDirect scoreProgressProvider] stop];

  return NULL;
 }

EXTERN_C FREObject MNScoreProgressProvider_postScore(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  long long score;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsLongLong(argv[0],&score)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect scoreProgressProvider] postScore:score];

  return NULL;
 }

#define MNScoreProgressProviderAirComparatorIdMoreIsBetter (1)
#define MNScoreProgressProviderAirComparatorIdLessIsBetter (2)

EXTERN_C FREObject MNScoreProgressProvider_setScoreComparator(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int comparatorId;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult: MNFREGetObjectAsInt(argv[0],&comparatorId)];
   }

  if (!argResult)
   {
    return NULL;
   }

  if (comparatorId == MNScoreProgressProviderAirComparatorIdMoreIsBetter)
   {
    [[MNDirect scoreProgressProvider] setScoreCompareFunc:MNScoreProgressProviderScoreCompareFuncMoreIsBetter withContext:NULL];
   }
  else if (comparatorId == MNScoreProgressProviderAirComparatorIdLessIsBetter)
   {
    [[MNDirect scoreProgressProvider] setScoreCompareFunc:MNScoreProgressProviderScoreCompareFuncLessIsBetter withContext:NULL];
   }
  else
   {
    ELog(@"Unknown comparator id");
   }

  return NULL;
 }

static BOOL eventHandlerAdded = NO;

EXTERN_C FREObject MNScoreProgressProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  if (!eventHandlerAdded)
   {
    eventHandlerAdded = YES;
    [[MNDirect scoreProgressProvider] addDelegate:[[MNScoreProgressProviderExtDelegate alloc]initWithDispatcher:[MNExtWrapperEventDispatcherAir shared]]];
   }

  return NULL;
 }

