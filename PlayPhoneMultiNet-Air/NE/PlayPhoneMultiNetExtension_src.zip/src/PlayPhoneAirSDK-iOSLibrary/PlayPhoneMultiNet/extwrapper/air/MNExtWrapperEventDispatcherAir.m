//
//  MNExtWrapperEventDispatcherAir.m
//  MultiNet Extension Wrapper Air
//
//  Created by Vladislav Ogol on 7/13/12.
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "MNExtWrapperDefs.h"
#import "MNExtWrapperCommon.h"

#import "MNExtWrapperEventDispatcherAir.h"

static MNExtWrapperEventDispatcherAir *MNExtWrapperEventDispatcherAirInstance = nil;

@implementation MNExtWrapperEventDispatcherAir
@synthesize freContext = _freContext;

+ (MNExtWrapperEventDispatcherAir*)shared
 {
  if (MNExtWrapperEventDispatcherAirInstance == nil)
   {
    MNExtWrapperEventDispatcherAirInstance = [[MNExtWrapperEventDispatcherAir alloc]init];
   }
  
  return MNExtWrapperEventDispatcherAirInstance;
 }

- (id)init {
  return [super init];
}

- (void)dealloc
 {
  [super dealloc];
 }

- (void)dispatchEvent:(NSString *)eventName withParams:(NSArray*) params andParamsNames:(NSArray*)paramNames
 {
  DLog(@"dispatchEvent:%@ withParams:%p andParamsNames:%p",eventName,params,paramNames);
  
  if ([eventName compare:@"MNWSInfoRequestEventHandler"] == NSOrderedSame)
   {
    eventName = @"onWSRequestReceived";
   }

  NSString *paramsPassString = nil;
  
  if ((params == nil) || ([params count] == 0))
   {
    paramsPassString = @""; 
   }
  else
   {
    NSMutableDictionary *paramsDict = [NSMutableDictionary dictionaryWithCapacity:[params count]];
    
    for (NSUInteger index = 0;index < [params count];index++)
     {
      NSString *key = nil;
      
      if ((paramNames == nil) || ([paramNames count] <= index))
       {
        key = [NSString stringWithFormat:@"UnnamedParam%d",index + 1];
       }
      else
       {
        key = [paramNames objectAtIndex:index];
       }
      
      [paramsDict setObject:[params objectAtIndex:index]
                     forKey:key];
     }
    
    paramsPassString = [[MNExtWrapperCommon serializer]serialize:paramsDict];
   }
  
  if (self.freContext == NULL)
   {
    ELog(@"Can not dispatch event. freContext == NULL");
   }
  else
   {
    FREDispatchStatusEventAsync(_freContext,(const uint8_t*)[eventName UTF8String],(const uint8_t*)[paramsPassString UTF8String]);
   }
 }

@end
