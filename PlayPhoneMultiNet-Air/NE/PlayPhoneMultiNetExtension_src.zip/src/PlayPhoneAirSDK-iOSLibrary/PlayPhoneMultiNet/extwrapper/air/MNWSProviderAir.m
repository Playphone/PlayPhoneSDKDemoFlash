//
//  MNExtWrapperAir.m
//  MultiNet Extension Wrapper Air
//
//  Created by Vladislav Ogol on 30.07.12.
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "FlashRuntimeExtensions.h"
#import "MNExtWrapperDefs.h"
#import "MNExtWrapperAir.h"
#import "MNFRETools.h"

#import "MNDirect.h"
#import "MNExtWrapperEventDispatcherAir.h"
#import "MNWSProviderExtWrapper.h"

static BOOL MNWSProviderExtWrapperIsInited = NO;

static void MNWSProviderExtWrapperSafeInit()
{
  if (!MNWSProviderExtWrapperIsInited)
   {
    MNWSProviderExtWrapperIsInited = YES;
    [MNWSProviderExtWrapper shared].eventDispatcher = [MNExtWrapperEventDispatcherAir shared];
   }
}

EXTERN_C FREObject MNWSProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  return NULL;
 }

EXTERN_C FREObject MNWSProvider_send(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  FREObject freObjectResult = NULL;
  MNFREResult *mnFREResult = [MNFREResult result];
  
  NSString *requestParamJsonArray;

  if (argc >= 1)
   {
    [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&requestParamJsonArray withType:[NSString class] fromFREObject:argv[0]]];
   }

  if ([mnFREResult isResultOk])
   {
    MNWSProviderExtWrapperSafeInit();
    NSInteger loaderId = [[MNWSProviderExtWrapper shared] sendRequest:requestParamJsonArray];

    [mnFREResult collectResult:MNFRENewObjectFromInt(loaderId,&freObjectResult)];
   }
  
  if (![mnFREResult isResultOk])
   {
    ELog(@"Send WS request error. FREResult = %@, failed step No: %d",
         FREResultToString([mnFREResult freResult]),
         [mnFREResult failedStepNumber]);
   }

  return freObjectResult;
 }


EXTERN_C FREObject MNWSProvider_cancel(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;
  
  MNFREResult *mnFREResult = [MNFREResult result];
  
  int loaderId;  
  
  if (argc >= 1)
   {
    [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&loaderId)];
   }
  
  if (![mnFREResult isResultOk])
   {
    return NULL;
   }
  
  MNWSProviderExtWrapperSafeInit();
  [[MNWSProviderExtWrapper shared] cancelRequest:loaderId];
  
  return NULL;
 }