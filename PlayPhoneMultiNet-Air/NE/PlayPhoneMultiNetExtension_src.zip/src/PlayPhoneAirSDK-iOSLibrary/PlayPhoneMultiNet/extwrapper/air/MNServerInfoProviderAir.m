//
//  MNServerInfoProviderAir.m
//  MultiNet Extension Wrapper Air
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "FlashRuntimeExtensions.h"
#import "MNExtWrapperDefs.h"
#import "MNExtWrapperAir.h"
#import "MNFRETools.h"

#import "MNDirect.h"
#import "MNServerInfoProvider.h"

#import "MNExtWrapperEventDispatcherAir.h"
#import "MNServerInfoProviderExtDelegate.h"


EXTERN_C FREObject MNServerInfoProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  return NULL;
 }

EXTERN_C FREObject MNServerInfoProvider_requestServerInfoItem(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int key;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&key)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect serverInfoProvider] requestServerInfoItem:key];

  return NULL;
 }

static BOOL eventHandlerAdded = NO;

EXTERN_C FREObject MNServerInfoProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  if (!eventHandlerAdded)
   {
    eventHandlerAdded = YES;
    [[MNDirect serverInfoProvider] addDelegate:[[MNServerInfoProviderExtDelegate alloc]initWithDispatcher:[MNExtWrapperEventDispatcherAir shared]]];
   }

  return NULL;
 }

