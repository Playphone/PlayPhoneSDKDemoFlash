//
//  MNVItemsProviderAir.m
//  MultiNet Extension Wrapper Air
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "FlashRuntimeExtensions.h"
#import "MNExtWrapperDefs.h"
#import "MNExtWrapperAir.h"
#import "MNFRETools.h"

#import "MNDirect.h"
#import "MNVItemsProvider.h"

#import "MNExtWrapperEventDispatcherAir.h"
#import "MNVItemsProviderExtDelegate.h"


EXTERN_C FREObject MNVItemsProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  return NULL;
 }

EXTERN_C FREObject MNVItemsProvider_getGameVItemsList(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  NSArray *result;
  result = [[MNDirect vItemsProvider] getGameVItemsList];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from MNGameVItemInfo[]");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNVItemsProvider_findGameVItemById(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int _id;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&_id)];
   }

  if (!argResult)
   {
    return NULL;
   }

  MNGameVItemInfo* result;
  result = [[MNDirect vItemsProvider] findGameVItemById:_id];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from MNGameVItemInfo");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNVItemsProvider_isGameVItemsListNeedUpdate(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [[MNDirect vItemsProvider] isGameVItemsListNeedUpdate];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNVItemsProvider_doGameVItemsListUpdate(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  [[MNDirect vItemsProvider] doGameVItemsListUpdate];

  return NULL;
 }

EXTERN_C FREObject MNVItemsProvider_reqAddPlayerVItem(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int vItemId;
  long long count;
  long long clientTransactionId;

  if (argc >= 3)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&vItemId)];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsLongLong(argv[1],&count)];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsLongLong(argv[2],&clientTransactionId)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect vItemsProvider] reqAddPlayerVItem:vItemId count:count andClientTransactionId:clientTransactionId];

  return NULL;
 }

EXTERN_C FREObject MNVItemsProvider_reqAddPlayerVItemTransaction(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSArray *transactionVItems;
  long long clientTransactionId;

  if (argc >= 2)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getArray:&transactionVItems withElementTypeClass:[MNTransactionVItemInfo class] fromFREObject:argv[0]]];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsLongLong(argv[1],&clientTransactionId)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect vItemsProvider] reqAddPlayerVItemTransaction:transactionVItems andClientTransactionId:clientTransactionId];

  return NULL;
 }

EXTERN_C FREObject MNVItemsProvider_reqTransferPlayerVItem(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int vItemId;
  long long count;
  long long toPlayerId;
  long long clientTransactionId;

  if (argc >= 4)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&vItemId)];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsLongLong(argv[1],&count)];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsLongLong(argv[2],&toPlayerId)];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsLongLong(argv[3],&clientTransactionId)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect vItemsProvider] reqTransferPlayerVItem:vItemId count:count toPlayer:toPlayerId andClientTransactionId:clientTransactionId];

  return NULL;
 }

EXTERN_C FREObject MNVItemsProvider_reqTransferPlayerVItemTransaction(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSArray *transactionVItems;
  long long toPlayerId;
  long long clientTransactionId;

  if (argc >= 3)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getArray:&transactionVItems withElementTypeClass:[MNTransactionVItemInfo class] fromFREObject:argv[0]]];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsLongLong(argv[1],&toPlayerId)];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsLongLong(argv[2],&clientTransactionId)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect vItemsProvider] reqTransferPlayerVItemTransaction:transactionVItems toPlayer:toPlayerId andClientTransactionId:clientTransactionId];

  return NULL;
 }

EXTERN_C FREObject MNVItemsProvider_getPlayerVItemList(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  NSArray *result;
  result = [[MNDirect vItemsProvider] getPlayerVItemList];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from MNPlayerVItemInfo[]");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNVItemsProvider_getPlayerVItemCountById(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int vItemId;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&vItemId)];
   }

  if (!argResult)
   {
    return NULL;
   }

  long long result;
  result = [[MNDirect vItemsProvider] getPlayerVItemCountById:vItemId];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromLongLong(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from long long");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNVItemsProvider_getVItemImageURL(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int vItemId;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&vItemId)];
   }

  if (!argResult)
   {
    return NULL;
   }

  NSString* result;
  result = [[[MNDirect vItemsProvider] getVItemImageURL:vItemId]absoluteString];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from NSString");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNVItemsProvider_getNewClientTransactionId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  long long result;
  result = [[MNDirect vItemsProvider] getNewClientTransactionId];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromLongLong(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from long long");
   }

  return freObjectResult;
 }

static BOOL eventHandlerAdded = NO;

EXTERN_C FREObject MNVItemsProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  if (!eventHandlerAdded)
   {
    eventHandlerAdded = YES;
    [[MNDirect vItemsProvider] addDelegate:[[MNVItemsProviderExtDelegate alloc]initWithDispatcher:[MNExtWrapperEventDispatcherAir shared]]];
   }

  return NULL;
 }

