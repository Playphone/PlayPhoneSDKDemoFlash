//
//  MNGameCookiesProviderAir.m
//  MultiNet Extension Wrapper Air
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "FlashRuntimeExtensions.h"
#import "MNExtWrapperDefs.h"
#import "MNExtWrapperAir.h"
#import "MNFRETools.h"

#import "MNDirect.h"
#import "MNGameCookiesProvider.h"

#import "MNExtWrapperEventDispatcherAir.h"
#import "MNGameCookiesProviderExtDelegate.h"


EXTERN_C FREObject MNGameCookiesProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  return NULL;
 }

EXTERN_C FREObject MNGameCookiesProvider_downloadUserCookie(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int key;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&key)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect gameCookiesProvider] downloadUserCookie:key];

  return NULL;
 }

EXTERN_C FREObject MNGameCookiesProvider_uploadUserCookie(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int key;
  NSString* cookie;

  if (argc >= 2)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&key)];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&cookie withType:[NSString class] fromFREObject:argv[1]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect gameCookiesProvider] uploadUserCookieWithKey:key andCookie:cookie];

  return NULL;
 }

static BOOL eventHandlerAdded = NO;

EXTERN_C FREObject MNGameCookiesProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  if (!eventHandlerAdded)
   {
    eventHandlerAdded = YES;
    [[MNDirect gameCookiesProvider] addDelegate:[[MNGameCookiesProviderExtDelegate alloc]initWithDispatcher:[MNExtWrapperEventDispatcherAir shared]]];
   }

  return NULL;
 }

