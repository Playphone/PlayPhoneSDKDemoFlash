//
//  MNSessionAir.m
//  MultiNet Extension Wrapper Air
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "FlashRuntimeExtensions.h"
#import "MNExtWrapperDefs.h"
#import "MNExtWrapperAir.h"
#import "MNFRETools.h"

#import "MNDirect.h"
#import "MNSession.h"

#import "MNExtWrapperEventDispatcherAir.h"
#import "MNSessionExtDelegate.h"


EXTERN_C FREObject MNSession_loginWithUserLoginAndPassword(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSString* login;
  NSString* password;
  BOOL saveCredentials;

  if (argc >= 3)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&login withType:[NSString class] fromFREObject:argv[0]]];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&password withType:[NSString class] fromFREObject:argv[1]]];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsBOOL(argv[2],&saveCredentials)];
   }

  if (!argResult)
   {
    return NULL;
   }

  BOOL result;
  result = [[MNDirect getSession] loginWithUserLogin:login password:password saveCredentials:saveCredentials];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_loginWithUserIdAndPasswordHash(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  long long _id;
  NSString* passwordHash;
  BOOL saveCredentials;

  if (argc >= 3)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsLongLong(argv[0],&_id)];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&passwordHash withType:[NSString class] fromFREObject:argv[1]]];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsBOOL(argv[2],&saveCredentials)];
   }

  if (!argResult)
   {
    return NULL;
   }

  BOOL result;
  result = [[MNDirect getSession] loginWithUserId:_id passwordHash:passwordHash saveCredentials:saveCredentials];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_loginWithDeviceCredentials(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [[MNDirect getSession] loginWithDeviceCredentials];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_loginWithUserIdAndAuthSign(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  long long _id;
  NSString* authSign;

  if (argc >= 2)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsLongLong(argv[0],&_id)];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&authSign withType:[NSString class] fromFREObject:argv[1]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  BOOL result;
  result = [[MNDirect getSession] loginWithUserId:_id authSign:authSign];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_loginOfflineWithUserIdAndAuthSign(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  long long _id;
  NSString* authSign;

  if (argc >= 2)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsLongLong(argv[0],&_id)];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&authSign withType:[NSString class] fromFREObject:argv[1]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  BOOL result;
  result = [[MNDirect getSession] loginOfflineWithUserId:_id authSign:authSign];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_signupOffline(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [[MNDirect getSession] signupOffline];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_loginAuto(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [[MNDirect getSession] loginAuto];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_logout(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  [[MNDirect getSession] logout];

  return NULL;
 }

EXTERN_C FREObject MNSession_logoutAndWipeUserCredentialsByMode(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int wipeMode;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&wipeMode)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] logoutAndWipeUserCredentialsByMode:wipeMode];

  return NULL;
 }

EXTERN_C FREObject MNSession_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  return NULL;
 }

EXTERN_C FREObject MNSession_isReLoginPossible(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [[MNDirect getSession] isReLoginPossible];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_reLogin(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  [[MNDirect getSession] reLogin];

  return NULL;
 }

EXTERN_C FREObject MNSession_isOnline(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [[MNDirect getSession] isOnline];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_isUserLoggedIn(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [[MNDirect getSession] isUserLoggedIn];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_getGameId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  int result;
  result = [[MNDirect getSession] getGameId];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromInt(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from int");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_isInGameRoom(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [[MNDirect getSession] isInGameRoom];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_getStatus(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  int result;
  result = [[MNDirect getSession] getStatus];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromInt(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from int");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_getMyUserName(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  NSString* result;
  result = [[MNDirect getSession] getMyUserName];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from NSString");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_getMyUserId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  long long result;
  result = [[MNDirect getSession] getMyUserId];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromLongLong(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from long long");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_getMyUserSFId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  int result;
  result = [[MNDirect getSession] getMyUserSFId];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromInt(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from int");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_getMyUserInfo(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  MNUserInfo* result;
  result = [[MNDirect getSession] getMyUserInfo];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from MNUserInfo");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_getCurrentRoomId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  int result;
  result = [[MNDirect getSession] getCurrentRoomId];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromInt(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from int");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_getWebServerURL(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  NSString* result;
  result = [[MNDirect getSession] getWebServerURL];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from NSString");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_getWebFrontURL(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  NSString* result;
  result = [[MNDirect getSession] getWebFrontURL];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from NSString");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_getRoomUserList(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  NSArray *result;
  result = [[MNDirect getSession] getRoomUserList];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from MNUserInfo[]");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_getUserInfoBySFId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int sfId;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&sfId)];
   }

  if (!argResult)
   {
    return NULL;
   }

  MNUserInfo* result;
  result = [[MNDirect getSession] getUserInfoBySFId:sfId];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from MNUserInfo");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_getRoomUserStatus(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  int result;
  result = [[MNDirect getSession] getRoomUserStatus];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromInt(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from int");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_getRoomGameSetId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  int result;
  result = [[MNDirect getSession] getRoomGameSetId];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromInt(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from int");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_getMySId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  NSString* result;
  result = [[MNDirect getSession] getMySId];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from NSString");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_sendAppBeacon(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSString* actionName;
  NSString* beaconData;
  long long beaconCallSeqNumber;

  if (argc >= 3)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&actionName withType:[NSString class] fromFREObject:argv[0]]];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&beaconData withType:[NSString class] fromFREObject:argv[1]]];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsLongLong(argv[2],&beaconCallSeqNumber)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] sendAppBeacon:actionName beaconData:beaconData beaconCallSeqNumber:beaconCallSeqNumber];

  return NULL;
 }

EXTERN_C FREObject MNSession_execAppCommand(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSString* name;
  NSString* param;

  if (argc >= 2)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&name withType:[NSString class] fromFREObject:argv[0]]];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&param withType:[NSString class] fromFREObject:argv[1]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] execAppCommand:name withParam:param];

  return NULL;
 }

EXTERN_C FREObject MNSession_execUICommand(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSString* name;
  NSString* param;

  if (argc >= 2)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&name withType:[NSString class] fromFREObject:argv[0]]];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&param withType:[NSString class] fromFREObject:argv[1]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] execUICommand:name withParam:param];

  return NULL;
 }

EXTERN_C FREObject MNSession_processWebEvent(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSString* eventName;
  NSString* eventParam;
  NSString* callbackId;

  if (argc >= 3)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&eventName withType:[NSString class] fromFREObject:argv[0]]];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&eventParam withType:[NSString class] fromFREObject:argv[1]]];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&callbackId withType:[NSString class] fromFREObject:argv[2]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] processWebEvent:eventName withParam:eventParam andCallbackId:callbackId];

  return NULL;
 }

EXTERN_C FREObject MNSession_postSysEvent(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSString* eventName;
  NSString* eventParam;
  NSString* callbackId;

  if (argc >= 3)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&eventName withType:[NSString class] fromFREObject:argv[0]]];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&eventParam withType:[NSString class] fromFREObject:argv[1]]];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&callbackId withType:[NSString class] fromFREObject:argv[2]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] postSysEvent:eventName withParam:eventParam andCallbackId:callbackId];

  return NULL;
 }

EXTERN_C FREObject MNSession_getApplicationStartParam(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  return NULL;
 }

EXTERN_C FREObject MNSession_sendPrivateMessage(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSString* message;
  int toUserSFId;

  if (argc >= 2)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&message withType:[NSString class] fromFREObject:argv[0]]];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[1],&toUserSFId)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] sendPrivateMessage:message to:toUserSFId];

  return NULL;
 }

EXTERN_C FREObject MNSession_sendChatMessage(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSString* message;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&message withType:[NSString class] fromFREObject:argv[0]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] sendChatMessage:message];

  return NULL;
 }

EXTERN_C FREObject MNSession_sendGameMessage(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSString* message;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&message withType:[NSString class] fromFREObject:argv[0]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] sendGameMessage:message];

  return NULL;
 }

EXTERN_C FREObject MNSession_sendPluginMessage(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSString* pluginName;
  NSString* message;

  if (argc >= 2)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&pluginName withType:[NSString class] fromFREObject:argv[0]]];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&message withType:[NSString class] fromFREObject:argv[1]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] sendPlugin:pluginName message:message];

  return NULL;
 }

EXTERN_C FREObject MNSession_reqJoinBuddyRoom(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int roomSFId;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&roomSFId)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] reqJoinBuddyRoom:roomSFId];

  return NULL;
 }

EXTERN_C FREObject MNSession_sendJoinRoomInvitationResponse(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  MNJoinRoomInvitationParams* invitationParams;
  BOOL accept;

  if (argc >= 2)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&invitationParams withType:[MNJoinRoomInvitationParams class] fromFREObject:argv[0]]];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsBOOL(argv[1],&accept)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] sendJoinRoomInvitationResponse:invitationParams accept:accept];

  return NULL;
 }

EXTERN_C FREObject MNSession_reqJoinRandomRoom(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSString* gameSetId;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&gameSetId withType:[NSString class] fromFREObject:argv[0]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] reqJoinRandomRoom:gameSetId];

  return NULL;
 }

EXTERN_C FREObject MNSession_reqCreateBuddyRoom(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  MNBuddyRoomParams* buddyRoomParams;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&buddyRoomParams withType:[MNBuddyRoomParams class] fromFREObject:argv[0]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] reqCreateBuddyRoom:buddyRoomParams];

  return NULL;
 }

EXTERN_C FREObject MNSession_reqStartBuddyRoomGame(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  [[MNDirect getSession] reqStartBuddyRoomGame];

  return NULL;
 }

EXTERN_C FREObject MNSession_reqStopRoomGame(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  [[MNDirect getSession] reqStopRoomGame];

  return NULL;
 }

EXTERN_C FREObject MNSession_reqCurrentGameResults(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  [[MNDirect getSession] reqCurrentGameResults];

  return NULL;
 }

EXTERN_C FREObject MNSession_reqSetUserStatus(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int userStatus;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&userStatus)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] reqSetUserStatus:userStatus];

  return NULL;
 }

EXTERN_C FREObject MNSession_startGameWithParams(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  MNGameParams* gameParams;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&gameParams withType:[MNGameParams class] fromFREObject:argv[0]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] startGameWithParams:gameParams];

  return NULL;
 }

EXTERN_C FREObject MNSession_finishGameWithResult(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  MNGameResult* gameResult;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&gameResult withType:[MNGameResult class] fromFREObject:argv[0]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] finishGameWithResult:gameResult];

  return NULL;
 }

EXTERN_C FREObject MNSession_schedulePostScoreOnLogin(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  MNGameResult* gameResult;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&gameResult withType:[MNGameResult class] fromFREObject:argv[0]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] schedulePostScoreOnLogin:gameResult];

  return NULL;
 }

EXTERN_C FREObject MNSession_cancelPostScoreOnLogin(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  [[MNDirect getSession] cancelPostScoreOnLogin];

  return NULL;
 }

EXTERN_C FREObject MNSession_cancelGameWithParams(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  MNGameParams* gameParams;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&gameParams withType:[MNGameParams class] fromFREObject:argv[0]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] cancelGameWithParams:gameParams];

  return NULL;
 }

EXTERN_C FREObject MNSession_setDefaultGameSetId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int gameSetId;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&gameSetId)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] setDefaultGameSetId:gameSetId];

  return NULL;
 }

EXTERN_C FREObject MNSession_getDefaultGameSetId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  int result;
  result = [[MNDirect getSession] getDefaultGameSetId];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromInt(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from int");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_leaveRoom(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  [[MNDirect getSession] leaveRoom];

  return NULL;
 }

static BOOL eventHandlerAdded = NO;

EXTERN_C FREObject MNSession_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  if (!eventHandlerAdded)
   {
    eventHandlerAdded = YES;
    [[MNDirect getSession] addDelegate:[[MNSessionExtDelegate alloc]initWithDispatcher:[MNExtWrapperEventDispatcherAir shared]]];
   }

  return NULL;
 }

EXTERN_C FREObject MNSession_onOfflinePackStartPageReady(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  return NULL;
 }

EXTERN_C FREObject MNSession_onOfflinePackUnavailable(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  return NULL;
 }

EXTERN_C FREObject MNSession_varStorageSetValue(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSString* name;
  NSString* value;

  if (argc >= 2)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&name withType:[NSString class] fromFREObject:argv[0]]];
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&value withType:[NSString class] fromFREObject:argv[1]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] varStorageSetValue:value forVariable:name];

  return NULL;
 }

EXTERN_C FREObject MNSession_varStorageGetValueForVariable(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSString* name;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&name withType:[NSString class] fromFREObject:argv[0]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  NSString* result;
  result = [[MNDirect getSession] varStorageGetValueForVariable:name];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from NSString");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_varStorageGetValuesByMasks(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSArray *masks;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getArray:&masks withElementTypeClass:[NSString class] fromFREObject:argv[0]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  NSDictionary* result;
  result = [[MNDirect getSession] varStorageGetValuesByMasks:masks];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from NSDictionary");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_varStorageRemoveVariablesByMask(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSString* mask;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&mask withType:[NSString class] fromFREObject:argv[0]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] varStorageRemoveVariablesByMask:mask];

  return NULL;
 }

EXTERN_C FREObject MNSession_varStorageRemoveVariablesByMasks(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  NSArray *masks;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getArray:&masks withElementTypeClass:[NSString class] fromFREObject:argv[0]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] varStorageRemoveVariablesByMasks:masks];

  return NULL;
 }

EXTERN_C FREObject MNSession_getUniqueAppId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  NSString* result;
  result = [[MNDirect getSession] getUniqueAppId];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from NSString");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNSession_onAppBeaconResponseReceived(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  MNAppBeaconResponse* response;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&response withType:[MNAppBeaconResponse class] fromFREObject:argv[0]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect getSession] onAppBeaconResponseReceived:response];

  return NULL;
 }

EXTERN_C FREObject MNSession_isWebShopReady(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [[MNDirect getSession] isWebShopReady];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

