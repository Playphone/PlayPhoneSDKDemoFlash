//
//  MNDirectUIHelperAir.m
//  MultiNet Extension Wrapper Air
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "FlashRuntimeExtensions.h"
#import "MNExtWrapperDefs.h"
#import "MNExtWrapperAir.h"
#import "MNFRETools.h"

#import "MNDirect.h"
#import "MNDirectUIHelper.h"

#import "UIKit/UIKit.h"

EXTERN_C FREObject MNDirectUIHelper_setDashboardStyle(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int newStyle;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&newStyle)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [MNDirectUIHelper setDashboardStyle:newStyle];

  return NULL;
 }

EXTERN_C FREObject MNDirectUIHelper_setHostActivity(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;
  return NULL;
 }

EXTERN_C FREObject MNDirectUIHelper_showDashboard(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  [MNDirectUIHelper showDashboard];

  return NULL;
 }

EXTERN_C FREObject MNDirectUIHelper_hideDashboard(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  [MNDirectUIHelper hideDashboard];

  return NULL;
 }

EXTERN_C FREObject MNDirectUIHelper_isDashboardHidden(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [MNDirectUIHelper isDashboardHidden];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNDirectUIHelper_isDashboardVisible(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [MNDirectUIHelper isDashboardVisible];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

