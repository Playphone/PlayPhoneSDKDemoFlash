//
//  MNExtWrapperAir.h
//  MultiNet Extension Wrapper Air
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MNFRETools.h"

@interface MNExtWrapperAir : NSObject
+ (MNFRETools*)freTools;
@end
