//
//  PlayPhoneMultiNetExt.m
//  MultiNet Extension Wrapper Air
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "FlashRuntimeExtensions.h"

#import "MNExtWrapperCommon.h"
#import "MNExtWrapperDefs.h"

typedef FREObject (*MNAirWrapperNativeFuncPtr)(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
typedef struct {
  MNAirWrapperNativeFuncPtr nativeFunction;
  NSString *actionScriptFunctionName;
} MNAirWrapperFunctionInfo;

EXTERN_C FREObject MNVarStorage_save(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
  NSLog(@"MNVarStorage_save");
  return NULL;
}

EXTERN_C FREObject MNWSProvider_send(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNWSProvider_cancel(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirect_init(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirect_makeGameSecretByComponents(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirect_shutdownSession(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirect_isOnline(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirect_isUserLoggedIn(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirect_getSessionStatus(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirect_postGameScore(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirect_postGameScorePending(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirect_cancelGame(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirect_setDefaultGameSetId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirect_getDefaultGameSetId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirect_sendAppBeacon(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirect_execAppCommand(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirect_sendGameMessage(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirectButton_isVisible(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirectButton_isHidden(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirectButton_initWithLocation(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirectButton_show(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirectButton_hide(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirectButton_setVShopEventAutoHandleEnabled(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirectPopup_init(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirectPopup_isActive(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirectPopup_setActive(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirectUIHelper_setDashboardStyle(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirectUIHelper_setHostActivity(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirectUIHelper_showDashboard(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirectUIHelper_hideDashboard(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirectUIHelper_isDashboardHidden(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNDirectUIHelper_isDashboardVisible(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_loginWithUserLoginAndPassword(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_loginWithUserIdAndPasswordHash(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_loginWithDeviceCredentials(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_loginWithUserIdAndAuthSign(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_loginOfflineWithUserIdAndAuthSign(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_signupOffline(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_loginAuto(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_logout(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_logoutAndWipeUserCredentialsByMode(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_isReLoginPossible(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_reLogin(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_isOnline(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_isUserLoggedIn(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_getGameId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_isInGameRoom(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_getStatus(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_getMyUserName(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_getMyUserId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_getMyUserSFId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_getMyUserInfo(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_getCurrentRoomId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_getWebServerURL(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_getWebFrontURL(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_getRoomUserList(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_getUserInfoBySFId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_getRoomUserStatus(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_getRoomGameSetId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_getMySId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_sendAppBeacon(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_execAppCommand(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_execUICommand(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_processWebEvent(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_postSysEvent(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_getApplicationStartParam(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_sendPrivateMessage(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_sendChatMessage(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_sendGameMessage(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_sendPluginMessage(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_reqJoinBuddyRoom(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_sendJoinRoomInvitationResponse(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_reqJoinRandomRoom(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_reqCreateBuddyRoom(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_reqStartBuddyRoomGame(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_reqStopRoomGame(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_reqCurrentGameResults(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_reqSetUserStatus(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_startGameWithParams(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_finishGameWithResult(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_schedulePostScoreOnLogin(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_cancelPostScoreOnLogin(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_cancelGameWithParams(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_setDefaultGameSetId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_getDefaultGameSetId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_leaveRoom(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_onOfflinePackStartPageReady(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_onOfflinePackUnavailable(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_varStorageSetValue(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_varStorageGetValueForVariable(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_varStorageGetValuesByMasks(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_varStorageRemoveVariablesByMask(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_varStorageRemoveVariablesByMasks(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_getUniqueAppId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_onAppBeaconResponseReceived(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNSession_isWebShopReady(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNAchievementsProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNAchievementsProvider_getGameAchievementsList(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNAchievementsProvider_findGameAchievementById(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNAchievementsProvider_isGameAchievementListNeedUpdate(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNAchievementsProvider_doGameAchievementListUpdate(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNAchievementsProvider_isPlayerAchievementUnlocked(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNAchievementsProvider_unlockPlayerAchievement(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNAchievementsProvider_getPlayerAchievementsList(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNAchievementsProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNAchievementsProvider_getAchievementImageURL(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNClientRobotsProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNClientRobotsProvider_isRobot(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNClientRobotsProvider_postRobotScore(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNClientRobotsProvider_setRoomRobotLimit(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNClientRobotsProvider_getRoomRobotLimit(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNGameCookiesProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNGameCookiesProvider_downloadUserCookie(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNGameCookiesProvider_uploadUserCookie(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNGameCookiesProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNGameSettingsProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNGameSettingsProvider_getGameSettingList(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNGameSettingsProvider_findGameSettingById(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNGameSettingsProvider_isGameSettingListNeedUpdate(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNGameSettingsProvider_doGameSettingListUpdate(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNGameSettingsProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNMyHiScoresProvider_getMyHiScore(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNMyHiScoresProvider_getMyHiScores(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNMyHiScoresProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNMyHiScoresProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNPlayerListProvider_getPlayerList(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNPlayerListProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNPlayerListProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNGameRoomCookiesProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNGameRoomCookiesProvider_downloadGameRoomCookie(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNGameRoomCookiesProvider_setCurrentGameRoomCookie(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNGameRoomCookiesProvider_getCurrentGameRoomCookie(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNGameRoomCookiesProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNScoreProgressProvider_setRefreshIntervalAndUpdateDelay(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNScoreProgressProvider_start(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNScoreProgressProvider_stop(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNScoreProgressProvider_postScore(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNScoreProgressProvider_setScoreComparator(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNScoreProgressProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNServerInfoProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNServerInfoProvider_requestServerInfoItem(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNServerInfoProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVItemsProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVItemsProvider_getGameVItemsList(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVItemsProvider_findGameVItemById(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVItemsProvider_isGameVItemsListNeedUpdate(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVItemsProvider_doGameVItemsListUpdate(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVItemsProvider_reqAddPlayerVItem(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVItemsProvider_reqAddPlayerVItemTransaction(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVItemsProvider_reqTransferPlayerVItem(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVItemsProvider_reqTransferPlayerVItemTransaction(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVItemsProvider_getPlayerVItemList(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVItemsProvider_getPlayerVItemCountById(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVItemsProvider_getVItemImageURL(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVItemsProvider_getNewClientTransactionId(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVItemsProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVShopProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVShopProvider_getVShopPackList(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVShopProvider_getVShopCategoryList(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVShopProvider_findVShopPackById(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVShopProvider_findVShopCategoryById(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVShopProvider_isVShopInfoNeedUpdate(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVShopProvider_doVShopInfoUpdate(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVShopProvider_getVShopPackImageURL(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVShopProvider_execCheckoutVShopPacks(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVShopProvider_procCheckoutVShopPacksSilent(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVShopProvider_isVShopReady(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);
EXTERN_C FREObject MNVShopProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]);

static MNAirWrapperFunctionInfo MNAirWrapperFunctionsMap[] =
 {
  { MNWSProvider_send,@"MNWSProvider_send" },
  { MNWSProvider_cancel,@"MNWSProvider_cancel" },

  { MNVarStorage_save,@"MNVarStorage_save" },  
  { MNDirect_init,@"MNDirect_init" },
  { MNDirect_makeGameSecretByComponents,@"MNDirect_makeGameSecretByComponents" },
  { MNDirect_shutdownSession,@"MNDirect_shutdownSession" },
  { MNDirect_isOnline,@"MNDirect_isOnline" },
  { MNDirect_isUserLoggedIn,@"MNDirect_isUserLoggedIn" },
  { MNDirect_getSessionStatus,@"MNDirect_getSessionStatus" },
  { MNDirect_postGameScore,@"MNDirect_postGameScore" },
  { MNDirect_postGameScorePending,@"MNDirect_postGameScorePending" },
  { MNDirect_cancelGame,@"MNDirect_cancelGame" },
  { MNDirect_setDefaultGameSetId,@"MNDirect_setDefaultGameSetId" },
  { MNDirect_getDefaultGameSetId,@"MNDirect_getDefaultGameSetId" },
  { MNDirect_sendAppBeacon,@"MNDirect_sendAppBeacon" },
  { MNDirect_execAppCommand,@"MNDirect_execAppCommand" },
  { MNDirect_sendGameMessage,@"MNDirect_sendGameMessage" },
  { MNDirectButton_isVisible,@"MNDirectButton_isVisible" },
  { MNDirectButton_isHidden,@"MNDirectButton_isHidden" },
  { MNDirectButton_initWithLocation,@"MNDirectButton_initWithLocation" },
  { MNDirectButton_show,@"MNDirectButton_show" },
  { MNDirectButton_hide,@"MNDirectButton_hide" },
  { MNDirectButton_setVShopEventAutoHandleEnabled,@"MNDirectButton_setVShopEventAutoHandleEnabled" },
  { MNDirectPopup_init,@"MNDirectPopup_init" },
  { MNDirectPopup_isActive,@"MNDirectPopup_isActive" },
  { MNDirectPopup_setActive,@"MNDirectPopup_setActive" },
  { MNDirectUIHelper_setDashboardStyle,@"MNDirectUIHelper_setDashboardStyle" },
  { MNDirectUIHelper_setHostActivity,@"MNDirectUIHelper_setHostActivity" },
  { MNDirectUIHelper_showDashboard,@"MNDirectUIHelper_showDashboard" },
  { MNDirectUIHelper_hideDashboard,@"MNDirectUIHelper_hideDashboard" },
  { MNDirectUIHelper_isDashboardHidden,@"MNDirectUIHelper_isDashboardHidden" },
  { MNDirectUIHelper_isDashboardVisible,@"MNDirectUIHelper_isDashboardVisible" },
  { MNSession_loginWithUserLoginAndPassword,@"MNSession_loginWithUserLoginAndPassword" },
  { MNSession_loginWithUserIdAndPasswordHash,@"MNSession_loginWithUserIdAndPasswordHash" },
  { MNSession_loginWithDeviceCredentials,@"MNSession_loginWithDeviceCredentials" },
  { MNSession_loginWithUserIdAndAuthSign,@"MNSession_loginWithUserIdAndAuthSign" },
  { MNSession_loginOfflineWithUserIdAndAuthSign,@"MNSession_loginOfflineWithUserIdAndAuthSign" },
  { MNSession_signupOffline,@"MNSession_signupOffline" },
  { MNSession_loginAuto,@"MNSession_loginAuto" },
  { MNSession_logout,@"MNSession_logout" },
  { MNSession_logoutAndWipeUserCredentialsByMode,@"MNSession_logoutAndWipeUserCredentialsByMode" },
  { MNSession_shutdown,@"MNSession_shutdown" },
  { MNSession_isReLoginPossible,@"MNSession_isReLoginPossible" },
  { MNSession_reLogin,@"MNSession_reLogin" },
  { MNSession_isOnline,@"MNSession_isOnline" },
  { MNSession_isUserLoggedIn,@"MNSession_isUserLoggedIn" },
  { MNSession_getGameId,@"MNSession_getGameId" },
  { MNSession_isInGameRoom,@"MNSession_isInGameRoom" },
  { MNSession_getStatus,@"MNSession_getStatus" },
  { MNSession_getMyUserName,@"MNSession_getMyUserName" },
  { MNSession_getMyUserId,@"MNSession_getMyUserId" },
  { MNSession_getMyUserSFId,@"MNSession_getMyUserSFId" },
  { MNSession_getMyUserInfo,@"MNSession_getMyUserInfo" },
  { MNSession_getCurrentRoomId,@"MNSession_getCurrentRoomId" },
  { MNSession_getWebServerURL,@"MNSession_getWebServerURL" },
  { MNSession_getWebFrontURL,@"MNSession_getWebFrontURL" },
  { MNSession_getRoomUserList,@"MNSession_getRoomUserList" },
  { MNSession_getUserInfoBySFId,@"MNSession_getUserInfoBySFId" },
  { MNSession_getRoomUserStatus,@"MNSession_getRoomUserStatus" },
  { MNSession_getRoomGameSetId,@"MNSession_getRoomGameSetId" },
  { MNSession_getMySId,@"MNSession_getMySId" },
  { MNSession_sendAppBeacon,@"MNSession_sendAppBeacon" },
  { MNSession_execAppCommand,@"MNSession_execAppCommand" },
  { MNSession_execUICommand,@"MNSession_execUICommand" },
  { MNSession_processWebEvent,@"MNSession_processWebEvent" },
  { MNSession_postSysEvent,@"MNSession_postSysEvent" },
  { MNSession_getApplicationStartParam,@"MNSession_getApplicationStartParam" },
  { MNSession_sendPrivateMessage,@"MNSession_sendPrivateMessage" },
  { MNSession_sendChatMessage,@"MNSession_sendChatMessage" },
  { MNSession_sendGameMessage,@"MNSession_sendGameMessage" },
  { MNSession_sendPluginMessage,@"MNSession_sendPluginMessage" },
  { MNSession_reqJoinBuddyRoom,@"MNSession_reqJoinBuddyRoom" },
  { MNSession_sendJoinRoomInvitationResponse,@"MNSession_sendJoinRoomInvitationResponse" },
  { MNSession_reqJoinRandomRoom,@"MNSession_reqJoinRandomRoom" },
  { MNSession_reqCreateBuddyRoom,@"MNSession_reqCreateBuddyRoom" },
  { MNSession_reqStartBuddyRoomGame,@"MNSession_reqStartBuddyRoomGame" },
  { MNSession_reqStopRoomGame,@"MNSession_reqStopRoomGame" },
  { MNSession_reqCurrentGameResults,@"MNSession_reqCurrentGameResults" },
  { MNSession_reqSetUserStatus,@"MNSession_reqSetUserStatus" },
  { MNSession_startGameWithParams,@"MNSession_startGameWithParams" },
  { MNSession_finishGameWithResult,@"MNSession_finishGameWithResult" },
  { MNSession_schedulePostScoreOnLogin,@"MNSession_schedulePostScoreOnLogin" },
  { MNSession_cancelPostScoreOnLogin,@"MNSession_cancelPostScoreOnLogin" },
  { MNSession_cancelGameWithParams,@"MNSession_cancelGameWithParams" },
  { MNSession_setDefaultGameSetId,@"MNSession_setDefaultGameSetId" },
  { MNSession_getDefaultGameSetId,@"MNSession_getDefaultGameSetId" },
  { MNSession_leaveRoom,@"MNSession_leaveRoom" },
  { MNSession_addEventHandler,@"MNSession_addEventHandler" },
  { MNSession_onOfflinePackStartPageReady,@"MNSession_onOfflinePackStartPageReady" },
  { MNSession_onOfflinePackUnavailable,@"MNSession_onOfflinePackUnavailable" },
  { MNSession_varStorageSetValue,@"MNSession_varStorageSetValue" },
  { MNSession_varStorageGetValueForVariable,@"MNSession_varStorageGetValueForVariable" },
  { MNSession_varStorageGetValuesByMasks,@"MNSession_varStorageGetValuesByMasks" },
  { MNSession_varStorageRemoveVariablesByMask,@"MNSession_varStorageRemoveVariablesByMask" },
  { MNSession_varStorageRemoveVariablesByMasks,@"MNSession_varStorageRemoveVariablesByMasks" },
  { MNSession_getUniqueAppId,@"MNSession_getUniqueAppId" },
  { MNSession_onAppBeaconResponseReceived,@"MNSession_onAppBeaconResponseReceived" },
  { MNSession_isWebShopReady,@"MNSession_isWebShopReady" },
  { MNAchievementsProvider_shutdown,@"MNAchievementsProvider_shutdown" },
  { MNAchievementsProvider_getGameAchievementsList,@"MNAchievementsProvider_getGameAchievementsList" },
  { MNAchievementsProvider_findGameAchievementById,@"MNAchievementsProvider_findGameAchievementById" },
  { MNAchievementsProvider_isGameAchievementListNeedUpdate,@"MNAchievementsProvider_isGameAchievementListNeedUpdate" },
  { MNAchievementsProvider_doGameAchievementListUpdate,@"MNAchievementsProvider_doGameAchievementListUpdate" },
  { MNAchievementsProvider_isPlayerAchievementUnlocked,@"MNAchievementsProvider_isPlayerAchievementUnlocked" },
  { MNAchievementsProvider_unlockPlayerAchievement,@"MNAchievementsProvider_unlockPlayerAchievement" },
  { MNAchievementsProvider_getPlayerAchievementsList,@"MNAchievementsProvider_getPlayerAchievementsList" },
  { MNAchievementsProvider_addEventHandler,@"MNAchievementsProvider_addEventHandler" },
  { MNAchievementsProvider_getAchievementImageURL,@"MNAchievementsProvider_getAchievementImageURL" },
  { MNClientRobotsProvider_shutdown,@"MNClientRobotsProvider_shutdown" },
  { MNClientRobotsProvider_isRobot,@"MNClientRobotsProvider_isRobot" },
  { MNClientRobotsProvider_postRobotScore,@"MNClientRobotsProvider_postRobotScore" },
  { MNClientRobotsProvider_setRoomRobotLimit,@"MNClientRobotsProvider_setRoomRobotLimit" },
  { MNClientRobotsProvider_getRoomRobotLimit,@"MNClientRobotsProvider_getRoomRobotLimit" },
  { MNGameCookiesProvider_shutdown,@"MNGameCookiesProvider_shutdown" },
  { MNGameCookiesProvider_downloadUserCookie,@"MNGameCookiesProvider_downloadUserCookie" },
  { MNGameCookiesProvider_uploadUserCookie,@"MNGameCookiesProvider_uploadUserCookie" },
  { MNGameCookiesProvider_addEventHandler,@"MNGameCookiesProvider_addEventHandler" },
  { MNGameSettingsProvider_shutdown,@"MNGameSettingsProvider_shutdown" },
  { MNGameSettingsProvider_getGameSettingList,@"MNGameSettingsProvider_getGameSettingList" },
  { MNGameSettingsProvider_findGameSettingById,@"MNGameSettingsProvider_findGameSettingById" },
  { MNGameSettingsProvider_isGameSettingListNeedUpdate,@"MNGameSettingsProvider_isGameSettingListNeedUpdate" },
  { MNGameSettingsProvider_doGameSettingListUpdate,@"MNGameSettingsProvider_doGameSettingListUpdate" },
  { MNGameSettingsProvider_addEventHandler,@"MNGameSettingsProvider_addEventHandler" },
  { MNMyHiScoresProvider_getMyHiScore,@"MNMyHiScoresProvider_getMyHiScore" },
  { MNMyHiScoresProvider_getMyHiScores,@"MNMyHiScoresProvider_getMyHiScores" },
  { MNMyHiScoresProvider_shutdown,@"MNMyHiScoresProvider_shutdown" },
  { MNMyHiScoresProvider_addEventHandler,@"MNMyHiScoresProvider_addEventHandler" },
  { MNPlayerListProvider_getPlayerList,@"MNPlayerListProvider_getPlayerList" },
  { MNPlayerListProvider_shutdown,@"MNPlayerListProvider_shutdown" },
  { MNPlayerListProvider_addEventHandler,@"MNPlayerListProvider_addEventHandler" },
  { MNGameRoomCookiesProvider_shutdown,@"MNGameRoomCookiesProvider_shutdown" },
  { MNGameRoomCookiesProvider_downloadGameRoomCookie,@"MNGameRoomCookiesProvider_downloadGameRoomCookie" },
  { MNGameRoomCookiesProvider_setCurrentGameRoomCookie,@"MNGameRoomCookiesProvider_setCurrentGameRoomCookie" },
  { MNGameRoomCookiesProvider_getCurrentGameRoomCookie,@"MNGameRoomCookiesProvider_getCurrentGameRoomCookie" },
  { MNGameRoomCookiesProvider_addEventHandler,@"MNGameRoomCookiesProvider_addEventHandler" },
  { MNScoreProgressProvider_setRefreshIntervalAndUpdateDelay,@"MNScoreProgressProvider_setRefreshIntervalAndUpdateDelay" },
  { MNScoreProgressProvider_start,@"MNScoreProgressProvider_start" },
  { MNScoreProgressProvider_stop,@"MNScoreProgressProvider_stop" },
  { MNScoreProgressProvider_postScore,@"MNScoreProgressProvider_postScore" },
  { MNScoreProgressProvider_setScoreComparator,@"MNScoreProgressProvider_setScoreComparator" },
  { MNScoreProgressProvider_addEventHandler,@"MNScoreProgressProvider_addEventHandler" },
  { MNServerInfoProvider_shutdown,@"MNServerInfoProvider_shutdown" },
  { MNServerInfoProvider_requestServerInfoItem,@"MNServerInfoProvider_requestServerInfoItem" },
  { MNServerInfoProvider_addEventHandler,@"MNServerInfoProvider_addEventHandler" },
  { MNVItemsProvider_shutdown,@"MNVItemsProvider_shutdown" },
  { MNVItemsProvider_getGameVItemsList,@"MNVItemsProvider_getGameVItemsList" },
  { MNVItemsProvider_findGameVItemById,@"MNVItemsProvider_findGameVItemById" },
  { MNVItemsProvider_isGameVItemsListNeedUpdate,@"MNVItemsProvider_isGameVItemsListNeedUpdate" },
  { MNVItemsProvider_doGameVItemsListUpdate,@"MNVItemsProvider_doGameVItemsListUpdate" },
  { MNVItemsProvider_reqAddPlayerVItem,@"MNVItemsProvider_reqAddPlayerVItem" },
  { MNVItemsProvider_reqAddPlayerVItemTransaction,@"MNVItemsProvider_reqAddPlayerVItemTransaction" },
  { MNVItemsProvider_reqTransferPlayerVItem,@"MNVItemsProvider_reqTransferPlayerVItem" },
  { MNVItemsProvider_reqTransferPlayerVItemTransaction,@"MNVItemsProvider_reqTransferPlayerVItemTransaction" },
  { MNVItemsProvider_getPlayerVItemList,@"MNVItemsProvider_getPlayerVItemList" },
  { MNVItemsProvider_getPlayerVItemCountById,@"MNVItemsProvider_getPlayerVItemCountById" },
  { MNVItemsProvider_getVItemImageURL,@"MNVItemsProvider_getVItemImageURL" },
  { MNVItemsProvider_getNewClientTransactionId,@"MNVItemsProvider_getNewClientTransactionId" },
  { MNVItemsProvider_addEventHandler,@"MNVItemsProvider_addEventHandler" },
  { MNVShopProvider_shutdown,@"MNVShopProvider_shutdown" },
  { MNVShopProvider_getVShopPackList,@"MNVShopProvider_getVShopPackList" },
  { MNVShopProvider_getVShopCategoryList,@"MNVShopProvider_getVShopCategoryList" },
  { MNVShopProvider_findVShopPackById,@"MNVShopProvider_findVShopPackById" },
  { MNVShopProvider_findVShopCategoryById,@"MNVShopProvider_findVShopCategoryById" },
  { MNVShopProvider_isVShopInfoNeedUpdate,@"MNVShopProvider_isVShopInfoNeedUpdate" },
  { MNVShopProvider_doVShopInfoUpdate,@"MNVShopProvider_doVShopInfoUpdate" },
  { MNVShopProvider_getVShopPackImageURL,@"MNVShopProvider_getVShopPackImageURL" },
  { MNVShopProvider_execCheckoutVShopPacks,@"MNVShopProvider_execCheckoutVShopPacks" },
  { MNVShopProvider_procCheckoutVShopPacksSilent,@"MNVShopProvider_procCheckoutVShopPacksSilent" },
  { MNVShopProvider_isVShopReady,@"MNVShopProvider_isVShopReady" },
  { MNVShopProvider_addEventHandler,@"MNVShopProvider_addEventHandler" },
 };


void ContextInitializer(void* extData,
                        const uint8_t* ctxType,
                        FREContext ctx,
                        uint32_t* numFunctionsToTest,
                        const FRENamedFunction** functionsToSet)
 {
  NSLog(@"Entering ContextInitializer()");

  *numFunctionsToTest = sizeof(MNAirWrapperFunctionsMap) / sizeof(MNAirWrapperFunctionsMap[0]);
  FRENamedFunction* func = (FRENamedFunction*) malloc(sizeof(FRENamedFunction) * *numFunctionsToTest);

  for (unsigned int index = 0;index < *numFunctionsToTest;index++) {
    func[index].name = (const uint8_t*)[MNAirWrapperFunctionsMap[index].actionScriptFunctionName UTF8String];
    func[index].functionData = NULL;
    func[index].function = MNAirWrapperFunctionsMap[index].nativeFunction;
  }
  
  *functionsToSet = func;

  NSLog(@"Exiting ContextInitializer()");
 }


void ContextFinalizer(FREContext ctx)
 {
  NSLog(@"Entering ContextFinalizer()");

  // Nothing to clean up.

  NSLog(@"Exiting ContextFinalizer()");

   return;
 }

void ExtInitializer(void** extDataToSet,
                    FREContextInitializer* ctxInitializerToSet,
                    FREContextFinalizer* ctxFinalizerToSet)
 {
  NSLog(@"Entering ExtInitializer()");

  *extDataToSet = NULL;
  *ctxInitializerToSet = &ContextInitializer;
  *ctxFinalizerToSet = &ContextFinalizer;

  [MNExtWrapperCommon setWrapperPlatform:MNExtWrapperPlatformAir];

  NSLog(@"Exiting ExtInitializer()");
 }

void ExtFinalizer(void* extData)
 {
  NSLog(@"Entering ExtFinalizer()");

  // Nothing to clean up.

  NSLog(@"Exiting ExtFinalizer()");
  return;
 }
