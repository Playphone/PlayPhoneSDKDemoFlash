//
//  MNGameSettingsProviderAir.m
//  MultiNet Extension Wrapper Air
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "FlashRuntimeExtensions.h"
#import "MNExtWrapperDefs.h"
#import "MNExtWrapperAir.h"
#import "MNFRETools.h"

#import "MNDirect.h"
#import "MNGameSettingsProvider.h"

#import "MNExtWrapperEventDispatcherAir.h"
#import "MNGameSettingsProviderExtDelegate.h"


EXTERN_C FREObject MNGameSettingsProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  return NULL;
 }

EXTERN_C FREObject MNGameSettingsProvider_getGameSettingList(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  NSArray *result;
  result = [[MNDirect gameSettingsProvider] getGameSettingList];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from MNGameSettingInfo[]");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNGameSettingsProvider_findGameSettingById(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int _id;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&_id)];
   }

  if (!argResult)
   {
    return NULL;
   }

  MNGameSettingInfo* result;
  result = [[MNDirect gameSettingsProvider] findGameSettingById:_id];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from MNGameSettingInfo");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNGameSettingsProvider_isGameSettingListNeedUpdate(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [[MNDirect gameSettingsProvider] isGameSettingListNeedUpdate];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNGameSettingsProvider_doGameSettingListUpdate(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  [[MNDirect gameSettingsProvider] doGameSettingListUpdate];

  return NULL;
 }

static BOOL eventHandlerAdded = NO;

EXTERN_C FREObject MNGameSettingsProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  if (!eventHandlerAdded)
   {
    eventHandlerAdded = YES;
    [[MNDirect gameSettingsProvider] addDelegate:[[MNGameSettingsProviderExtDelegate alloc]initWithDispatcher:[MNExtWrapperEventDispatcherAir shared]]];
   }

  return NULL;
 }

