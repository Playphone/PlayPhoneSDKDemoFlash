//
//  MNMyHiScoresProviderAir.m
//  MultiNet Extension Wrapper Air
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "FlashRuntimeExtensions.h"
#import "MNExtWrapperDefs.h"
#import "MNExtWrapperAir.h"
#import "MNFRETools.h"

#import "MNDirect.h"
#import "MNMyHiScoresProvider.h"

#import "MNExtWrapperEventDispatcherAir.h"
#import "MNMyHiScoresProviderExtDelegate.h"


EXTERN_C FREObject MNMyHiScoresProvider_getMyHiScore(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int gameSetId;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&gameSetId)];
   }

  if (!argResult)
   {
    return NULL;
   }

  NSNumber* result;
  result = [[MNDirect myHiScoresProvider] getMyHiScore:gameSetId];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from NSNumber");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNMyHiScoresProvider_getMyHiScores(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  NSDictionary* result;
  result = [[MNDirect myHiScoresProvider] getMyHiScores];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from NSDictionary");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNMyHiScoresProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  return NULL;
 }

static BOOL eventHandlerAdded = NO;

EXTERN_C FREObject MNMyHiScoresProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  if (!eventHandlerAdded)
   {
    eventHandlerAdded = YES;
    [[MNDirect myHiScoresProvider] addDelegate:[[MNMyHiScoresProviderExtDelegate alloc]initWithDispatcher:[MNExtWrapperEventDispatcherAir shared]]];
   }

  return NULL;
 }

