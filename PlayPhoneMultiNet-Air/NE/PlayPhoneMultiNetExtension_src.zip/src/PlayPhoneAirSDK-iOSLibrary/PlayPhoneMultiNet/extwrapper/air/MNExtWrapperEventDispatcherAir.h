//
//  MNExtWrapperEventDispatcherAir.h
//  MultiNet Extension Wrapper Air
//
//  Created by Vladislav Ogol on 7/13/12.
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FlashRuntimeExtensions.h"

#import "MNExtWrapperEventDispatcher.h"

@interface MNExtWrapperEventDispatcherAir : NSObject <MNExtWrapperEventDispatcher>
 {
  FREContext _freContext;
 }

@property (nonatomic,assign) FREContext freContext;

+ (MNExtWrapperEventDispatcherAir*)shared;

- (void)dealloc;

- (void)dispatchEvent:(NSString *)eventName withParams:(NSArray*) params andParamsNames:(NSArray*)paramNames;

@end
