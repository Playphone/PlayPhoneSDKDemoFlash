//
//  MNFRETools.m
//  MultiNet Extension Wrapper Air
//
//  Created by Vladislav Ogol on 04.07.12.
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//
#import <objc/runtime.h>

#import "MNDirect.h"
#import "MNErrorInfo.h"
#import "MNUserInfo.h"
#import "MNAchievementsProvider.h"
#import "MNJoinRoomInvitationParams.h"
#import "MNBuddyRoomParams.h"
#import "MNTrackingSystem.h"
#import "MNGameSettingsProvider.h"
#import "MNVItemsProvider.h"
#import "MNTools.h"

#import "MNExtWrapperAir.h"

#import "MNFRETools.h"


#define MaxIntegerDouble (pow(2, 52) - 1)


#pragma mark - FREToolsResult

@implementation MNFREResult
@synthesize totalStepNumber  = _totalStepNumber;
@synthesize failedStepNumber = _failedAttemtNumber;
@synthesize freResult   = _freResult;

+ (MNFREResult*)result
 {
  return [[[MNFREResult alloc]init]autorelease];
 }

- (id)init
 {
  if (self = [super init])
   {
    self.totalStepNumber = 0;
    self.failedStepNumber = 0;
    self.freResult  = FRE_OK;
   }

  return self;
 }

- (void) dealloc
 {
  [super dealloc];
 }

- (BOOL)collectResult:(FREResult)freResult
 {
  self.totalStepNumber++;

  if ((self.failedStepNumber == 0) && (freResult != FRE_OK))
   {
    self.failedStepNumber = self.totalStepNumber;
    self.freResult        = freResult;
   }

  return (freResult == FRE_OK);
 }

- (BOOL)isResultOk
 {
  return (self.freResult == FRE_OK);
 }

@end

#pragma mark - FREObject unpacking functions
EXTERN_C FREResult MNFREGetObjectAsInt     (FREObject freObject,int          *value)
 {
  return FREGetObjectAsInt32(freObject,value);
 }
EXTERN_C FREResult MNFREGetObjectAsUInt    (FREObject freObject,unsigned int *value)
 {
  return FREGetObjectAsUint32(freObject,value);
 }
EXTERN_C FREResult MNFREGetObjectAsDouble  (FREObject freObject,double       *value)
 {
  return FREGetObjectAsDouble(freObject,value);
 }
EXTERN_C FREResult MNFREGetObjectAsBOOL    (FREObject freObject,BOOL         *value)
 {
  uint32_t boolValue;
  FREResult result = FREGetObjectAsBool(freObject,&boolValue);

  *value = boolValue != 0;

  return result;
 }
EXTERN_C FREResult MNFREGetObjectAsLongLong(FREObject freObject,long long    *value)
 {
  MARK;
  double longAsDouble;
  FREResult result = MNFREGetObjectAsDouble(freObject,&longAsDouble);
  
  if (result != FRE_OK)
   {
    *value = 0;
    ELog(@"Can not get double representation of long value from FREObject. FREResult=%@",FREResultToString(result));
   }
  else
   {
    *value = (long long)longAsDouble;
    
    if (*value != longAsDouble)
     {
      ILog(@"Result of casting of double to long long does not equals to original value: %lld(long long) != %f(double)",*value,longAsDouble);
     }
   }
  
  DLog(@"value=%lld",*value);
  
  return result;
 }

#pragma mark - FREObject packing functions

FREResult MNFRENewObjectFromInt     (int          value,FREObject *freObject)
 {
  DLog("%d",value);
  return FRENewObjectFromInt32(value,freObject);
 }

FREResult MNFRENewObjectFromUInt    (unsigned int value,FREObject *freObject)
 {
  DLog("%u",value);
  return FRENewObjectFromUint32(value,freObject);
 }

FREResult MNFRENewObjectFromDouble  (double       value,FREObject *freObject)
 {
  DLog("%f",value);
  return FRENewObjectFromDouble(value,freObject);
 }

FREResult MNFRENewObjectFromBOOL    (BOOL         value,FREObject *freObject)
 {
  DLog("%@",value?@"true":@"false");
  return FRENewObjectFromBool(value,freObject);
 }

FREResult MNFRENewObjectFromLongLong(long long    value,FREObject *freObject)
 {
  DLog(@"%lld",value);
  
  if ((value > MaxIntegerDouble) ||
      (value < -MaxIntegerDouble))
   {
    ILog(@"Loss of precision possible. long long value is to big for double type: %lld",value);
   }
  
  return MNFRENewObjectFromDouble((double)value,freObject);
 }

FREResult ExtWrapperFRENewArray(FREObject *array,NSUInteger length)
 {
  MNFREResult *mnFREResult = [MNFREResult result];

  if ([mnFREResult collectResult:FRENewObject((const uint8_t*)"Array",0,NULL,array,NULL)])
   {
    [mnFREResult collectResult:FRESetArrayLength(*array,(uint32_t)length)];
   }

  if (![mnFREResult isResultOk])
   {
    ELog(@"Can not create FREArray of lenght: %d",length);
   }


  return mnFREResult.freResult;
 }

NSString* FREResultToString(FREResult freResult)
 {
  NSString *resultString = NULL;

  if (freResult == FRE_OK)
   {
    resultString = @"FRE_OK";
   }
  if (freResult == FRE_NO_SUCH_NAME)
   {
    resultString = @"FRE_NO_SUCH_NAME";
   }
  if (freResult == FRE_INVALID_OBJECT)
   {
    resultString = @"FRE_INVALID_OBJECT";
   }
  if (freResult == FRE_TYPE_MISMATCH)
   {
    resultString = @"FRE_TYPE_MISMATCH";
   }
  if (freResult == FRE_ACTIONSCRIPT_ERROR)
   {
    resultString = @"FRE_ACTIONSCRIPT_ERROR";
   }
  if (freResult == FRE_INVALID_ARGUMENT)
   {
    resultString = @"FRE_INVALID_ARGUMENT";
   }
  if (freResult == FRE_READ_ONLY)
   {
    resultString = @"FRE_READ_ONLY";
   }
  if (freResult == FRE_ILLEGAL_STATE)
   {
    resultString = @"FRE_ILLEGAL_STATE";
   }
  if (freResult == FRE_INSUFFICIENT_MEMORY)
   {
    resultString = @"FRE_INSUFFICIENT_MEMORY";
   }
  if (freResult == FREResult_ENUMPADDING)
   {
    resultString = @"FREResult_ENUMPADDING";
   }

  return resultString;
 }

static FREResult MNFRENumberToString(FREObject freNumber,FREObject *freString)
 {
  MARK;
  
  MNFREResult *result = [MNFREResult result];
  FREObject params[1];
  
  [result collectResult:MNFRENewObjectFromInt(0, &(params[0]))];
  [result collectResult:FRECallObjectMethod(freNumber, (const uint8_t*)[@"toFixed" UTF8String], 1, params, freString, NULL)];
  
  if (![result isResultOk])
   {
    ELog(@"Can not convert FRENumber to FREString. FREResult = %@, failed step No: %d",
         FREResultToString(result.freResult),
         result.failedStepNumber);
   }
  
  return result.freResult;
 }

@implementation MNFRETools

- (FREResult)getObject:(id*)value withType:(Class)objectType fromFREObject:(FREObject)freObject
 {
  FREResult freResult = FRE_OK;

  if (objectType == [NSString class])
   {
    uint32_t rawLength;
    const uint8_t *rawValue;

    freResult = FREGetObjectAsUTF8(freObject,&rawLength,&rawValue);

    if (freResult == FRE_OK)
     {
      *value = [NSString stringWithUTF8String:(const char*)rawValue];
     }
    else
     {
      ELog(@"FREGetObjectAsUTF8 failed with result: %@",FREResultToString(freResult));
     }
   }
  else if ([objectType respondsToSelector:@selector(getObject:fromFREObject:)])
   {
    // warning OK
    freResult = (FREResult)[objectType getObject:value fromFREObject:freObject];
   }
  else
   {
    ELog(@"Can not get object of type: %s from FREObject",class_getName(objectType));
    freResult = FRE_TYPE_MISMATCH;
   }

  return freResult;
 }

- (FREResult)getArray:(NSArray**)array withElementTypeEncode:(const char*)elementEncode fromFREObject:(FREObject)freArray
 {
  MNFREResult *mnFREResult = [MNFREResult result];
  NSMutableArray *resultArray = [NSMutableArray array];

  FREObject *freObjectsArray = NULL;
  NSUInteger freObjectsArrayLength = 0;
  
  NSUInteger index = 0;
  
  if (strcmp(elementEncode,@encode(int)) == 0)
   {
    [mnFREResult collectResult:[self getFREObjects:&freObjectsArray length:&freObjectsArrayLength fromFREArray:freArray]];

    int value;
    
    while (([mnFREResult isResultOk]) && (index < freObjectsArrayLength))
     {
      [mnFREResult collectResult:MNFREGetObjectAsInt(freObjectsArray[index],&value)];
      
      if ([mnFREResult isResultOk])
       {
        [resultArray addObject:[NSNumber numberWithInt:value]];
        index++;
       }
     }
   }
  else
   {
    mnFREResult.freResult = FRE_TYPE_MISMATCH;
   }
  
  if (![mnFREResult isResultOk])
   {
    ELog(@"Can not get array of objects with encode type %s from FREObject. FREResult = %@, failed step No: %d",
         elementEncode,
         FREResultToString([mnFREResult freResult]),
         [mnFREResult failedStepNumber]);
    
    *array = nil;
   }
  else
   {
    *array = resultArray;
   }
  
  if (freObjectsArray != NULL)
   {
    free(freObjectsArray);
    freObjectsArray = NULL;
    freObjectsArrayLength = 0;
   }
  
  return mnFREResult.freResult;
 }

- (FREResult)getFREObjects:(FREObject**)freObjectsArray 
                    length:(NSUInteger*)freObjectsArrayLength
              fromFREArray:(FREObject)freArray
 {
  FREObject *freObjectsBufferArray = NULL;
  MNFREResult *mnFREResult = [MNFREResult result];
  
  [mnFREResult collectResult:FREGetArrayLength(freArray,freObjectsArrayLength)];

  if ([mnFREResult isResultOk])
   {
    freObjectsBufferArray = calloc(*freObjectsArrayLength,sizeof(FREObject));
    
    NSUInteger index = 0;
    FREObject arrayFREElement = NULL;
    
    while (([mnFREResult isResultOk]) && (index < *freObjectsArrayLength))
     {
      [mnFREResult collectResult:FREGetArrayElementAt(freArray,index,&arrayFREElement)];
      
      if ([mnFREResult isResultOk])
       {
        freObjectsBufferArray[index] = arrayFREElement;
        index++;
       }
     }  
   }

  if (![mnFREResult isResultOk])
   {
    ELog(@"Can not extract FREObject elements from FREArray. FREResult = %@, failed step No: %d",
         FREResultToString([mnFREResult freResult]),
         [mnFREResult failedStepNumber]);
    
    *freObjectsArray = NULL;
    *freObjectsArrayLength = 0;
    free(freObjectsBufferArray);
   }
  else
   {
    *freObjectsArray = freObjectsBufferArray;
   }
  
  return mnFREResult.freResult;
 }

- (FREResult)getArray:(NSArray**)array withElementTypeClass:(Class)elementType fromFREObject:(FREObject)freArray
 {
  MNFREResult *mnFREResult = [MNFREResult result];
  NSMutableArray *resultArray = [NSMutableArray array];
  
  FREObject *freObjectsArray = NULL;
  NSUInteger freObjectsArrayLength = 0;
  
  NSUInteger index = 0;
  id arrayElement = nil;

  [mnFREResult collectResult:[self getFREObjects:&freObjectsArray length:&freObjectsArrayLength fromFREArray:freArray]];
  
  while (([mnFREResult isResultOk]) && (index < freObjectsArrayLength))
   {
    [mnFREResult collectResult:[self getObject:&arrayElement withType:elementType fromFREObject:freObjectsArray[index]]];
    
    if ([mnFREResult isResultOk])
     {
      [resultArray addObject:arrayElement];
      index++;
     }
   }
    
  if (![mnFREResult isResultOk])
   {
    ELog(@"Can not get array of objects of type %s from FREObject. FREResult = %@, failed step No: %d",
         class_getName(elementType),
         FREResultToString([mnFREResult freResult]),
         [mnFREResult failedStepNumber]);
    
    *array = nil;
   }
  else
   {
    *array = resultArray;
   }
  
  if (freObjectsArray != NULL)
   {
    free(freObjectsArray);
    freObjectsArray = NULL;
    freObjectsArrayLength = 0;
   }
  
  return mnFREResult.freResult;
 }

- (FREResult)getDictionary:(NSDictionary**) dictonary withKeyType:(Class)keyType valueType:(Class)valueType fromFREObject:(FREObject)freDictionary
 {
  ELog(@"NOT IMPLEMENTED");
  return FRE_TYPE_MISMATCH;
 }

- (FREResult)getFREObject:(FREObject*) freObject fromObject:(id)object
 {
  MARK;
  MNFREResult *mnFREResult = [MNFREResult result];

  /*if (object == nil)
   {
    *freObject = NULL;
   }
  else*/
  if ([object isKindOfClass:[NSNumber class]])
   {
    if (strcmp([object objCType],@encode(BOOL)) == 0)
     {
      [mnFREResult collectResult:MNFRENewObjectFromBOOL([object boolValue],freObject)];
     }        
    else if (strcmp([object objCType],@encode(int)) == 0)
     {
      [mnFREResult collectResult:MNFRENewObjectFromInt([object intValue],freObject)];
     }
    else if (strcmp([object objCType],@encode(unsigned int)) == 0)
     {
      [mnFREResult collectResult:MNFRENewObjectFromUInt([object unsignedIntValue],freObject)];
     }
    else if (strcmp([object objCType],@encode(long long)) == 0)
     {
      [mnFREResult collectResult:MNFRENewObjectFromLongLong([object longLongValue],freObject)];
     }
    else if (strcmp([object objCType],@encode(double)) == 0)
     {
      [mnFREResult collectResult:MNFRENewObjectFromDouble([object doubleValue],freObject)];
     }
    else
     {
      mnFREResult.freResult = FRE_TYPE_MISMATCH;
      ELog(@"Do not know how to make FREObject from NSNumber of type: %s",[object objCType]);
     }
   }
  else if ([object isKindOfClass:[NSString class]])
   {
    [mnFREResult collectResult:FRENewObjectFromUTF8([object lengthOfBytesUsingEncoding:NSUTF8StringEncoding] + 1,
                                                    (const uint8_t*)[object UTF8String],
                                                    freObject)];
   }
  else if ([object isKindOfClass:[NSArray class]])
   {
    NSArray *srcArray = (NSArray*)object;
    FREObject arrayElement = NULL;
    NSUInteger index = 0;

    [mnFREResult collectResult:ExtWrapperFRENewArray(freObject,[srcArray count])];

    while ((index < [srcArray count]) &&
           ([mnFREResult isResultOk]))
     {
      [mnFREResult collectResult:[self getFREObject:&arrayElement fromObject:[srcArray objectAtIndex:index]]];

      if ([mnFREResult isResultOk])
       {
        [mnFREResult collectResult:FRESetArrayElementAt(*freObject,index,arrayElement)];
        index++;
       }
     }
   }
  else if ([object isKindOfClass:[NSDictionary class]])
   {
    NSDictionary *dictionary = (NSDictionary*)object;
    
    if (dictionary != nil)
     {
      NSMutableArray *dictionaryAsArray = [NSMutableArray arrayWithCapacity:dictionary.count * 2];
      
      for (NSUInteger index = 0;index < [dictionary allKeys].count;index++)
       {
        id key = [[dictionary allKeys] objectAtIndex:index];
        
        [dictionaryAsArray addObject:key];
        [dictionaryAsArray addObject:[dictionary objectForKey:key]];
       }
      
      mnFREResult.freResult = [self getFREObject:freObject fromObject:dictionaryAsArray];
     }
   }
  else if ([object respondsToSelector:@selector(toFREObject:)])
   {
    //warning OK
    [mnFREResult collectResult:(FREResult)[object toFREObject:freObject]];
   }
  else
   {
    mnFREResult.freResult = FRE_TYPE_MISMATCH;
   }

  if (![mnFREResult isResultOk])
   {
    ELog(@"Can not create FREObject from %s. FREResult = %@, failed step No: %d",
         class_getName([object class]),
         FREResultToString(mnFREResult.freResult),
         mnFREResult.failedStepNumber);
   }

  return mnFREResult.freResult;
 }

@end


@implementation MNUserInfo(MNFRETools)
- (FREResult)toFREObject:(FREObject*)toFREObject
 {
  MARK;

  MNFREResult *result = [MNFREResult result];
  BOOL resultOkFlag      = YES;
  FREObject exception    = NULL;

  uint32_t argc = 4;
  FREObject *argv = calloc(argc,sizeof(FREObject));

  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromLongLong(self.userId,&(argv[0]))];
  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromInt(self.userSFId,&(argv[1]))];
  resultOkFlag = resultOkFlag && [result collectResult:[[MNExtWrapperAir freTools]getFREObject:&(argv[2]) fromObject:self.userName]];
  resultOkFlag = resultOkFlag && [result collectResult:[[MNExtWrapperAir freTools]getFREObject:&(argv[3]) fromObject:[self getAvatarUrl]]];

  resultOkFlag = resultOkFlag && [result collectResult:FRENewObject((const uint8_t*)[@"com.playphone.multinet.MNUserInfo" UTF8String],
                                                                    argc,
                                                                    argv,
                                                                    toFREObject,
                                                                    &exception)];



  if (![result isResultOk])
   {
    ELog(@"Can not create FREObject from MNUserInfo. FREResult = %@, failed step No: %d",
         FREResultToString(result.freResult),
         result.failedStepNumber);

    *toFREObject = NULL;
   }

  return [result freResult];
 }

+ (FREResult)getObject:(id*) value fromFREObject:(FREObject) freObject
 {
  MARK;

  MNFREResult *mnFREResult = [MNFREResult result];
  BOOL resultOkFlag        = YES;
  FREObject tempObject     = NULL;
  FREObject exception      = NULL;

  long long userId;
  int userSFId;
  NSString* userName;

  FREObject freString = NULL;
  
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"userId",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFRENumberToString(tempObject,&freString)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFREGetObjectAsLongLong(freString,&userId)];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"userSFId",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFREGetObjectAsInt(tempObject,&userSFId)];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"userName",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&userName withType:[NSString class] fromFREObject:tempObject]];

  if ([mnFREResult isResultOk])
   {
    *value = [[[MNUserInfo alloc]initWithUserId:userId
                                       userSFId:userSFId
                                       userName:userName
                                     webBaseUrl:[[MNDirect getSession]getWebServerURL]]autorelease];
   }
  else
   {
    ELog(@"Can not get object of type MNUserInfo from FREObject. FREResult = %@, failed step No: %d",
         FREResultToString([mnFREResult freResult]),
         [mnFREResult failedStepNumber]);

    *value = nil;
   }

  return [mnFREResult freResult];
 }
@end

@implementation MNGameAchievementInfo(MNFRETools)
- (FREResult)toFREObject:(FREObject*)toFREObject
 {
  MARK;

  MNFREResult *result = [MNFREResult result];
  BOOL resultOkFlag      = YES;
  FREObject exception    = NULL;

  uint32_t argc = 6;

  FREObject *argv = calloc(argc,sizeof(FREObject));

  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromInt(self.achievementId,&(argv[0]))];
  resultOkFlag = resultOkFlag && [result collectResult:[[MNExtWrapperAir freTools]getFREObject:&(argv[1]) fromObject:self.name]];
  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromInt(self.flags,&(argv[2]))];
  resultOkFlag = resultOkFlag && [result collectResult:[[MNExtWrapperAir freTools]getFREObject:&(argv[3]) fromObject:self.description]];
  resultOkFlag = resultOkFlag && [result collectResult:[[MNExtWrapperAir freTools]getFREObject:&(argv[4]) fromObject:self.params]];
  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromInt(self.points,&(argv[5]))];

  resultOkFlag = resultOkFlag && [result collectResult:FRENewObject((const uint8_t*)[@"com.playphone.multinet.providers.GameAchievementInfo" UTF8String],
                                                                    argc,
                                                                    argv,
                                                                    toFREObject,
                                                                    &exception)];



  if (![result isResultOk])
   {
    ELog(@"Can not create FREObject from MNGameAchievementInfo. FREResult = %@, failed step No: %d",
         FREResultToString(result.freResult),
         result.failedStepNumber);

    *toFREObject = NULL;
   }

  return [result freResult];
 }

+ (FREResult)getObject:(id*) value fromFREObject:(FREObject) freObject
 {
  MARK;

  MNFREResult *mnFREResult = [MNFREResult result];
  BOOL resultOkFlag        = YES;
  FREObject tempObject     = NULL;
  FREObject exception      = NULL;

  int achievementId;
  NSString* name;
  int flags;
  NSString* description;
  NSString* params;
  int points;

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"id",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFREGetObjectAsInt(tempObject,&achievementId)];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"name",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&name withType:[NSString class] fromFREObject:tempObject]];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"flags",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFREGetObjectAsInt(tempObject,&flags)];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"description",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&description withType:[NSString class] fromFREObject:tempObject]];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"params",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&params withType:[NSString class] fromFREObject:tempObject]];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"points",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFREGetObjectAsInt(tempObject,&points)];

  if ([mnFREResult isResultOk])
   {
    *value = [[[MNGameAchievementInfo alloc]initWithId:achievementId name:name andFlags:flags]
              autorelease];

    ((MNGameAchievementInfo*)*value).description = description;
    ((MNGameAchievementInfo*)*value).params      = params;
    ((MNGameAchievementInfo*)*value).points      = points;
   }
  else
   {
    ELog(@"Can not get object of type MNUserInfo from FREObject. FREResult = %@, failed step No: %d",
         FREResultToString([mnFREResult freResult]),
         [mnFREResult failedStepNumber]);

    *value = nil;
   }

  return [mnFREResult freResult];
 }
@end

@implementation MNPlayerAchievementInfo(MNFRETools)

- (FREResult)toFREObject:(FREObject*)toFREObject
 {
  MARK;

  MNFREResult *result = [MNFREResult result];
  BOOL resultOkFlag      = YES;
  FREObject exception    = NULL;

  uint32_t argc = 1;

  FREObject *argv = calloc(argc,sizeof(FREObject));

  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromInt(self.achievementId,&(argv[0]))];

  resultOkFlag = resultOkFlag && [result collectResult:FRENewObject((const uint8_t*)[@"com.playphone.multinet.providers.PlayerAchievementInfo" UTF8String],
                                                                    argc,
                                                                    argv,
                                                                    toFREObject,
                                                                    &exception)];



  if (![result isResultOk])
   {
    ELog(@"Can not create FREObject from PlayerAchievementInfo. FREResult = %@, failed step No: %d",
         FREResultToString(result.freResult),
         result.failedStepNumber);

    *toFREObject = NULL;
   }

  return [result freResult];
 }

+ (FREResult)getObject:(id*) value fromFREObject:(FREObject) freObject
 {
  MARK;

  MNFREResult *mnFREResult = [MNFREResult result];
  BOOL resultOkFlag        = YES;
  FREObject tempObject     = NULL;
  FREObject exception      = NULL;

  int achievementId;

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"id",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFREGetObjectAsInt(tempObject,&achievementId)];

  if ([mnFREResult isResultOk])
   {
    *value = [[[MNPlayerAchievementInfo alloc]initWithId:achievementId]
              autorelease];
   }
  else
   {
    ELog(@"Can not get object of type PlayerAchievementInfo from FREObject. FREResult = %@, failed step No: %d",
         FREResultToString([mnFREResult freResult]),
         [mnFREResult failedStepNumber]);

    *value = nil;
   }

  return [mnFREResult freResult];
 }
@end

@implementation MNGameSettingInfo(MNFRETools)
- (FREResult)toFREObject:(FREObject*)toFREObject
{
  MARK;
  
  MNFREResult *result = [MNFREResult result];
  BOOL resultOkFlag      = YES;
  FREObject exception    = NULL;
  
  uint32_t argc = 6;
  
  FREObject *argv = calloc(argc,sizeof(FREObject));
  
  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromInt(self.gameSetId,&(argv[0]))];
  resultOkFlag = resultOkFlag && [result collectResult:[[MNExtWrapperAir freTools]getFREObject:&(argv[1]) fromObject:self.name]];
  resultOkFlag = resultOkFlag && [result collectResult:[[MNExtWrapperAir freTools]getFREObject:&(argv[2]) fromObject:self.params]];
  resultOkFlag = resultOkFlag && [result collectResult:[[MNExtWrapperAir freTools]getFREObject:&(argv[3]) fromObject:self.sysParams]];
  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromBOOL(self.isMultiplayerEnabled,&(argv[4]))];
  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromBOOL(self.isLeaderboardVisible,&(argv[5]))];
  
  resultOkFlag = resultOkFlag && [result collectResult:FRENewObject((const uint8_t*)[@"com.playphone.multinet.providers.GameSettingInfo" UTF8String],
                                                                    argc,
                                                                    argv,
                                                                    toFREObject,
                                                                    &exception)];
  
  
  
  if (![result isResultOk])
   {
    ELog(@"Can not create FREObject from MNGameSettingInfo. FREResult = %@, failed step No: %d",
         FREResultToString(result.freResult),
         result.failedStepNumber);
    
    *toFREObject = NULL;
   }
  
  return [result freResult];
}

@end

@implementation MNGameVItemInfo(MNFRETools)
- (FREResult)toFREObject:(FREObject*)toFREObject
 {
  MARK;

  MNFREResult *result = [MNFREResult result];
  BOOL resultOkFlag      = YES;
  FREObject exception    = NULL;

  uint32_t argc = 5;

  FREObject *argv = calloc(argc,sizeof(FREObject));

  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromInt(self.vItemId,&(argv[0]))];
  resultOkFlag = resultOkFlag && [result collectResult:[[MNExtWrapperAir freTools]getFREObject:&(argv[1]) fromObject:self.name]];
  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromInt(self.model,&(argv[2]))];
  resultOkFlag = resultOkFlag && [result collectResult:[[MNExtWrapperAir freTools]getFREObject:&(argv[3]) fromObject:self.description]];
  resultOkFlag = resultOkFlag && [result collectResult:[[MNExtWrapperAir freTools]getFREObject:&(argv[4]) fromObject:self.params]];

  resultOkFlag = resultOkFlag && [result collectResult:FRENewObject((const uint8_t*)[@"com.playphone.multinet.providers.GameVItemInfo" UTF8String],
                                                                    argc,
                                                                    argv,
                                                                    toFREObject,
                                                                    &exception)];



  if (![result isResultOk])
   {
    ELog(@"Can not create FREObject from MNGameVItemInfo. FREResult = %@, failed step No: %d",
         FREResultToString(result.freResult),
         result.failedStepNumber);

    *toFREObject = NULL;
   }

  return [result freResult];
 }

@end

@implementation MNPlayerVItemInfo(MNFRETools)
- (FREResult)toFREObject:(FREObject*)toFREObject
 {
  MARK;

  MNFREResult *result = [MNFREResult result];
  BOOL resultOkFlag      = YES;
  FREObject exception    = NULL;

  uint32_t argc = 2;

  FREObject *argv = calloc(argc,sizeof(FREObject));

  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromInt(self.vItemId,&(argv[0]))];
  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromLongLong(self.count,&(argv[1]))];

  resultOkFlag = resultOkFlag && [result collectResult:FRENewObject((const uint8_t*)[@"com.playphone.multinet.providers.PlayerVItemInfo" UTF8String],
                                                                    argc,
                                                                    argv,
                                                                    toFREObject,
                                                                    &exception)];



  if (![result isResultOk])
   {
    ELog(@"Can not create FREObject from MNPlayerVItemInfo. FREResult = %@, failed step No: %d",
         FREResultToString(result.freResult),
         result.failedStepNumber);

    *toFREObject = NULL;
   }

  return [result freResult];
 }

@end
#import "MNVShopProvider.h"
@implementation MNVShopPackInfo(MNFRETools)
- (FREResult)toFREObject:(FREObject*)toFREObject
{
  MARK;
  
  MNFREResult *result = [MNFREResult result];
  BOOL resultOkFlag      = YES;
  FREObject exception    = NULL;
  
  uint32_t argc = 10;
  
  FREObject *argv = calloc(argc,sizeof(FREObject));
  
  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromInt(self.packId,&(argv[0]))];
  resultOkFlag = resultOkFlag && [result collectResult:[[MNExtWrapperAir freTools]getFREObject:&(argv[1]) fromObject:self.name]];
  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromInt(self.model,&(argv[2]))];
  resultOkFlag = resultOkFlag && [result collectResult:[[MNExtWrapperAir freTools]getFREObject:&(argv[3]) fromObject:self.description]];
  resultOkFlag = resultOkFlag && [result collectResult:[[MNExtWrapperAir freTools]getFREObject:&(argv[4]) fromObject:self.appParams]];
  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromInt(self.sortPos,&(argv[5]))];
  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromInt(self.categoryId,&(argv[6]))];
  resultOkFlag = resultOkFlag && [result collectResult:[[MNExtWrapperAir freTools]getFREObject:&(argv[7]) fromObject:self.delivery]];
  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromInt(self.priceItemId,&(argv[8]))];
  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromLongLong(self.priceValue,&(argv[9]))];
  
  resultOkFlag = resultOkFlag && [result collectResult:FRENewObject((const uint8_t*)[@"com.playphone.multinet.providers.VShopPackInfo" UTF8String],
                                                                    argc,
                                                                    argv,
                                                                    toFREObject,
                                                                    &exception)];
  
  
  
  if (![result isResultOk])
   {
    ELog(@"Can not create FREObject from MNVShopPackInfo. FREResult = %@, failed step No: %d",
         FREResultToString(result.freResult),
         result.failedStepNumber);
    
    *toFREObject = NULL;
   }
  
  return [result freResult];
}

@end

@implementation MNVShopCategoryInfo(MNFRETools)
- (FREResult)toFREObject:(FREObject*)toFREObject
{
  MARK;
  
  MNFREResult *result = [MNFREResult result];
  BOOL resultOkFlag      = YES;
  FREObject exception    = NULL;
  
  uint32_t argc = 3;
  
  FREObject *argv = calloc(argc,sizeof(FREObject));
  
  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromInt(self.categoryId,&(argv[0]))];
  resultOkFlag = resultOkFlag && [result collectResult:[[MNExtWrapperAir freTools]getFREObject:&(argv[1]) fromObject:self.name]];
  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromInt(self.sortPos,&(argv[2]))];
  
  resultOkFlag = resultOkFlag && [result collectResult:FRENewObject((const uint8_t*)[@"com.playphone.multinet.providers.VShopCategoryInfo" UTF8String],
                                                                    argc,
                                                                    argv,
                                                                    toFREObject,
                                                                    &exception)];
  
  
  
  if (![result isResultOk])
   {
    ELog(@"Can not create FREObject from MNVShopCategoryInfo. FREResult = %@, failed step No: %d",
         FREResultToString(result.freResult),
         result.failedStepNumber);
    
    *toFREObject = NULL;
   }
  
  return [result freResult];
}

@end

@implementation MNVShopDeliveryInfo(MNFRETools)
- (FREResult)toFREObject:(FREObject*)toFREObject
{
  MARK;
  
  MNFREResult *result = [MNFREResult result];
  BOOL resultOkFlag      = YES;
  FREObject exception    = NULL;
  
  uint32_t argc = 2;
  
  FREObject *argv = calloc(argc,sizeof(FREObject));
  
  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromInt(self.vItemId,&(argv[0]))];
  resultOkFlag = resultOkFlag && [result collectResult:MNFRENewObjectFromLongLong(self.amount,&(argv[1]))];
  
  resultOkFlag = resultOkFlag && [result collectResult:FRENewObject((const uint8_t*)[@"com.playphone.multinet.providers.VShopDeliveryInfo" UTF8String],
                                                                    argc,
                                                                    argv,
                                                                    toFREObject,
                                                                    &exception)];
  
  
  
  if (![result isResultOk])
   {
    ELog(@"Can not create FREObject from MNVShopDeliveryInfo. FREResult = %@, failed step No: %d",
         FREResultToString(result.freResult),
         result.failedStepNumber);
    
    *toFREObject = NULL;
   }
  
  return [result freResult];
}

@end

@implementation MNJoinRoomInvitationParams(MNFRETools)
+ (FREResult)getObject:(id*) value fromFREObject:(FREObject) freObject
{
  MARK;

  MNFREResult *mnFREResult = [MNFREResult result];
  BOOL resultOkFlag        = YES;
  FREObject tempObject     = NULL;
  FREObject exception      = NULL;

  int fromUserSFId;
  NSString* fromUserName;
  int roomSFId;
  NSString* roomName;
  int roomGameId;
  int roomGameSetId;
  NSString* inviteText;

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"fromUserSFId",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFREGetObjectAsInt(tempObject,&fromUserSFId)];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"fromUserName",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&fromUserName withType:[NSString class] fromFREObject:tempObject]];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"roomSFId",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFREGetObjectAsInt(tempObject,&roomSFId)];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"roomName",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&roomName withType:[NSString class] fromFREObject:tempObject]];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"roomGameId",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFREGetObjectAsInt(tempObject,&roomGameId)];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"roomGameSetId",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFREGetObjectAsInt(tempObject,&roomGameSetId)];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"inviteText",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&inviteText withType:[NSString class] fromFREObject:tempObject]];

  if ([mnFREResult isResultOk])
   {
    *value = [[[MNJoinRoomInvitationParams alloc]init]
              autorelease];
    ((MNJoinRoomInvitationParams*)*value).fromUserSFId = fromUserSFId;
    ((MNJoinRoomInvitationParams*)*value).fromUserName = fromUserName;
    ((MNJoinRoomInvitationParams*)*value).roomSFId = roomSFId;
    ((MNJoinRoomInvitationParams*)*value).roomName = roomName;
    ((MNJoinRoomInvitationParams*)*value).roomGameId = roomGameId;
    ((MNJoinRoomInvitationParams*)*value).roomGameSetId = roomGameSetId;
    ((MNJoinRoomInvitationParams*)*value).inviteText = inviteText;
   }
  else
   {
    ELog(@"Can not get object of type MNJoinRoomInvitationParams from FREObject. FREResult = %@, failed step No: %d",
         FREResultToString([mnFREResult freResult]),
         [mnFREResult failedStepNumber]);

    *value = nil;
   }

  return [mnFREResult freResult];
}
@end

@implementation MNBuddyRoomParams(MNFRETools)
+ (FREResult)getObject:(id*) value fromFREObject:(FREObject) freObject
{
  MARK;

  MNFREResult *mnFREResult = [MNFREResult result];
  BOOL resultOkFlag        = YES;
  FREObject tempObject     = NULL;
  FREObject exception      = NULL;

  NSString* roomName;
  int gameSetId;
  NSString* toUserIdList;
  NSString* toUserSFIdList;
  NSString* inviteText;

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"roomName",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&roomName withType:[NSString class] fromFREObject:tempObject]];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"gameSetId",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFREGetObjectAsInt(tempObject,&gameSetId)];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"toUserIdList",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&toUserIdList withType:[NSString class] fromFREObject:tempObject]];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"toUserSFIdList",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&toUserSFIdList withType:[NSString class] fromFREObject:tempObject]];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"inviteText",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&inviteText withType:[NSString class] fromFREObject:tempObject]];

  if ([mnFREResult isResultOk])
   {
    *value = [[[MNBuddyRoomParams alloc]init]
              autorelease];
    ((MNBuddyRoomParams*)*value).roomName = roomName;
    ((MNBuddyRoomParams*)*value).gameSetId = gameSetId;
    ((MNBuddyRoomParams*)*value).toUserIdList = toUserIdList;
    ((MNBuddyRoomParams*)*value).toUserSFIdList = toUserSFIdList;
    ((MNBuddyRoomParams*)*value).inviteText = inviteText;
   }
  else
   {
    ELog(@"Can not get object of type MNBuddyRoomParams from FREObject. FREResult = %@, failed step No: %d",
         FREResultToString([mnFREResult freResult]),
         [mnFREResult failedStepNumber]);

    *value = nil;
   }

  return [mnFREResult freResult];
}
@end

@implementation MNGameParams(MNFRETools)
+ (FREResult)getObject:(id*) value fromFREObject:(FREObject) freObject
{
  MARK;

  MNFREResult *mnFREResult = [MNFREResult result];
  BOOL resultOkFlag        = YES;
  FREObject tempObject     = NULL;
  FREObject exception      = NULL;

  int gameSetId;
  NSString* gameSetParams;
  NSString* scorePostLinkId;
  int gameSeed;
  int playModel;

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"gameSetId",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFREGetObjectAsInt(tempObject,&gameSetId)];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"gameSetParams",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&gameSetParams withType:[NSString class] fromFREObject:tempObject]];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"scorePostLinkId",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&scorePostLinkId withType:[NSString class] fromFREObject:tempObject]];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"gameSeed",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFREGetObjectAsInt(tempObject,&gameSeed)];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"playModel",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFREGetObjectAsInt(tempObject,&playModel)];

  if ([mnFREResult isResultOk])
   {
    *value = [[[MNGameParams alloc]initWithGameSetId:gameSetId gameSetParams:gameSetParams scorePostLinkId:scorePostLinkId gameSeed:gameSeed playModel:playModel]
              autorelease];
   }
  else
   {
    ELog(@"Can not get object of type MNGameParams from FREObject. FREResult = %@, failed step No: %d",
         FREResultToString([mnFREResult freResult]),
         [mnFREResult failedStepNumber]);

    *value = nil;
   }

  return [mnFREResult freResult];
}
@end

@implementation MNGameResult(MNFRETools)
+ (FREResult)getObject:(id*) value fromFREObject:(FREObject) freObject
{
  MARK;

  MNFREResult *mnFREResult = [MNFREResult result];
  BOOL resultOkFlag        = YES;
  FREObject tempObject     = NULL;
  FREObject exception      = NULL;

  long long score;
  NSString* scorePostLinkId;
  int gameSetId;

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"score",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFREGetObjectAsLongLong(tempObject,&score)];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"scorePostLinkId",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&scorePostLinkId withType:[NSString class] fromFREObject:tempObject]];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"gameSetId",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFREGetObjectAsInt(tempObject,&gameSetId)];

  if ([mnFREResult isResultOk])
   {
    *value = [[[MNGameResult alloc]init]
              autorelease];

    ((MNGameResult*)*value).score = score;
    ((MNGameResult*)*value).scorePostLinkId = scorePostLinkId;
    ((MNGameResult*)*value).gameSetId = gameSetId;
   }
  else
   {
    ELog(@"Can not get object of type MNGameResult from FREObject. FREResult = %@, failed step No: %d",
         FREResultToString([mnFREResult freResult]),
         [mnFREResult failedStepNumber]);

    *value = nil;
   }

  return [mnFREResult freResult];
}
@end

@implementation MNAppBeaconResponse(MNFRETools)
+ (FREResult)getObject:(id*) value fromFREObject:(FREObject) freObject
{
  MARK;

  MNFREResult *mnFREResult = [MNFREResult result];
  BOOL resultOkFlag        = YES;
  FREObject tempObject     = NULL;
  FREObject exception      = NULL;

  NSString* responseText;
  int callSeqNumber;

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"responseText",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&responseText withType:[NSString class] fromFREObject:tempObject]];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"callSeqNumber",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFREGetObjectAsInt(tempObject,&callSeqNumber)];


  if ([mnFREResult isResultOk])
   {
    *value = [[[MNAppBeaconResponse alloc]init]
              autorelease];

    ((MNAppBeaconResponse*)*value).responseText = responseText;
    ((MNAppBeaconResponse*)*value).callSeqNumber = callSeqNumber;
   }
  else
   {
    ELog(@"Can not get object of type MNAppBeaconResponse from FREObject. FREResult = %@, failed step No: %d",
         FREResultToString([mnFREResult freResult]),
         [mnFREResult failedStepNumber]);

    *value = nil;
   }

  return [mnFREResult freResult];
}
@end

@implementation MNTransactionVItemInfo(MNFRETools)
+ (FREResult)getObject:(id*) value fromFREObject:(FREObject) freObject
 {
  MARK;

  MNFREResult *mnFREResult = [MNFREResult result];
  BOOL resultOkFlag        = YES;
  FREObject tempObject     = NULL;
  FREObject exception      = NULL;

  long long delta;
  int vItemId;

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"delta",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFREGetObjectAsLongLong(tempObject,&delta)];

  resultOkFlag = resultOkFlag && [mnFREResult collectResult:FREGetObjectProperty(freObject,(const uint8_t*)"id",&tempObject,&exception)];
  resultOkFlag = resultOkFlag && [mnFREResult collectResult:MNFREGetObjectAsInt(tempObject,&vItemId)];

  if ([mnFREResult isResultOk])
   {
    *value = [[[MNTransactionVItemInfo alloc]initWithId:vItemId andDelta:delta]
                                 autorelease];
   }
  else
   {
    ELog(@"Can not get object of type MNTransactionVItemInfo from FREObject. FREResult = %@, failed step No: %d",
         FREResultToString([mnFREResult freResult]),
         [mnFREResult failedStepNumber]);

    *value = nil;
   }

  return [mnFREResult freResult];
 }
@end
