//
//  MNPlayerListProviderAir.m
//  MultiNet Extension Wrapper Air
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "FlashRuntimeExtensions.h"
#import "MNExtWrapperDefs.h"
#import "MNExtWrapperAir.h"
#import "MNFRETools.h"

#import "MNDirect.h"
#import "MNPlayerListProvider.h"

#import "MNExtWrapperEventDispatcherAir.h"
#import "MNPlayerListProviderExtDelegate.h"


EXTERN_C FREObject MNPlayerListProvider_getPlayerList(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  NSArray *result;
  result = [[MNDirect playerListProvider] getPlayerList];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = [[MNExtWrapperAir freTools]getFREObject:&freObjectResult fromObject:result];

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from MNUserInfo[]");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNPlayerListProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  return NULL;
 }

static BOOL eventHandlerAdded = NO;

EXTERN_C FREObject MNPlayerListProvider_addEventHandler(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  if (!eventHandlerAdded)
   {
    eventHandlerAdded = YES;
    [[MNDirect playerListProvider] addDelegate:[[MNPlayerListProviderExtDelegate alloc]initWithDispatcher:[MNExtWrapperEventDispatcherAir shared]]];
   }

  return NULL;
 }

