//
//  MNClientRobotsProviderAir.m
//  MultiNet Extension Wrapper Air
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "FlashRuntimeExtensions.h"
#import "MNExtWrapperDefs.h"
#import "MNExtWrapperAir.h"
#import "MNFRETools.h"

#import "MNDirect.h"
#import "MNClientRobotsProvider.h"


EXTERN_C FREObject MNClientRobotsProvider_shutdown(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  return NULL;
 }

EXTERN_C FREObject MNClientRobotsProvider_isRobot(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  MNUserInfo* userInfo;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&userInfo withType:[MNUserInfo class] fromFREObject:argv[0]]];
   }

  if (!argResult)
   {
    return NULL;
   }

  BOOL result;
  result = [[MNDirect clientRobotsProvider] isRobot:userInfo];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNClientRobotsProvider_postRobotScore(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  MNUserInfo* userInfo;
  long long score;

  if (argc >= 2)
   {
    argResult = argResult && [mnFREResult collectResult:[[MNExtWrapperAir freTools]getObject:&userInfo withType:[MNUserInfo class] fromFREObject:argv[0]]];
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsLongLong(argv[1],&score)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect clientRobotsProvider] postRobot:userInfo score:score];

  return NULL;
 }

EXTERN_C FREObject MNClientRobotsProvider_setRoomRobotLimit(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int robotCount;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&robotCount)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [[MNDirect clientRobotsProvider] setRoomRobotLimit:robotCount];

  return NULL;
 }

EXTERN_C FREObject MNClientRobotsProvider_getRoomRobotLimit(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  int result;
  result = [[MNDirect clientRobotsProvider] getRoomRobotLimit];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromInt(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from int");
   }

  return freObjectResult;
 }

