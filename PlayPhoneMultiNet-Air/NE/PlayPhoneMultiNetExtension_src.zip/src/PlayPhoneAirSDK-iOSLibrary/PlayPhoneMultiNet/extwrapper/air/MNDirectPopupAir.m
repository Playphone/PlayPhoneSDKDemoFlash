//
//  MNDirectPopupAir.m
//  MultiNet Extension Wrapper Air
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "FlashRuntimeExtensions.h"
#import "MNExtWrapperDefs.h"
#import "MNExtWrapperAir.h"
#import "MNFRETools.h"

#import "MNDirect.h"
#import "MNDirectPopup.h"


EXTERN_C FREObject MNDirectPopup_init(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  int actionsBitMask;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsInt(argv[0],&actionsBitMask)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [MNDirectPopup init:actionsBitMask];

  return NULL;
 }

EXTERN_C FREObject MNDirectPopup_isActive(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  BOOL result;
  result = [MNDirectPopup isActive];

  FREObject freObjectResult = NULL;
  FREResult returnFREResult = MNFRENewObjectFromBOOL(result,&freObjectResult);

  if (returnFREResult != FRE_OK)
   {
    ELog(@"Can not create FREObject from BOOL");
   }

  return freObjectResult;
 }

EXTERN_C FREObject MNDirectPopup_setActive(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
 {
  MARK;

  bool argResult = true;
  MNFREResult *mnFREResult = [MNFREResult result];
  BOOL activeFlag;

  if (argc >= 1)
   {
    argResult = argResult && [mnFREResult collectResult:MNFREGetObjectAsBOOL(argv[0],&activeFlag)];
   }

  if (!argResult)
   {
    return NULL;
   }

  [MNDirectPopup setActive:activeFlag];

  return NULL;
 }

