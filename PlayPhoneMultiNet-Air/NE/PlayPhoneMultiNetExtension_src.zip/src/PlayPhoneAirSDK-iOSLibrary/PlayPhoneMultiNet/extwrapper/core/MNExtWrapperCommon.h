//
//  MNExtWrapperCommon.h
//  MultiNet Extension Wrapper
//
//  Created by Vladislav Ogol on 7/13/12.
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MNExtWrapperDefs.h"

@protocol MNSerializer <NSObject>

- (NSString*)serialize:(id)object;
- (NSString*)serializeDicitionaryToArray:(NSDictionary*)dictionary;
- (id)deserialize:(Class)classType fromJson:(NSString*)jsonString;
- (NSArray*)deserializeArray:(Class)elementType fromJson:(NSString*)jsonString;

- (NSString*)formatKey:(NSString*)key;

@end

@interface MNExtWrapperCommon : NSObject

+ (void)setWrapperPlatform:(MNExtWrapperPlatform)wrapperPlatform;
+ (MNExtWrapperPlatform)wrapperPlatform;

+ (id<MNSerializer>)serializer;

@end
