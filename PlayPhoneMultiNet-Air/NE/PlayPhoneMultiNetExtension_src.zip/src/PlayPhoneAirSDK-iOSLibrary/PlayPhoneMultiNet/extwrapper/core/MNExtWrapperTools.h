//
//  MNExtWrapperTools.h
//  MultiNet Extension Wrapper
//
//  Created by Vladislav Ogol on 03.08.12.
//  Copyright (c) 2012 PlayPhone.h. All rights reserved.
//

NSString* GetCapitalizedString(NSString *word);
NSString* GetDecapitalizedString(NSString *word);
