//
//  MNExtWrapperCommon.m
//  MultiNet Extension Wrapper
//
//  Created by Vladislav Ogol on 7/13/12.
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "MNJsonSerializer.h"

#import "MNExtWrapperCommon.h"

static id<MNSerializer> MNExtWrapperSerializerShared = nil;
static MNExtWrapperPlatform MNExtWrapperPlatformShared = MNExtWrapperPlatformUndefinded;
@implementation MNExtWrapperCommon

+ (void)setWrapperPlatform:(MNExtWrapperPlatform)wrapperPlatform
 {
  MNExtWrapperPlatformShared = wrapperPlatform;
 }

+ (MNExtWrapperPlatform)wrapperPlatform
 {
  return MNExtWrapperPlatformShared;
 }

+ (id<MNSerializer>)serializer
 {
  if (MNExtWrapperSerializerShared == nil)
   {
    MNExtWrapperSerializerShared  =[[MNJsonSerializer alloc]init];
   }
  
  return MNExtWrapperSerializerShared;
 }

@end
