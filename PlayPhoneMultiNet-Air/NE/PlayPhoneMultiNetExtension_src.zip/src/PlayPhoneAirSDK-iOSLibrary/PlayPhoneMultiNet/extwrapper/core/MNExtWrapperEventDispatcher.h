//
//  MNExtWrapperEventDispatcher.h
//  MultiNet Extension Wrapper
//
//  Created by Vladislav Ogol on 7/13/12.
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

@protocol MNExtWrapperEventDispatcher <NSObject>
/**
 * Impementaton should dispatch event in a way specific for target platform
 * @param eventName  - event name
 * @param params     - event params (can be nil or wmpty if no params passed to event
 * @param paramNames - names of params (can be nil if names are not used for transferring params to wrapped system)
 */
- (void)dispatchEvent:(NSString *)eventName withParams:(NSArray*) params andParamsNames:(NSArray*)paramNames;
@end
