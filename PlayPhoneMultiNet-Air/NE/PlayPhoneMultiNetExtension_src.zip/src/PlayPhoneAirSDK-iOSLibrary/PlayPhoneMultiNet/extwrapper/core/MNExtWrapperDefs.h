//
//  MNExtWrapperDefs.h
//  MultiNet Extension Wrapper
//
//  Created by Vladislav Ogol on 04.07.12.
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#ifndef PlayPhoneAirWrapper_MNDefs_h
#define PlayPhoneAirWrapper_MNDefs_h

typedef enum
 {
  MNExtWrapperPlatformUndefinded,
  MNExtWrapperPlatformUnity,
  MNExtWrapperPlatformAir   
 } MNExtWrapperPlatform;

#ifdef __cplusplus
#define EXTERN_C  extern "C"
#else
#define EXTERN_C  extern
#endif


#define MN_DEBUG

#ifdef MN_DEBUG
#define DLog(format,...) NSLog(@"MNUW:ObjC:[%s] " format, __PRETTY_FUNCTION__, ##__VA_ARGS__)
#else
#define DLog(format,...)
#endif

#define ILog(format,...) NSLog(@"MNUW:ObjC:INFO:[%s] " format, __PRETTY_FUNCTION__, ##__VA_ARGS__)
#define ELog(format,...) NSLog(@"MNUW:ObjC:ERROR:[%s] " format, __PRETTY_FUNCTION__, ##__VA_ARGS__)

#define MARK DLog(@"")

#endif
