//
//  MNJsonSerializer.m
//  MultiNet Extension Wrapper
//
//  Created by Vladislav Ogol on 25.01.12.
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import <objc/runtime.h>

#import "JSON.h"

#import "MNExtWrapperDefs.h"
#import "MNExtWrapperTools.h"

#import "MNDirect.h"
#import "MNErrorInfo.h"
#import "MNGameParams.h"
#import "MNUserInfo.h"

#import "MNAchievementsProvider.h"
#import "MNVItemsProvider.h"
#import "MNVShopProvider.h"
#import "MNGameSettingsProvider.h"
#import "MNScoreProgressProvider.h"

#import "MNSession.h"

#import "MNWSProvider.h"
#import "MNWSAnyGameItem.h"
#import "MNWSAnyUserItem.h"
#import "MNWSUserGameCookie.h"
#import "MNWSCurrentUserInfo.h"
#import "MNWSRoomListItem.h"
#import "MNWSRoomUserInfoItem.h"
#import "MNWSBuddyListItem.h"
#import "MNWSCurrUserSubscriptionStatus.h"
#import "MNWSSessionSignedClientToken.h"
#import "MNWSSystemGameNetStats.h"
#import "MNWSLeaderboardListItem.h"

#import "MNBuddyRoomParams.h"
#import "MNJoinRoomInvitationParams.h"

#import "MNJsonSerializer.h"

@interface MNJsonSerializer()

@property (retain, nonatomic) SBJSON *jsonSerializer;

@end

@implementation MNJsonSerializer

@synthesize jsonSerializer = _jsonSerializer;

- (NSString*)formatKey:(NSString*)key {
    NSString *resultKey = nil;
    
    if ([MNExtWrapperCommon wrapperPlatform] == MNExtWrapperPlatformUnity) {
        resultKey = GetCapitalizedString(key);
    }
    else if ([MNExtWrapperCommon wrapperPlatform] == MNExtWrapperPlatformAir) {
        resultKey = GetDecapitalizedString(key);
    }
    else {
        DLog(@"Unknown wrapper platform");
        resultKey = key;
    }
    
    return resultKey;
}

- (id)init {
    if (self = [super init]) {
        self.jsonSerializer = [[[SBJSON alloc]init]autorelease];
    }
    
    return self;
}

- (void)dealloc {
    self.jsonSerializer = nil;
    
    [super dealloc];
}

- (NSString*)serialize:(id)object {
    NSError *_lastError = nil;
    
    if (object == nil) {
        object = [NSNull null];
    }
    
    NSString *jsonString = [self.jsonSerializer stringWithObject:object error:&_lastError];
    
    if ([_lastError code] == EFRAGMENT) {
        DLog(@"Serialization Error = EFRAGMENT, try to pack value in array");
        // May be it's a boxed primitive type or null. If so, serialize it as array of one element.
        jsonString = [self.jsonSerializer stringWithObject:[NSArray arrayWithObject:object] error:&_lastError];
    }

    DLog(@"Serialization result: %@",jsonString == nil?@"<nil>":jsonString);
    
    return jsonString;
}

- (NSString*)serializeDicitionaryToArray:(NSDictionary*)dictionary {
    NSMutableArray *dictArray = [NSMutableArray arrayWithCapacity:[dictionary count]];
    NSEnumerator *enumerator = [dictionary keyEnumerator];
    id key;
    
    while ((key = [enumerator nextObject])) {
        [dictArray addObject:key];
        [dictArray addObject:[dictionary objectForKey:key]];
    }

    return [self serialize:dictArray];
}

- (id)deserialize:(Class)classType fromJson:(NSString*)jsonString {
    if ([classType respondsToSelector:@selector(fromJson:)]) {
        return [classType fromJson:jsonString];
    }
    else {
        ELog(@"Deserialization error. Class: %s",class_getName(classType));
    }
    
    return nil;
}

- (NSArray*)deserializeArray:(Class)elementType fromJson:(NSString*)jsonString {
    NSError *_lastError = nil;

    DLog(@"Deserialize Array of %s",class_getName(elementType));
    
    NSMutableArray *resultArray = nil;
    
    if (([elementType isSubclassOfClass:[NSNumber class]]) || ([elementType isSubclassOfClass:[NSString class]])) {
        resultArray = [self.jsonSerializer objectWithString:jsonString error:&_lastError];
    }
    else {
        NSArray *rawArray = [self.jsonSerializer objectWithString:jsonString error:&_lastError];
        resultArray = [NSMutableArray arrayWithCapacity:[rawArray count]];
        
        for (NSDictionary *dict in rawArray) {
            if ([elementType respondsToSelector:@selector(fromDictionary:)]) {
                [resultArray addObject:[elementType fromDictionary:dict]];
            }
            else {
                ELog(@"Array Deserialization error. Elemets type: %s",class_getName(elementType));
                break;
            }
        }
    }
    
    return resultArray;
}

@end

#pragma mark - JSON Serializers

@implementation MNErrorInfo(MNUnity)

- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:2];
    
    id localErrorMessage = self.errorMessage;
    [fieldsDict setObject:(localErrorMessage == nil) ? [NSNull null] : localErrorMessage forKey:[[MNExtWrapperCommon serializer] formatKey:@"ErrorMessage"]];
    
    id localActionCode = [NSNumber numberWithInt:self.actionCode];
    [fieldsDict setObject:(localActionCode == nil) ? [NSNull null] : localActionCode forKey:[[MNExtWrapperCommon serializer] formatKey:@"ActionCode"]];
    
    
    return fieldsDict;
}
+ (id)fromDictionary:(NSDictionary*)fieldsDict {
    MNErrorInfo *object = [[[MNErrorInfo alloc]initWithActionCode:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"ActionCode"]]).intValue
                                                  andErrorMessage:[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"ErrorMessage"]]]autorelease];
    
    return object;
}
+ (id)fromJson:(NSString*)jsonString {
    NSDictionary *fieldsDict = [[[[SBJsonParser alloc]init]autorelease]objectWithString:jsonString];
    
    return [MNErrorInfo fromDictionary:fieldsDict];
}

@end

@implementation MNGameParams(MNUnity)

- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:6];
    
    id localPlayModel = [NSNumber numberWithInt:self.playModel];
    [fieldsDict setObject:(localPlayModel == nil) ? [NSNull null] : localPlayModel forKey:[[MNExtWrapperCommon serializer] formatKey:@"PlayModel"]];
    
    id localGameSeed = [NSNumber numberWithInt:self.gameSeed];
    [fieldsDict setObject:(localGameSeed == nil) ? [NSNull null] : localGameSeed forKey:[[MNExtWrapperCommon serializer] formatKey:@"GameSeed"]];
    
    id localGameSetParams = self.gameSetParams;
    [fieldsDict setObject:(localGameSetParams == nil) ? [NSNull null] : localGameSetParams forKey:[[MNExtWrapperCommon serializer] formatKey:@"GameSetParams"]];
    
    id localScorePostLinkId = self.scorePostLinkId;
    [fieldsDict setObject:(localScorePostLinkId == nil) ? [NSNull null] : localScorePostLinkId forKey:[[MNExtWrapperCommon serializer] formatKey:@"ScorePostLinkId"]];
    
    id localGameSetId = [NSNumber numberWithInt:self.gameSetId];
    [fieldsDict setObject:(localGameSetId == nil) ? [NSNull null] : localGameSetId forKey:[[MNExtWrapperCommon serializer] formatKey:@"GameSetId"]];
    
    
    return fieldsDict;
}
+ (id)fromDictionary:(NSDictionary*)fieldsDict {
    MNGameParams *object = [[[MNGameParams alloc]initWithGameSetId:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"GameSetId"]]).intValue
                                                     gameSetParams:[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"GameSetParams"]]
                                                   scorePostLinkId:[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"ScorePostLinkId"]]
                                                          gameSeed:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"GameSeed"]]).intValue
                                                         playModel:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"PlayModel"]]).intValue]autorelease];

    return object;
}
+ (id)fromJson:(NSString*)jsonString {
    NSDictionary *fieldsDict = [[[[SBJsonParser alloc]init]autorelease]objectWithString:jsonString];
    
    return [MNGameParams fromDictionary:fieldsDict];
}

@end

@implementation MNUserInfo(MNUnity)

- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:3];
    
    id localUserId = [NSNumber numberWithLongLong:self.userId];
    [fieldsDict setObject:(localUserId == nil) ? [NSNull null] : localUserId forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserId"]];
    
    id localUserName = self.userName;
    [fieldsDict setObject:(localUserName == nil) ? [NSNull null] : localUserName forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserName"]];
    
    id localUserSFId = [NSNumber numberWithInt:self.userSFId];
    [fieldsDict setObject:(localUserSFId == nil) ? [NSNull null] : localUserSFId forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserSFId"]];

    id localUserAvatarUrl = [self getAvatarUrl];
    [fieldsDict setObject:(localUserAvatarUrl == nil) ? [NSNull null] : localUserAvatarUrl forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserAvatarUrl"]];
        
    return fieldsDict;
}
+ (id)fromDictionary:(NSDictionary*)fieldsDict {
    MNUserInfo *userInfo = [[[MNUserInfo alloc]initWithUserId:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"UserId"]  ]).longLongValue 
                                                     userSFId:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"UserSFId"]]).intValue
                                                     userName:[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"UserName"]]
                                                   webBaseUrl:[[MNDirect getSession]getWebServerURL]]autorelease];
    
    return userInfo;
}
+ (id)fromJson:(NSString*)jsonString {
    NSDictionary *fieldsDict = [[[[SBJsonParser alloc]init]autorelease]objectWithString:jsonString];
    
    return [MNUserInfo fromDictionary:fieldsDict];
}

@end

@implementation MNGameAchievementInfo(MNUnity)

- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:6];
    
    id localFlags = [NSNumber numberWithInt:self.flags];
    [fieldsDict setObject:(localFlags == nil) ? [NSNull null] : localFlags forKey:[[MNExtWrapperCommon serializer] formatKey:@"Flags"]];
    
    id localName = self.name;
    [fieldsDict setObject:(localName == nil) ? [NSNull null] : localName forKey:[[MNExtWrapperCommon serializer] formatKey:@"Name"]];
    
    id localPoints = [NSNumber numberWithInt:self.points];
    [fieldsDict setObject:(localPoints == nil) ? [NSNull null] : localPoints forKey:[[MNExtWrapperCommon serializer] formatKey:@"Points"]];
    
    id localDescription = self.description;
    [fieldsDict setObject:(localDescription == nil) ? [NSNull null] : localDescription forKey:[[MNExtWrapperCommon serializer] formatKey:@"Description"]];
    
    id localParams = self.params;
    [fieldsDict setObject:(localParams == nil) ? [NSNull null] : localParams forKey:[[MNExtWrapperCommon serializer] formatKey:@"Params"]];
    
    id localId = [NSNumber numberWithInt:self.achievementId];
    [fieldsDict setObject:(localId == nil) ? [NSNull null] : localId forKey:[[MNExtWrapperCommon serializer] formatKey:@"Id"]];
    
    
    return fieldsDict;
}
+ (id)fromDictionary:(NSDictionary*)fieldsDict {
    MNGameAchievementInfo *object = [[[MNGameAchievementInfo alloc]initWithId:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Id"]]).intValue
                                                                         name:[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Name"]]
                                                                     andFlags:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Flags"]]).intValue]autorelease];
    
    object.points = ((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Points"]]).intValue;
    object.description = [fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Description"]];
    object.params = [fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Params"]];
    
    return object;
}
+ (id)fromJson:(NSString*)jsonString {
    NSDictionary *fieldsDict = [[[[SBJsonParser alloc]init]autorelease]objectWithString:jsonString];
    
    return [MNGameAchievementInfo fromDictionary:fieldsDict];
}

@end

@implementation MNPlayerAchievementInfo(MNUnity)

- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:1];
    
    id localId = [NSNumber numberWithInt:self.achievementId];
    [fieldsDict setObject:(localId == nil) ? [NSNull null] : localId forKey:[[MNExtWrapperCommon serializer] formatKey:@"Id"]];
    
    
    return fieldsDict;
}
+ (id)fromDictionary:(NSDictionary*)fieldsDict {
    MNPlayerAchievementInfo *object = [[[MNPlayerAchievementInfo alloc]initWithId:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Id"]]).intValue]autorelease];
    
    return object;
}
+ (id)fromJson:(NSString*)jsonString {
    NSDictionary *fieldsDict = [[[[SBJsonParser alloc]init]autorelease]objectWithString:jsonString];
    
    return [MNPlayerAchievementInfo fromDictionary:fieldsDict];
}

@end

@implementation MNGameVItemInfo(MNUnity)

- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:5];
    
    id localModel = [NSNumber numberWithInt:self.model];
    [fieldsDict setObject:(localModel == nil) ? [NSNull null] : localModel forKey:[[MNExtWrapperCommon serializer] formatKey:@"Model"]];
    
    id localName = self.name;
    [fieldsDict setObject:(localName == nil) ? [NSNull null] : localName forKey:[[MNExtWrapperCommon serializer] formatKey:@"Name"]];
    
    id localDescription = self.description;
    [fieldsDict setObject:(localDescription == nil) ? [NSNull null] : localDescription forKey:[[MNExtWrapperCommon serializer] formatKey:@"Description"]];
    
    id localParams = self.params;
    [fieldsDict setObject:(localParams == nil) ? [NSNull null] : localParams forKey:[[MNExtWrapperCommon serializer] formatKey:@"Params"]];
    
    id localId = [NSNumber numberWithInt:self.vItemId];
    [fieldsDict setObject:(localId == nil) ? [NSNull null] : localId forKey:[[MNExtWrapperCommon serializer] formatKey:@"Id"]];
    
    
    return fieldsDict;
}
+ (id)fromDictionary:(NSDictionary*)fieldsDict {
    MNGameVItemInfo *object = [[[MNGameVItemInfo alloc]initWithId:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Id"]]).intValue
                                                             name:[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Name"]]
                                                         andModel:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Model"]]).intValue]autorelease];
    
    object.description = [fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Description"]];
    object.params = [fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Params"]];

    return object;
}
+ (id)fromJson:(NSString*)jsonString {
    NSDictionary *fieldsDict = [[[[SBJsonParser alloc]init]autorelease]objectWithString:jsonString];
    
    return [MNGameVItemInfo fromDictionary:fieldsDict];
}

@end

@implementation MNPlayerVItemInfo(MNUnity)

- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:2];
    
    id localCount = [NSNumber numberWithLongLong:self.count];
    [fieldsDict setObject:(localCount == nil) ? [NSNull null] : localCount forKey:[[MNExtWrapperCommon serializer] formatKey:@"Count"]];
    
    id localId = [NSNumber numberWithInt:self.vItemId];
    [fieldsDict setObject:(localId == nil) ? [NSNull null] : localId forKey:[[MNExtWrapperCommon serializer] formatKey:@"Id"]];
    
    
    return fieldsDict;
}
+ (id)fromDictionary:(NSDictionary*)fieldsDict {
    MNPlayerVItemInfo *object = [[[MNPlayerVItemInfo alloc]initWithId:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Id"]]).intValue
                                                             andCount:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Count"]]).longLongValue]autorelease];
    
    return object;
}
+ (id)fromJson:(NSString*)jsonString {
    NSDictionary *fieldsDict = [[[[SBJsonParser alloc]init]autorelease]objectWithString:jsonString];
    
    return [MNPlayerVItemInfo fromDictionary:fieldsDict];
}

@end

@implementation MNTransactionVItemInfo(MNUnity)

- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:2];
    
    id localDelta = [NSNumber numberWithLongLong:self.delta];
    [fieldsDict setObject:(localDelta == nil) ? [NSNull null] : localDelta forKey:[[MNExtWrapperCommon serializer] formatKey:@"Delta"]];
    
    id localId = [NSNumber numberWithInt:self.vItemId];
    [fieldsDict setObject:(localId == nil) ? [NSNull null] : localId forKey:[[MNExtWrapperCommon serializer] formatKey:@"Id"]];
    
    
    return fieldsDict;
}
+ (id)fromDictionary:(NSDictionary*)fieldsDict {
    MNTransactionVItemInfo *object = [[[MNTransactionVItemInfo alloc]initWithId:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Id"]]).intValue
                                                                       andDelta:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Delta"]]).longLongValue]autorelease];
    
    return object;
}
+ (id)fromJson:(NSString*)jsonString {
    NSDictionary *fieldsDict = [[[[SBJsonParser alloc]init]autorelease]objectWithString:jsonString];
    
    return [MNTransactionVItemInfo fromDictionary:fieldsDict];
}

@end

@implementation MNVItemsTransactionInfo(MNUnity)

- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:4];
    
    id localCorrUserId = [NSNumber numberWithLongLong:self.corrUserId];
    [fieldsDict setObject:(localCorrUserId == nil) ? [NSNull null] : localCorrUserId forKey:[[MNExtWrapperCommon serializer] formatKey:@"CorrUserId"]];
    
    id localVItems = self.transactionVItems;
    [fieldsDict setObject:(localVItems == nil) ? [NSNull null] : localVItems forKey:[[MNExtWrapperCommon serializer] formatKey:@"VItems"]];
    
    id localServerTransactionId = [NSNumber numberWithLongLong:self.serverTransactionId];
    [fieldsDict setObject:(localServerTransactionId == nil) ? [NSNull null] : localServerTransactionId forKey:[[MNExtWrapperCommon serializer] formatKey:@"ServerTransactionId"]];
    
    id localClientTransactionId = [NSNumber numberWithLongLong:self.clientTransactionId];
    [fieldsDict setObject:(localClientTransactionId == nil) ? [NSNull null] : localClientTransactionId forKey:[[MNExtWrapperCommon serializer] formatKey:@"ClientTransactionId"]];
    
    
    return fieldsDict;
}
+ (id)fromDictionary:(NSDictionary*)fieldsDict {
    NSArray *vItemsJsonArray = [fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"VItems"]];
    NSMutableArray *vItems = [NSMutableArray arrayWithCapacity:[vItemsJsonArray count]];
    
    for (NSDictionary *vItemDictionary in vItemsJsonArray) {
        MNTransactionVItemInfo *vItemInfo = [[[MNTransactionVItemInfo alloc]initWithId:((NSNumber*)[vItemDictionary objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Id"]]).intValue
                                                                             andDelta:((NSNumber*)[vItemDictionary objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Delta"]]).longLongValue]autorelease];

        [vItems addObject:vItemInfo];
    }
    
    MNVItemsTransactionInfo *object = [[[MNVItemsTransactionInfo alloc]initWithClientTransactionId:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"ClientTransactionId"]]).longLongValue
                                                                               serverTransactionId:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"ServerTransactionId"]]).longLongValue
                                                                                        corrUserId:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"CorrUserId"]]).longLongValue
                                                                                         andVItems:vItems]autorelease];
    
    return object;
}
+ (id)fromJson:(NSString*)jsonString {
    NSDictionary *fieldsDict = [[[[SBJsonParser alloc]init]autorelease]objectWithString:jsonString];
    
    return [MNVItemsTransactionInfo fromDictionary:fieldsDict];
}

@end

@implementation MNVItemsTransactionError(MNUnity)

- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:5];
    
    id localCorrUserId = [NSNumber numberWithLongLong:self.corrUserId];
    [fieldsDict setObject:(localCorrUserId == nil) ? [NSNull null] : localCorrUserId forKey:[[MNExtWrapperCommon serializer] formatKey:@"CorrUserId"]];
    
    id localErrorMessage = self.errorMessage;
    [fieldsDict setObject:(localErrorMessage == nil) ? [NSNull null] : localErrorMessage forKey:[[MNExtWrapperCommon serializer] formatKey:@"ErrorMessage"]];
    
    id localFailReasonCode = [NSNumber numberWithInt:self.failReasonCode];
    [fieldsDict setObject:(localFailReasonCode == nil) ? [NSNull null] : localFailReasonCode forKey:[[MNExtWrapperCommon serializer] formatKey:@"FailReasonCode"]];
    
    id localServerTransactionId = [NSNumber numberWithLongLong:self.serverTransactionId];
    [fieldsDict setObject:(localServerTransactionId == nil) ? [NSNull null] : localServerTransactionId forKey:[[MNExtWrapperCommon serializer] formatKey:@"ServerTransactionId"]];
    
    id localClientTransactionId = [NSNumber numberWithLongLong:self.clientTransactionId];
    [fieldsDict setObject:(localClientTransactionId == nil) ? [NSNull null] : localClientTransactionId forKey:[[MNExtWrapperCommon serializer] formatKey:@"ClientTransactionId"]];
    
    
    return fieldsDict;
}
+ (id)fromDictionary:(NSDictionary*)fieldsDict {
    MNVItemsTransactionError *object = [[[MNVItemsTransactionError alloc]initWithClientTransactionId:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"ClientTransactionId"]]).longLongValue
                                                                                 serverTransactionId:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"ServerTransactionId"]]).longLongValue
                                                                                          corrUserId:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"CorrUserId"]]).longLongValue
                                                                                      failReasonCode:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"FailReasonCode"]]).intValue
                                                                                     andErrorMessage:[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"ErrorMessage"]]]autorelease];
    
    return object;
}
+ (id)fromJson:(NSString*)jsonString {
    NSDictionary *fieldsDict = [[[[SBJsonParser alloc]init]autorelease]objectWithString:jsonString];
    
    return [MNVItemsTransactionError fromDictionary:fieldsDict];
}

@end

@implementation MNVShopDeliveryInfo(MNUnity)

- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:2];
    
    id localAmount = [NSNumber numberWithLongLong:self.amount];
    [fieldsDict setObject:(localAmount == nil) ? [NSNull null] : localAmount forKey:[[MNExtWrapperCommon serializer] formatKey:@"Amount"]];
    
    id localVItemId = [NSNumber numberWithInt:self.vItemId];
    [fieldsDict setObject:(localVItemId == nil) ? [NSNull null] : localVItemId forKey:[[MNExtWrapperCommon serializer] formatKey:@"VItemId"]];
    
    
    return fieldsDict;
}
+ (id)fromDictionary:(NSDictionary*)fieldsDict {
    MNVShopDeliveryInfo *object = [[[MNVShopDeliveryInfo alloc]initWithVItemId:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"VItemId"]]).intValue
                                                                     andAmount:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Amount"]]).longLongValue]autorelease];
    
    return object;
}
+ (id)fromJson:(NSString*)jsonString {
    NSDictionary *fieldsDict = [[[[SBJsonParser alloc]init]autorelease]objectWithString:jsonString];
    
    return [MNVShopDeliveryInfo fromDictionary:fieldsDict];
}

@end

@implementation MNVShopPackInfo(MNUnity)

- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:10];
    
    id localAppParams = self.appParams;
    [fieldsDict setObject:(localAppParams == nil) ? [NSNull null] : localAppParams forKey:[[MNExtWrapperCommon serializer] formatKey:@"AppParams"]];
    
    id localName = self.name;
    [fieldsDict setObject:(localName == nil) ? [NSNull null] : localName forKey:[[MNExtWrapperCommon serializer] formatKey:@"Name"]];
    
    id localId = [NSNumber numberWithInt:self.packId];
    [fieldsDict setObject:(localId == nil) ? [NSNull null] : localId forKey:[[MNExtWrapperCommon serializer] formatKey:@"Id"]];
    
    id localDelivery = self.delivery;
    [fieldsDict setObject:(localDelivery == nil) ? [NSNull null] : localDelivery forKey:[[MNExtWrapperCommon serializer] formatKey:@"Delivery"]];
    
    id localSortPos = [NSNumber numberWithInt:self.sortPos];
    [fieldsDict setObject:(localSortPos == nil) ? [NSNull null] : localSortPos forKey:[[MNExtWrapperCommon serializer] formatKey:@"SortPos"]];
    
    id localCategoryId = [NSNumber numberWithInt:self.categoryId];
    [fieldsDict setObject:(localCategoryId == nil) ? [NSNull null] : localCategoryId forKey:[[MNExtWrapperCommon serializer] formatKey:@"CategoryId"]];
    
    id localModel = [NSNumber numberWithInt:self.model];
    [fieldsDict setObject:(localModel == nil) ? [NSNull null] : localModel forKey:[[MNExtWrapperCommon serializer] formatKey:@"Model"]];
    
    id localPriceValue = [NSNumber numberWithLongLong:self.priceValue];
    [fieldsDict setObject:(localPriceValue == nil) ? [NSNull null] : localPriceValue forKey:[[MNExtWrapperCommon serializer] formatKey:@"PriceValue"]];
    
    id localPriceItemId = [NSNumber numberWithInt:self.priceItemId];
    [fieldsDict setObject:(localPriceItemId == nil) ? [NSNull null] : localPriceItemId forKey:[[MNExtWrapperCommon serializer] formatKey:@"PriceItemId"]];
    
    id localDescription = self.description;
    [fieldsDict setObject:(localDescription == nil) ? [NSNull null] : localDescription forKey:[[MNExtWrapperCommon serializer] formatKey:@"Description"]];
    
    
    return fieldsDict;
}
+ (id)fromDictionary:(NSDictionary*)fieldsDict {
    MNVShopPackInfo *object = [[[MNVShopPackInfo alloc]initWithId:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Id"]]).intValue
                                                         andName:[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Name"]]]autorelease];
    
    object.appParams = [fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"AppParams"]];
    object.delivery = [fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Delivery"]];
    object.sortPos = ((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"SortPos"]]).intValue;
    object.categoryId = ((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"CategoryId"]]).intValue;
    object.model = ((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Model"]]).intValue;
    object.priceValue = ((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"PriceValue"]]).longLongValue;
    object.priceItemId = ((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"PriceItemId"]]).intValue;
    object.description = [fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Description"]];
    
    return object;
}
+ (id)fromJson:(NSString*)jsonString {
    NSDictionary *fieldsDict = [[[[SBJsonParser alloc]init]autorelease]objectWithString:jsonString];
    
    return [MNVShopPackInfo fromDictionary:fieldsDict];
}

@end

@implementation MNVShopCategoryInfo(MNUnity)

- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:3];
    
    id localName = self.name;
    [fieldsDict setObject:(localName == nil) ? [NSNull null] : localName forKey:[[MNExtWrapperCommon serializer] formatKey:@"Name"]];
    
    id localSortPos = [NSNumber numberWithInt:self.sortPos];
    [fieldsDict setObject:(localSortPos == nil) ? [NSNull null] : localSortPos forKey:[[MNExtWrapperCommon serializer] formatKey:@"SortPos"]];
    
    id localId = [NSNumber numberWithInt:self.categoryId];
    [fieldsDict setObject:(localId == nil) ? [NSNull null] : localId forKey:[[MNExtWrapperCommon serializer] formatKey:@"Id"]];
    
    
    return fieldsDict;
}
+ (id)fromDictionary:(NSDictionary*)fieldsDict {
    MNVShopCategoryInfo *object = [[[MNVShopCategoryInfo alloc]initWithId:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Id"]]).intValue
                                                                  andName:[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Name"]]]autorelease];

    object.sortPos = ((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"SortPos"]]).intValue;
    
    return object;
}
+ (id)fromJson:(NSString*)jsonString {
    NSDictionary *fieldsDict = [[[[SBJsonParser alloc]init]autorelease]objectWithString:jsonString];
    
    return [MNVShopCategoryInfo fromDictionary:fieldsDict];
}

@end

@implementation MNVShopProviderCheckoutVShopPackSuccessInfo(MNUnity)

- (id)proxyForJson {
 NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:1];
 
 id localTransaction = self.transaction;
 [fieldsDict setObject:(localTransaction == nil) ? [NSNull null] : localTransaction forKey:[[MNExtWrapperCommon serializer] formatKey:@"Transaction"]];
 
 
 return fieldsDict;
}
+ (id)fromDictionary:(NSDictionary*)fieldsDict {
 MNVShopProviderCheckoutVShopPackSuccessInfo *object = [[[MNVShopProviderCheckoutVShopPackSuccessInfo alloc]initWithTransactionInfo:[MNVItemsTransactionInfo fromDictionary:[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Transaction"]]]]autorelease];
 
 return object;
}
+ (id)fromJson:(NSString*)jsonString {
 NSDictionary *fieldsDict = [[[[SBJsonParser alloc]init]autorelease]objectWithString:jsonString];
 
 return [MNVShopProviderCheckoutVShopPackSuccessInfo fromDictionary:fieldsDict];
}

@end

@implementation MNVShopProviderCheckoutVShopPackFailInfo(MNUnity)

- (id)proxyForJson {
 NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:3];
 
 id localErrorMessage = self.errorMessage;
 [fieldsDict setObject:(localErrorMessage == nil) ? [NSNull null] : localErrorMessage forKey:[[MNExtWrapperCommon serializer] formatKey:@"ErrorMessage"]];
 
 id localClientTransactionId = [NSNumber numberWithLongLong:self.clientTransactionId];
 [fieldsDict setObject:(localClientTransactionId == nil) ? [NSNull null] : localClientTransactionId forKey:[[MNExtWrapperCommon serializer] formatKey:@"ClientTransactionId"]];
 
 id localErrorCode = [NSNumber numberWithInt:self.errorCode];
 [fieldsDict setObject:(localErrorCode == nil) ? [NSNull null] : localErrorCode forKey:[[MNExtWrapperCommon serializer] formatKey:@"ErrorCode"]];
 
 
 return fieldsDict;
}
+ (id)fromDictionary:(NSDictionary*)fieldsDict {
 MNVShopProviderCheckoutVShopPackFailInfo *object = [[[MNVShopProviderCheckoutVShopPackFailInfo alloc]initWithErrorCode:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"ErrorCode"]]).intValue
                                                                                                           errorMessage:[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"ErrorMessage"]]
                                                                                                 andClientTransactionId:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"ClientTransactionId"]]).longLongValue]autorelease];
 
 return object;
}
+ (id)fromJson:(NSString*)jsonString {
 NSDictionary *fieldsDict = [[[[SBJsonParser alloc]init]autorelease]objectWithString:jsonString];
 
 return [MNVShopProviderCheckoutVShopPackFailInfo fromDictionary:fieldsDict];
}

@end

@implementation MNGameSettingInfo(MNUnity)

- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:4];
    
    id localSysParams = self.sysParams;
    [fieldsDict setObject:(localSysParams == nil) ? [NSNull null] : localSysParams forKey:[[MNExtWrapperCommon serializer] formatKey:@"SysParams"]];
    
    id localName = self.name;
    [fieldsDict setObject:(localName == nil) ? [NSNull null] : localName forKey:[[MNExtWrapperCommon serializer] formatKey:@"Name"]];
    
    id localParams = self.params;
    [fieldsDict setObject:(localParams == nil) ? [NSNull null] : localParams forKey:[[MNExtWrapperCommon serializer] formatKey:@"Params"]];
    
    id localId = [NSNumber numberWithInt:self.gameSetId];
    [fieldsDict setObject:(localId == nil) ? [NSNull null] : localId forKey:[[MNExtWrapperCommon serializer] formatKey:@"Id"]];
    
    
    return fieldsDict;
}
+ (id)fromDictionary:(NSDictionary*)fieldsDict {
    MNGameSettingInfo *object = [[[MNGameSettingInfo alloc]initWithId:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Id"]]).intValue
                                                              andName:[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Name"]]]autorelease];

    object.sysParams = [fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"SysParams"]];
    object.params = [fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Params"]];
    object.isMultiplayerEnabled = ((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"MultiplayerEnabled"]]).boolValue;
    object.isLeaderboardVisible = ((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"LeaderboardVisible"]]).boolValue;
    
    return object;
}
+ (id)fromJson:(NSString*)jsonString {
    NSDictionary *fieldsDict = [[[[SBJsonParser alloc]init]autorelease]objectWithString:jsonString];
    
    return [MNGameSettingInfo fromDictionary:fieldsDict];
}

@end

@implementation MNWSInfoRequestResult(MNUnity)
- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:3];
    
    [fieldsDict setObject:[NSNumber numberWithBool:[self hadError]]  forKey:[[MNExtWrapperCommon serializer] formatKey:@"HadError"]];
    
    id localErrorMessage = [self getErrorMessage];
    [fieldsDict setObject:(localErrorMessage == nil) ? [NSNull null] : localErrorMessage forKey:[[MNExtWrapperCommon serializer] formatKey:@"ErrorMessage"]];
    
    id localDataEntry = [(id)self getDataEntry];
    [fieldsDict setObject:(localDataEntry == nil) ? [NSNull null] : localDataEntry forKey:[[MNExtWrapperCommon serializer] formatKey:@"DataEntry"]];
    
    return fieldsDict;
}
@end

@implementation MNWSAnyGameItem(MNUnity)
- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:9];
    
    id localGameStatus = [self getGameStatus];
    [fieldsDict setObject:(localGameStatus == nil) ? [NSNull null] : localGameStatus forKey:[[MNExtWrapperCommon serializer] formatKey:@"GameStatus"]];
    
    id localGameGenreId = [self getGameGenreId];
    [fieldsDict setObject:(localGameGenreId == nil) ? [NSNull null] : localGameGenreId forKey:[[MNExtWrapperCommon serializer] formatKey:@"GameGenreId"]];
    
    id localGameFlags = [self getGameFlags];
    [fieldsDict setObject:(localGameFlags == nil) ? [NSNull null] : localGameFlags forKey:[[MNExtWrapperCommon serializer] formatKey:@"GameFlags"]];
    
    id localGameName = [self getGameName];
    [fieldsDict setObject:(localGameName == nil) ? [NSNull null] : localGameName forKey:[[MNExtWrapperCommon serializer] formatKey:@"GameName"]];
    
    id localGameIconUrl = [self getGameIconUrl];
    [fieldsDict setObject:(localGameIconUrl == nil) ? [NSNull null] : localGameIconUrl forKey:[[MNExtWrapperCommon serializer] formatKey:@"GameIconUrl"]];
    
    id localGamePlayModel = [self getGamePlayModel];
    [fieldsDict setObject:(localGamePlayModel == nil) ? [NSNull null] : localGamePlayModel forKey:[[MNExtWrapperCommon serializer] formatKey:@"GamePlayModel"]];
    
    id localDeveloperId = [self getDeveloperId];
    [fieldsDict setObject:(localDeveloperId == nil) ? [NSNull null] : localDeveloperId forKey:[[MNExtWrapperCommon serializer] formatKey:@"DeveloperId"]];
    
    id localGameDesc = [self getGameDesc];
    [fieldsDict setObject:(localGameDesc == nil) ? [NSNull null] : localGameDesc forKey:[[MNExtWrapperCommon serializer] formatKey:@"GameDesc"]];
    
    id localGameId = [self getGameId];
    [fieldsDict setObject:(localGameId == nil) ? [NSNull null] : localGameId forKey:[[MNExtWrapperCommon serializer] formatKey:@"GameId"]];
    
    
    return fieldsDict;
}
@end

@implementation MNWSAnyUserItem(MNUnity)
- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:7];
    
    id localMyFriendLinkStatus = [self getMyFriendLinkStatus];
    [fieldsDict setObject:(localMyFriendLinkStatus == nil) ? [NSNull null] : localMyFriendLinkStatus forKey:[[MNExtWrapperCommon serializer] formatKey:@"MyFriendLinkStatus"]];
    
    id localUserGamePoints = [self getUserGamePoints];
    [fieldsDict setObject:(localUserGamePoints == nil) ? [NSNull null] : localUserGamePoints forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserGamePoints"]];
    
    id localUserId = [self getUserId];
    [fieldsDict setObject:(localUserId == nil) ? [NSNull null] : localUserId forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserId"]];
    
    id localUserAvatarExists = [self getUserAvatarExists];
    [fieldsDict setObject:(localUserAvatarExists == nil) ? [NSNull null] : localUserAvatarExists forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserAvatarExists"]];
    
    id localUserOnlineNow = [self getUserOnlineNow];
    [fieldsDict setObject:(localUserOnlineNow == nil) ? [NSNull null] : localUserOnlineNow forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserOnlineNow"]];
    
    id localUserAvatarUrl = [self getUserAvatarUrl];
    [fieldsDict setObject:(localUserAvatarUrl == nil) ? [NSNull null] : localUserAvatarUrl forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserAvatarUrl"]];
    
    id localUserNickName = [self getUserNickName];
    [fieldsDict setObject:(localUserNickName == nil) ? [NSNull null] : localUserNickName forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserNickName"]];
    
    
    return fieldsDict;
}
@end

@implementation MNWSUserGameCookie(MNUnity)
- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:3];
    
    id localUserId = [self getUserId];
    [fieldsDict setObject:(localUserId == nil) ? [NSNull null] : localUserId forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserId"]];
    
    id localCookieValue = [self getCookieValue];
    [fieldsDict setObject:(localCookieValue == nil) ? [NSNull null] : localCookieValue forKey:[[MNExtWrapperCommon serializer] formatKey:@"CookieValue"]];
    
    id localCookieKey = [self getCookieKey];
    //DLog(@"localCookieKey = %@", localCookieKey == nil ? @"nil" : [localCookieKey stringValue]);
    [fieldsDict setObject:(localCookieKey == nil) ? [NSNull null] : localCookieKey forKey:[[MNExtWrapperCommon serializer] formatKey:@"CookieKey"]];
    
    
    return fieldsDict;
}
@end

@implementation MNWSCurrentUserInfo(MNUnity)
- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:10];
    
    id localUserAvatarHasExternalUrl = [self getUserAvatarHasExternalUrl];
    [fieldsDict setObject:(localUserAvatarHasExternalUrl == nil) ? [NSNull null] : localUserAvatarHasExternalUrl forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserAvatarHasExternalUrl"]];
    
    id localUserAvatarUrl = [self getUserAvatarUrl];
    [fieldsDict setObject:(localUserAvatarUrl == nil) ? [NSNull null] : localUserAvatarUrl forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserAvatarUrl"]];
    
    id localUserStatus = [self getUserStatus];
    [fieldsDict setObject:(localUserStatus == nil) ? [NSNull null] : localUserStatus forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserStatus"]];
    
    id localUserGamePoints = [self getUserGamePoints];
    [fieldsDict setObject:(localUserGamePoints == nil) ? [NSNull null] : localUserGamePoints forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserGamePoints"]];
    
    id localUserEmail = [self getUserEmail];
    [fieldsDict setObject:(localUserEmail == nil) ? [NSNull null] : localUserEmail forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserEmail"]];
    
    id localUserOnlineNow = [self getUserOnlineNow];
    [fieldsDict setObject:(localUserOnlineNow == nil) ? [NSNull null] : localUserOnlineNow forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserOnlineNow"]];
    
    id localUserAvatarExists = [self getUserAvatarExists];
    [fieldsDict setObject:(localUserAvatarExists == nil) ? [NSNull null] : localUserAvatarExists forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserAvatarExists"]];
    
    id localUserId = [self getUserId];
    [fieldsDict setObject:(localUserId == nil) ? [NSNull null] : localUserId forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserId"]];
    
    id localUserNickName = [self getUserNickName];
    [fieldsDict setObject:(localUserNickName == nil) ? [NSNull null] : localUserNickName forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserNickName"]];
    
    id localUserAvatarHasCustomImg = [self getUserAvatarHasCustomImg];
    [fieldsDict setObject:(localUserAvatarHasCustomImg == nil) ? [NSNull null] : localUserAvatarHasCustomImg forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserAvatarHasCustomImg"]];
    
    
    return fieldsDict;
}
@end

@implementation MNWSRoomListItem(MNUnity)
- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:6];
    
    id localRoomName = [self getRoomName];
    [fieldsDict setObject:(localRoomName == nil) ? [NSNull null] : localRoomName forKey:[[MNExtWrapperCommon serializer] formatKey:@"RoomName"]];
    
    id localRoomSFId = [self getRoomSFId];
    [fieldsDict setObject:(localRoomSFId == nil) ? [NSNull null] : localRoomSFId forKey:[[MNExtWrapperCommon serializer] formatKey:@"RoomSFId"]];
    
    id localGameId = [self getGameId];
    [fieldsDict setObject:(localGameId == nil) ? [NSNull null] : localGameId forKey:[[MNExtWrapperCommon serializer] formatKey:@"GameId"]];
    
    id localRoomUserCount = [self getRoomUserCount];
    [fieldsDict setObject:(localRoomUserCount == nil) ? [NSNull null] : localRoomUserCount forKey:[[MNExtWrapperCommon serializer] formatKey:@"RoomUserCount"]];
    
    id localGameSetId = [self getGameSetId];
    [fieldsDict setObject:(localGameSetId == nil) ? [NSNull null] : localGameSetId forKey:[[MNExtWrapperCommon serializer] formatKey:@"GameSetId"]];
    
    id localRoomIsLobby = [self getRoomIsLobby];
    [fieldsDict setObject:(localRoomIsLobby == nil) ? [NSNull null] : localRoomIsLobby forKey:[[MNExtWrapperCommon serializer] formatKey:@"RoomIsLobby"]];
    
    
    return fieldsDict;
}
@end

@implementation MNWSRoomUserInfoItem(MNUnity)
- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:6];
    
    id localRoomSFId = [self getRoomSFId];
    [fieldsDict setObject:(localRoomSFId == nil) ? [NSNull null] : localRoomSFId forKey:[[MNExtWrapperCommon serializer] formatKey:@"RoomSFId"]];
    
    id localUserId = [self getUserId];
    [fieldsDict setObject:(localUserId == nil) ? [NSNull null] : localUserId forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserId"]];
    
    id localUserAvatarExists = [self getUserAvatarExists];
    [fieldsDict setObject:(localUserAvatarExists == nil) ? [NSNull null] : localUserAvatarExists forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserAvatarExists"]];
    
    id localUserOnlineNow = [self getUserOnlineNow];
    [fieldsDict setObject:(localUserOnlineNow == nil) ? [NSNull null] : localUserOnlineNow forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserOnlineNow"]];
    
    id localUserAvatarUrl = [self getUserAvatarUrl];
    [fieldsDict setObject:(localUserAvatarUrl == nil) ? [NSNull null] : localUserAvatarUrl forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserAvatarUrl"]];
    
    id localUserNickName = [self getUserNickName];
    [fieldsDict setObject:(localUserNickName == nil) ? [NSNull null] : localUserNickName forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserNickName"]];
    
    
    return fieldsDict;
}
@end

@implementation MNWSBuddyListItem(MNUnity)
- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:19];
    
    id localFriendSnId = [self getFriendSnId];
    [fieldsDict setObject:(localFriendSnId == nil) ? [NSNull null] : localFriendSnId forKey:[[MNExtWrapperCommon serializer] formatKey:@"FriendSnId"]];
    
    id localFriendHasCurrentGame = [self getFriendHasCurrentGame];
    [fieldsDict setObject:(localFriendHasCurrentGame == nil) ? [NSNull null] : localFriendHasCurrentGame forKey:[[MNExtWrapperCommon serializer] formatKey:@"FriendHasCurrentGame"]];
    
    id localFriendSnUserAsnId = [self getFriendSnUserAsnId];
    [fieldsDict setObject:(localFriendSnUserAsnId == nil) ? [NSNull null] : localFriendSnUserAsnId forKey:[[MNExtWrapperCommon serializer] formatKey:@"FriendSnUserAsnId"]];
    
    id localFriendInGameId = [self getFriendInGameId];
    [fieldsDict setObject:(localFriendInGameId == nil) ? [NSNull null] : localFriendInGameId forKey:[[MNExtWrapperCommon serializer] formatKey:@"FriendInGameId"]];
    
    id localFriendSnUserAsnIdList = [self getFriendSnUserAsnIdList];
    [fieldsDict setObject:(localFriendSnUserAsnIdList == nil) ? [NSNull null] : localFriendSnUserAsnIdList forKey:[[MNExtWrapperCommon serializer] formatKey:@"FriendSnUserAsnIdList"]];
    
    id localFriendUserAvatarUrl = [self getFriendUserAvatarUrl];
    [fieldsDict setObject:(localFriendUserAvatarUrl == nil) ? [NSNull null] : localFriendUserAvatarUrl forKey:[[MNExtWrapperCommon serializer] formatKey:@"FriendUserAvatarUrl"]];
    
    id localFriendUserOnlineNow = [self getFriendUserOnlineNow];
    [fieldsDict setObject:(localFriendUserOnlineNow == nil) ? [NSNull null] : localFriendUserOnlineNow forKey:[[MNExtWrapperCommon serializer] formatKey:@"FriendUserOnlineNow"]];
    
    id localFriendIsIgnored = [self getFriendIsIgnored];
    [fieldsDict setObject:(localFriendIsIgnored == nil) ? [NSNull null] : localFriendIsIgnored forKey:[[MNExtWrapperCommon serializer] formatKey:@"FriendIsIgnored"]];
    
    id localFriendFlags = [self getFriendFlags];
    [fieldsDict setObject:(localFriendFlags == nil) ? [NSNull null] : localFriendFlags forKey:[[MNExtWrapperCommon serializer] formatKey:@"FriendFlags"]];
    
    id localFriendCurrGameAchievementsList = [self getFriendCurrGameAchievementsList];
    [fieldsDict setObject:(localFriendCurrGameAchievementsList == nil) ? [NSNull null] : localFriendCurrGameAchievementsList forKey:[[MNExtWrapperCommon serializer] formatKey:@"FriendCurrGameAchievementsList"]];
    
    id localFriendInGameName = [self getFriendInGameName];
    [fieldsDict setObject:(localFriendInGameName == nil) ? [NSNull null] : localFriendInGameName forKey:[[MNExtWrapperCommon serializer] formatKey:@"FriendInGameName"]];
    
    id localFriendUserLocale = [self getFriendUserLocale];
    [fieldsDict setObject:(localFriendUserLocale == nil) ? [NSNull null] : localFriendUserLocale forKey:[[MNExtWrapperCommon serializer] formatKey:@"FriendUserLocale"]];
    
    id localFriendSnIdList = [self getFriendSnIdList];
    [fieldsDict setObject:(localFriendSnIdList == nil) ? [NSNull null] : localFriendSnIdList forKey:[[MNExtWrapperCommon serializer] formatKey:@"FriendSnIdList"]];
    
    id localFriendUserId = [self getFriendUserId];
    [fieldsDict setObject:(localFriendUserId == nil) ? [NSNull null] : localFriendUserId forKey:[[MNExtWrapperCommon serializer] formatKey:@"FriendUserId"]];
    
    id localFriendInRoomIsLobby = [self getFriendInRoomIsLobby];
    [fieldsDict setObject:(localFriendInRoomIsLobby == nil) ? [NSNull null] : localFriendInRoomIsLobby forKey:[[MNExtWrapperCommon serializer] formatKey:@"FriendInRoomIsLobby"]];
    
    id localFriendUserSfid = [self getFriendUserSfid];
    [fieldsDict setObject:(localFriendUserSfid == nil) ? [NSNull null] : localFriendUserSfid forKey:[[MNExtWrapperCommon serializer] formatKey:@"FriendUserSfid"]];
    
    id localFriendUserNickName = [self getFriendUserNickName];
    [fieldsDict setObject:(localFriendUserNickName == nil) ? [NSNull null] : localFriendUserNickName forKey:[[MNExtWrapperCommon serializer] formatKey:@"FriendUserNickName"]];
    
    id localFriendInGameIconUrl = [self getFriendInGameIconUrl];
    [fieldsDict setObject:(localFriendInGameIconUrl == nil) ? [NSNull null] : localFriendInGameIconUrl forKey:[[MNExtWrapperCommon serializer] formatKey:@"FriendInGameIconUrl"]];
    
    id localFriendInRoomSfid = [self getFriendInRoomSfid];
    [fieldsDict setObject:(localFriendInRoomSfid == nil) ? [NSNull null] : localFriendInRoomSfid forKey:[[MNExtWrapperCommon serializer] formatKey:@"FriendInRoomSfid"]];
    
    
    return fieldsDict;
}
@end

@implementation MNWSCurrUserSubscriptionStatus(MNUnity)
- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:3];
    
    id localOffersAvailable = [self getOffersAvailable];
    [fieldsDict setObject:(localOffersAvailable == nil) ? [NSNull null] : localOffersAvailable forKey:[[MNExtWrapperCommon serializer] formatKey:@"OffersAvailable"]];
    
    id localHasSubscription = [self getHasSubscription];
    [fieldsDict setObject:(localHasSubscription == nil) ? [NSNull null] : localHasSubscription forKey:[[MNExtWrapperCommon serializer] formatKey:@"HasSubscription"]];
    
    id localIsSubscriptionAvailable = [self getIsSubscriptionAvailable];
    [fieldsDict setObject:(localIsSubscriptionAvailable == nil) ? [NSNull null] : localIsSubscriptionAvailable forKey:[[MNExtWrapperCommon serializer] formatKey:@"IsSubscriptionAvailable"]];
    
    
    return fieldsDict;
}
@end

@implementation MNWSSessionSignedClientToken(MNUnity)
- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:2];
    
    id localClientTokenBody = [self getClientTokenBody];
    [fieldsDict setObject:(localClientTokenBody == nil) ? [NSNull null] : localClientTokenBody forKey:[[MNExtWrapperCommon serializer] formatKey:@"ClientTokenBody"]];
    
    id localClientTokenSign = [self getClientTokenSign];
    [fieldsDict setObject:(localClientTokenSign == nil) ? [NSNull null] : localClientTokenSign forKey:[[MNExtWrapperCommon serializer] formatKey:@"ClientTokenSign"]];
    
    
    return fieldsDict;
}
@end

@implementation MNWSSystemGameNetStats(MNUnity)
- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:7];
    
    id localGameOnlineRooms = [self getGameOnlineRooms];
    [fieldsDict setObject:(localGameOnlineRooms == nil) ? [NSNull null] : localGameOnlineRooms forKey:[[MNExtWrapperCommon serializer] formatKey:@"GameOnlineRooms"]];
    
    id localGameOnlineUsers = [self getGameOnlineUsers];
    [fieldsDict setObject:(localGameOnlineUsers == nil) ? [NSNull null] : localGameOnlineUsers forKey:[[MNExtWrapperCommon serializer] formatKey:@"GameOnlineUsers"]];
    
    id localServTotalGames = [self getServTotalGames];
    [fieldsDict setObject:(localServTotalGames == nil) ? [NSNull null] : localServTotalGames forKey:[[MNExtWrapperCommon serializer] formatKey:@"ServTotalGames"]];
    
    id localServTotalUsers = [self getServTotalUsers];
    [fieldsDict setObject:(localServTotalUsers == nil) ? [NSNull null] : localServTotalUsers forKey:[[MNExtWrapperCommon serializer] formatKey:@"ServTotalUsers"]];
    
    id localServOnlineRooms = [self getServOnlineRooms];
    [fieldsDict setObject:(localServOnlineRooms == nil) ? [NSNull null] : localServOnlineRooms forKey:[[MNExtWrapperCommon serializer] formatKey:@"ServOnlineRooms"]];
    
    id localServOnlineGames = [self getServOnlineGames];
    [fieldsDict setObject:(localServOnlineGames == nil) ? [NSNull null] : localServOnlineGames forKey:[[MNExtWrapperCommon serializer] formatKey:@"ServOnlineGames"]];
    
    id localServOnlineUsers = [self getServOnlineUsers];
    [fieldsDict setObject:(localServOnlineUsers == nil) ? [NSNull null] : localServOnlineUsers forKey:[[MNExtWrapperCommon serializer] formatKey:@"ServOnlineUsers"]];
    
    
    return fieldsDict;
}
@end

@implementation MNWSLeaderboardListItem(MNUnity)
- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:16];
    
    id localUserAchievementsList = [self getUserAchievementsList];
    [fieldsDict setObject:(localUserAchievementsList == nil) ? [NSNull null] : localUserAchievementsList forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserAchievementsList"]];
    
    id localUserAvatarUrl = [self getUserAvatarUrl];
    [fieldsDict setObject:(localUserAvatarUrl == nil) ? [NSNull null] : localUserAvatarUrl forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserAvatarUrl"]];
    
    id localOutHiDateTimeDiff = [self getOutHiDateTimeDiff];
    [fieldsDict setObject:(localOutHiDateTimeDiff == nil) ? [NSNull null] : localOutHiDateTimeDiff forKey:[[MNExtWrapperCommon serializer] formatKey:@"OutHiDateTimeDiff"]];
    
    id localUserIsFriend = [self getUserIsFriend];
    [fieldsDict setObject:(localUserIsFriend == nil) ? [NSNull null] : localUserIsFriend forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserIsFriend"]];
    
    id localOutHiDateTime = [self getOutHiDateTime];
    [fieldsDict setObject:(localOutHiDateTime == nil) ? [NSNull null] : localOutHiDateTime forKey:[[MNExtWrapperCommon serializer] formatKey:@"OutHiDateTime"]];
    
    id localGamesetId = [self getGamesetId];
    [fieldsDict setObject:(localGamesetId == nil) ? [NSNull null] : localGamesetId forKey:[[MNExtWrapperCommon serializer] formatKey:@"GamesetId"]];
    
    id localOutUserPlace = [self getOutUserPlace];
    [fieldsDict setObject:(localOutUserPlace == nil) ? [NSNull null] : localOutUserPlace forKey:[[MNExtWrapperCommon serializer] formatKey:@"OutUserPlace"]];
    
    id localUserOnlineNow = [self getUserOnlineNow];
    [fieldsDict setObject:(localUserOnlineNow == nil) ? [NSNull null] : localUserOnlineNow forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserOnlineNow"]];
    
    id localUserLocale = [self getUserLocale];
    [fieldsDict setObject:(localUserLocale == nil) ? [NSNull null] : localUserLocale forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserLocale"]];
    
    id localOutHiScoreText = [self getOutHiScoreText];
    [fieldsDict setObject:(localOutHiScoreText == nil) ? [NSNull null] : localOutHiScoreText forKey:[[MNExtWrapperCommon serializer] formatKey:@"OutHiScoreText"]];
    
    id localUserId = [self getUserId];
    [fieldsDict setObject:(localUserId == nil) ? [NSNull null] : localUserId forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserId"]];
    
    id localOutHiScore = [self getOutHiScore];
    [fieldsDict setObject:(localOutHiScore == nil) ? [NSNull null] : localOutHiScore forKey:[[MNExtWrapperCommon serializer] formatKey:@"OutHiScore"]];
    
    id localUserNickName = [self getUserNickName];
    [fieldsDict setObject:(localUserNickName == nil) ? [NSNull null] : localUserNickName forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserNickName"]];
    
    id localUserIsIgnored = [self getUserIsIgnored];
    [fieldsDict setObject:(localUserIsIgnored == nil) ? [NSNull null] : localUserIsIgnored forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserIsIgnored"]];
    
    id localGameId = [self getGameId];
    [fieldsDict setObject:(localGameId == nil) ? [NSNull null] : localGameId forKey:[[MNExtWrapperCommon serializer] formatKey:@"GameId"]];
    
    id localUserSfid = [self getUserSfid];
    [fieldsDict setObject:(localUserSfid == nil) ? [NSNull null] : localUserSfid forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserSfid"]];
    
    
    return fieldsDict;
}
@end

@implementation MNScoreProgressProviderItem(MNUnity)

- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:3];
    
    id localPlace = [NSNumber numberWithInt:self.place];
    [fieldsDict setObject:(localPlace == nil) ? [NSNull null] : localPlace forKey:[[MNExtWrapperCommon serializer] formatKey:@"Place"]];
    
    id localUserInfo = self.userInfo;
    [fieldsDict setObject:(localUserInfo == nil) ? [NSNull null] : localUserInfo forKey:[[MNExtWrapperCommon serializer] formatKey:@"UserInfo"]];
    
    id localScore = [NSNumber numberWithLongLong:self.score];
    [fieldsDict setObject:(localScore == nil) ? [NSNull null] : localScore forKey:[[MNExtWrapperCommon serializer] formatKey:@"Score"]];
    
    
    return fieldsDict;
}
+ (id)fromDictionary:(NSDictionary*)fieldsDict {
    MNScoreProgressProviderItem *object = [[[MNScoreProgressProviderItem alloc]initWithUserInfo:[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"UserInfo"]]
                                                                                          score:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Score"]]).longLongValue
                                                                                       andPlace:((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"Place"]]).intValue]autorelease];
    
    return object;
}
+ (id)fromJson:(NSString*)jsonString {
    NSDictionary *fieldsDict = [[[[SBJsonParser alloc]init]autorelease]objectWithString:jsonString];
    
    return [MNScoreProgressProviderItem fromDictionary:fieldsDict];
}

@end


@implementation MNBuddyRoomParams(MNUnity)

- (id)proxyForJson {
    NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:5];
    
    id localRoomName = self.roomName;
    [fieldsDict setObject:(localRoomName == nil) ? [NSNull null] : localRoomName forKey:[[MNExtWrapperCommon serializer] formatKey:@"RoomName"]];
    
    id localInviteText = self.inviteText;
    [fieldsDict setObject:(localInviteText == nil) ? [NSNull null] : localInviteText forKey:[[MNExtWrapperCommon serializer] formatKey:@"InviteText"]];
    
    id localToUserIdList = self.toUserIdList;
    [fieldsDict setObject:(localToUserIdList == nil) ? [NSNull null] : localToUserIdList forKey:[[MNExtWrapperCommon serializer] formatKey:@"ToUserIdList"]];
    
    id localToUserSFIdList = self.toUserSFIdList;
    [fieldsDict setObject:(localToUserSFIdList == nil) ? [NSNull null] : localToUserSFIdList forKey:[[MNExtWrapperCommon serializer] formatKey:@"ToUserSFIdList"]];
    
    id localGameSetId = [NSNumber numberWithInteger:self.gameSetId];
    [fieldsDict setObject:(localGameSetId == nil) ? [NSNull null] : localGameSetId forKey:[[MNExtWrapperCommon serializer] formatKey:@"GameSetId"]];
    
    
    return fieldsDict;
}
+ (id)fromDictionary:(NSDictionary*)fieldsDict {
    MNBuddyRoomParams *object = [[[MNBuddyRoomParams alloc]init]autorelease];
    
    object.roomName = [fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"RoomName"]];
    object.gameSetId = ((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"GameSetId"]]).integerValue;
    object.toUserIdList = [fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"ToUserIdList"]];
    object.toUserSFIdList = [fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"ToUserSFIdList"]];
    object.inviteText = [fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"InviteText"]];
    
    
    return object;
}
+ (id)fromJson:(NSString*)jsonString {
    NSDictionary *fieldsDict = [[[[SBJsonParser alloc]init]autorelease]objectWithString:jsonString];
    
    return [MNBuddyRoomParams fromDictionary:fieldsDict];
}

@end

@implementation MNJoinRoomInvitationParams(MNUnity)

- (id)proxyForJson {
 NSMutableDictionary *fieldsDict = [NSMutableDictionary dictionaryWithCapacity:7];
 
 id localRoomGameId = [NSNumber numberWithInt:self.roomGameId];
 [fieldsDict setObject:(localRoomGameId == nil) ? [NSNull null] : localRoomGameId forKey:[[MNExtWrapperCommon serializer] formatKey:@"RoomGameId"]];
 
 id localRoomName = self.roomName;
 [fieldsDict setObject:(localRoomName == nil) ? [NSNull null] : localRoomName forKey:[[MNExtWrapperCommon serializer] formatKey:@"RoomName"]];
 
 id localRoomSFId = [NSNumber numberWithInt:self.roomSFId];
 [fieldsDict setObject:(localRoomSFId == nil) ? [NSNull null] : localRoomSFId forKey:[[MNExtWrapperCommon serializer] formatKey:@"RoomSFId"]];
 
 id localInviteText = self.inviteText;
 [fieldsDict setObject:(localInviteText == nil) ? [NSNull null] : localInviteText forKey:[[MNExtWrapperCommon serializer] formatKey:@"InviteText"]];
 
 id localRoomGameSetId = [NSNumber numberWithInt:self.roomGameSetId];
 [fieldsDict setObject:(localRoomGameSetId == nil) ? [NSNull null] : localRoomGameSetId forKey:[[MNExtWrapperCommon serializer] formatKey:@"RoomGameSetId"]];
 
 id localFromUserName = self.fromUserName;
 [fieldsDict setObject:(localFromUserName == nil) ? [NSNull null] : localFromUserName forKey:[[MNExtWrapperCommon serializer] formatKey:@"FromUserName"]];
 
 id localFromUserSFId = [NSNumber numberWithInt:self.fromUserSFId];
 [fieldsDict setObject:(localFromUserSFId == nil) ? [NSNull null] : localFromUserSFId forKey:[[MNExtWrapperCommon serializer] formatKey:@"FromUserSFId"]];
 
 
 return fieldsDict;
}
+ (id)fromDictionary:(NSDictionary*)fieldsDict {
    MNJoinRoomInvitationParams *object = [[[MNJoinRoomInvitationParams alloc]init]autorelease];
    
    object.roomGameId = ((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"RoomGameId"]]).intValue;
    object.roomName = [fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"RoomName"]];
    object.roomSFId = ((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"RoomSFId"]]).intValue;
    object.inviteText = [fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"InviteText"]];
    object.roomGameSetId = ((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"RoomGameSetId"]]).intValue;
    object.fromUserName = [fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"FromUserName"]];
    object.fromUserSFId = ((NSNumber*)[fieldsDict objectForKey:[[MNExtWrapperCommon serializer] formatKey:@"FromUserSFId"]]).intValue;
                                        
 
 return object;
}
+ (id)fromJson:(NSString*)jsonString {
 NSDictionary *fieldsDict = [[[[SBJsonParser alloc]init]autorelease]objectWithString:jsonString];
 
 return [MNJoinRoomInvitationParams fromDictionary:fieldsDict];
}

@end


