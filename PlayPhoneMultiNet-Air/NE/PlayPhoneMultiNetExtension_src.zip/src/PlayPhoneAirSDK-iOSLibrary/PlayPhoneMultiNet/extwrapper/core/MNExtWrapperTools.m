//
//  MNExtWrapperTools.m
//  MultiNet Extension Wrapper
//
//  Created by Vladislav Ogol on 03.08.12.
//  Copyright (c) 2012 PlayPhone.m. All rights reserved.
//

#import "MNExtWrapperTools.h"


NSString* GetCapitalizedString(NSString *word)
 {
  NSString *resultString;
  
  if ([word isEqual:@"playphone"])
   {
    resultString = @"PlayPhone";
  }
  else if ([word isEqual:@"multinet"])
   {
    resultString = @"MultiNet";
   }
  else
   {
    NSRange range = [word rangeOfString:@"mn"];
   
    if (range.location == 0)
     {
      resultString = [NSString stringWithFormat:@"%@%@",@"MN",[word substringFromIndex:range.length]];
     }
    else
     {
      resultString = [word capitalizedString];
     }
  }
  
  return resultString;
 }

NSString* GetDecapitalizedString(NSString *word)
 {
  NSString *resultString;

  if ([word isEqual:@"PlayPhone"])
   {
    resultString = @"playphone";
   }
  else if ([word isEqual:@"MultiNet"])
   {
    resultString = @"multinet";

  }
  else
   {
    NSRange range = [word rangeOfString:@"MN"];
    
    if (range.location == 0)
     {
      resultString = [NSString stringWithFormat:@"%@%@",@"mn",[word substringFromIndex:range.length]];
     }
    else
     {
      resultString = [NSString stringWithFormat:@"%@%@",[[word substringToIndex:1]lowercaseString],[word substringFromIndex:1]];
     }
  }
  
  return resultString;
 }
