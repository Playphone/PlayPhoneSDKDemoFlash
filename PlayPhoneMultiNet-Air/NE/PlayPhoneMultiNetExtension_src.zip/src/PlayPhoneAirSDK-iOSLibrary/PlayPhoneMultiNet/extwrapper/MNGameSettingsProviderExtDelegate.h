//
//  MNGameSettingsProviderExtDelegate.h
//  MultiNet Extension Wrapper
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "MNGameSettingsProvider.h"

#import "MNExtWrapperEventDispatcher.h"

@interface MNGameSettingsProviderExtDelegate : NSObject<MNGameSettingsProviderDelegate>

- (id)initWithDispatcher:(id<MNExtWrapperEventDispatcher>)eventDispatcher;
- (void)dealloc;

@end
