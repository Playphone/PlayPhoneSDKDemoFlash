//
//  MNAchievementsProviderExtDelegate.m
//  MultiNet Extension Wrapper
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "MNExtWrapperDefs.h"
#import "MNAchievementsProviderExtDelegate.h"


@interface MNAchievementsProviderExtDelegate()
@property (nonatomic,retain) id<MNExtWrapperEventDispatcher> eventDispatcher;
@end

@implementation MNAchievementsProviderExtDelegate
@synthesize eventDispatcher = _eventDispatcher;

- (id)initWithDispatcher:(id<MNExtWrapperEventDispatcher>)eventDispatcher
 {
  if (self = [super init])
   {
    self.eventDispatcher = eventDispatcher;
   }
  
  return self;
 }

- (void)dealloc
 {
  self.eventDispatcher = nil;

  [super dealloc];
 }

- (void)onGameAchievementListUpdated
 {
  MARK;
  [self.eventDispatcher dispatchEvent:@"onGameAchievementListUpdated" withParams:nil andParamsNames:nil];
 }

- (void)onPlayerAchievementUnlocked:(int)achievementId
 {
  MARK;
  NSArray *paramsArray     = [NSArray arrayWithObjects:[NSNumber numberWithInt:achievementId],nil];
  NSArray *paramNamesArray = [NSArray arrayWithObjects:@"achievementId",nil];

  [self.eventDispatcher dispatchEvent:@"onPlayerAchievementUnlocked" withParams:paramsArray andParamsNames:paramNamesArray];
 }

@end
