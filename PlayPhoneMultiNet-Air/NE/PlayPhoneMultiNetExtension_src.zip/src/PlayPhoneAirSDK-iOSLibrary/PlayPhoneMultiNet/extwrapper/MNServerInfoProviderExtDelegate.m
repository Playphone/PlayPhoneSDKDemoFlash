//
//  MNServerInfoProviderExtDelegate.m
//  MultiNet Extension Wrapper
//
//  Copyright (c) 2012 PlayPhone Inc. All rights reserved.
//

#import "MNExtWrapperDefs.h"
#import "MNServerInfoProviderExtDelegate.h"


@interface MNServerInfoProviderExtDelegate()
@property (nonatomic,retain) id<MNExtWrapperEventDispatcher> eventDispatcher;
@end

@implementation MNServerInfoProviderExtDelegate
@synthesize eventDispatcher = _eventDispatcher;

- (id)initWithDispatcher:(id<MNExtWrapperEventDispatcher>)eventDispatcher
 {
  if (self = [super init])
   {
    self.eventDispatcher = eventDispatcher;
   }
  
  return self;
 }

- (void)dealloc
 {
  self.eventDispatcher = nil;

  [super dealloc];
 }

- (void)serverInfoWithKey:(int)key received:(NSString*)value
 {
  MARK;
  NSArray *paramsArray     = [NSArray arrayWithObjects:[NSNumber numberWithInt:key],(value == nil ? [NSNull null] : value),nil];
  NSArray *paramNamesArray = [NSArray arrayWithObjects:@"key",@"value",nil];

  [self.eventDispatcher dispatchEvent:@"onServerInfoItemReceived" withParams:paramsArray andParamsNames:paramNamesArray];
 }

- (void)serverInfoWithKey:(int)key requestFailedWithError:(NSString*)error
 {
  MARK;
  NSArray *paramsArray     = [NSArray arrayWithObjects:[NSNumber numberWithInt:key],(error == nil ? [NSNull null] : error),nil];
  NSArray *paramNamesArray = [NSArray arrayWithObjects:@"key",@"error",nil];

  [self.eventDispatcher dispatchEvent:@"onServerInfoItemRequestFailedWithError" withParams:paramsArray andParamsNames:paramNamesArray];
 }

@end
