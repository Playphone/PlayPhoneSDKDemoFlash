package com.playphone.multinet.extwrapper;

public interface IMNExtWrapperEventDispatcher {
public void dispatchEvent(String eventName,Object[] eventParams,String[] eventParamsNames);
}
