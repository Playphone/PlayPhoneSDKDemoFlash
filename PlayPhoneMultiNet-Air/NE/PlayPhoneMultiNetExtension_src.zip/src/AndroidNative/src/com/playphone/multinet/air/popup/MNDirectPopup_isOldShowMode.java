package com.playphone.multinet.air.popup;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;
import com.adobe.fre.FREWrongThreadException;
import com.playphone.multinet.MNDirectPopup;

public class MNDirectPopup_isOldShowMode implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
        ret = FREObject.newObject( MNDirectPopup.isOldShowMode(  ) );
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
