package com.playphone.multinet.air.vocabulary;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.core.MNGameVocabulary;

import java.nio.ByteBuffer;

public class MNGameVocabulary_getFileData implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREByteArray ret = null;
        try
        {

            byte[] fileBytes = MNDirect.getSession().getGameVocabulary().getFileData(freObjects[0].getAsString());
            ret = FREByteArray.newByteArray();
            ret.setProperty( "length", FREObject.newObject( fileBytes.length ) );
            ret.acquire();
            ByteBuffer bytes = ret.getBytes();
            bytes.put(fileBytes);
            ret.release();
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FREReadOnlyException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
