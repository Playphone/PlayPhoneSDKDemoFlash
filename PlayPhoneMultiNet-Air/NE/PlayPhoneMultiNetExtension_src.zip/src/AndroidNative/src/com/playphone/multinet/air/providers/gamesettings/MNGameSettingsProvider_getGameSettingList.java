package com.playphone.multinet.air.providers.gamesettings;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.providers.MNGameSettingsProvider;

public class MNGameSettingsProvider_getGameSettingList implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREArray ret = null;
        try
        {
            MNGameSettingsProvider.GameSettingInfo[] settings = MNDirect.getGameSettingsProvider().getGameSettingList(  );
            ret = FREArray.newArray(settings.length);
            
            for(int i = 0; i < settings.length; i++)
            {
                ret.setObjectAt(i, FREObject.newObject("com.playphone.multinet.providers.GameSettingInfo",
                                      new FREObject[]
                                      {
                                              FREObject.newObject(settings[i].getId()),
                                              FREObject.newObject(settings[i].getName()),
                                              FREObject.newObject(settings[i].getParams()),
                                              FREObject.newObject(settings[i].getSysParams()),
                                              FREObject.newObject(settings[i].isMultiplayerEnabled()),
                                              FREObject.newObject(settings[i].isLeaderboardVisible())
                                      }));
            }
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
