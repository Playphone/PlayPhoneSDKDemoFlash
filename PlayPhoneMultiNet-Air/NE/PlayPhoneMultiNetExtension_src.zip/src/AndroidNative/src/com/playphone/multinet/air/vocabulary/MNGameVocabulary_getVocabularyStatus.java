package com.playphone.multinet.air.vocabulary;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.core.MNGameVocabulary;

public class MNGameVocabulary_getVocabularyStatus implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            ret = FREObject.newObject(MNDirect.getSession().getGameVocabulary().getVocabularyStatus());
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
