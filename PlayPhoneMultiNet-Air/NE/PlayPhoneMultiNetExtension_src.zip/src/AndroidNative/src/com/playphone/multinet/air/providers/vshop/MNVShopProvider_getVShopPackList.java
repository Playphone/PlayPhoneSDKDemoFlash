package com.playphone.multinet.air.providers.vshop;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.providers.MNVShopProvider;

public class MNVShopProvider_getVShopPackList implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREArray ret = null;
        try
        {
            MNVShopProvider.VShopPackInfo[] packs = MNDirect.getVShopProvider().getVShopPackList();
            ret = FREArray.newArray(packs.length);
            for (int i = 0; i < packs.length; i++)
            {
                FREArray delivery = FREArray.newArray(packs[i].delivery.length);
                for (int j = 0; j < packs[i].delivery.length; j++)
                {
                    delivery.setObjectAt(i, FREObject.newObject("com.playphone.multinet.providers.VShopDeliveryInfo",
                                                                new FREObject[]
                                                                {
                                                                        FREObject.newObject(packs[i].delivery[j].vItemId),
                                                                        FREObject.newObject(packs[i].delivery[j].amount)
                                                                }));
                }

                ret.setObjectAt(i, FREObject.newObject("com.playphone.multinet.providers.VShopPackInfo",
                                                       new FREObject[]
                                                       {
                                                               FREObject.newObject(packs[i].id),
                                                               FREObject.newObject(packs[i].name),
                                                               FREObject.newObject(packs[i].model),
                                                               FREObject.newObject(packs[i].description),
                                                               FREObject.newObject(packs[i].appParams),
                                                               FREObject.newObject(packs[i].sortPos),
                                                               FREObject.newObject(packs[i].categoryId),
                                                               delivery,
                                                               FREObject.newObject(packs[i].priceItemId),
                                                               FREObject.newObject(packs[i].priceValue)
                                                       }));
            }
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
