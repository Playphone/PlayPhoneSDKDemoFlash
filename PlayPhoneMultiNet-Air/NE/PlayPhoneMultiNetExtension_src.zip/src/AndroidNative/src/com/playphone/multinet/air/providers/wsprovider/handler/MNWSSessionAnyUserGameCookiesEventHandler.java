package com.playphone.multinet.air.providers.wsprovider.handler;

import com.adobe.fre.FREContext;
import com.playphone.multinet.core.ws.data.MNWSRoomUserInfoItem;
import com.playphone.multinet.core.ws.data.MNWSSessionSignedClientToken;
import com.playphone.multinet.core.ws.data.MNWSUserGameCookie;
import com.playphone.multinet.providers.MNWSInfoRequestAnyUserGameCookies;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MNWSSessionAnyUserGameCookiesEventHandler extends MNWSEventHandler implements
        MNWSInfoRequestAnyUserGameCookies.IEventHandler
{
    public MNWSSessionAnyUserGameCookiesEventHandler(int requestId, FREContext context)
    {
        super(requestId, context);
    }

    @Override
    public void onCompleted(MNWSInfoRequestAnyUserGameCookies.RequestResult result)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("request_id", requestId);
            json.put("had_error", result.hadError());

            if (!result.hadError())
            {
                JSONArray arr = new JSONArray();
                for (MNWSUserGameCookie item : result.getDataEntry())
                {
                    JSONObject arrItem = new JSONObject();

                    arrItem.put("user_id", item.getUserId());
                    arrItem.put("cookie_id", item.getCookieKey());
                    arrItem.put("cookie_value", item.getCookieValue());

                    arr.put(arrItem);
                }
                json.put("data", arr);
            }
            else
            {
                json.put("error_message", result.getErrorMessage());
            }

            context.dispatchStatusEventAsync("onWSRequestReceived", json.toString());
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
    }
}
