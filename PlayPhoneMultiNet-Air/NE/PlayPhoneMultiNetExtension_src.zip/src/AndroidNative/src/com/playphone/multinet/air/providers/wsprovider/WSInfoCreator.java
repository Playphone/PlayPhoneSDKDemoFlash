package com.playphone.multinet.air.providers.wsprovider;

import com.adobe.fre.*;
import com.playphone.multinet.air.providers.wsprovider.handler.*;
import com.playphone.multinet.providers.*;

public class WSInfoCreator
{
    private static final String currentUser = "currentUser";
    private static final String currentUserBuddyList = "currentUserBuddyList";
    private static final String anyUser = "anyUser";
    private static final String currentGameRoomList = "currentGameRoomList";
    private static final String currentGameRoomUserList = "currentGameRoomUserList";
    private static final String systemGameNetStats = "systemGameNetStats";
    private static final String anyGame = "anyGame";
    private static final String anyGameAchievementList = "anyGameAchievementList";
    private static final String currentUserSubscriptionStatus = "currentUserSubscriptionStatus";
    private static final String getSessionSignedClientToken = "getSessionSignedClientToken";
    private static final String anyUserGameCookies = "anyUserGameCookies";
    private static final String currentUserLeaderboard = "currentUserLeaderboard";
    private static final String anyGameLeaderboardGlobal = "anyGameLeaderboardGlobal";
    private static final String anyUserAnyGameLeaderboardGlobal = "anyUserAnyGameLeaderboardGlobal";
    private static final String currentUserAnyGameLeaderboardLocal = "currentUserAnyGameLeaderboardLocal";

    public static MNWSInfoRequest create(FREObject infoRequest, FREContext context) throws FREWrongThreadException,
            FRENoSuchNameException, FRETypeMismatchException,
            FREASErrorException, FREInvalidObjectException
    {
        String blockName = infoRequest.getProperty("blockName").getAsString();

        if (blockName.contains(currentUserBuddyList))
        {
            return createCurrentUserBuddyList(infoRequest, context);
        }
        if (blockName.contains(currentGameRoomList))
        {
            return createCurrentGameRoomList(infoRequest, context);
        }
        if (blockName.contains(currentGameRoomUserList))
        {
            return createCurrentGameRoomUserList(infoRequest, context);
        }
        if (blockName.contains(systemGameNetStats))
        {
            return createSystemGameNetStats(infoRequest, context);
        }
        if (blockName.contains(anyGameAchievementList))
        {
            return createAnyGameAchievementList(infoRequest, context);
        }
        if (blockName.contains(currentUserSubscriptionStatus))
        {
            return createCurrentUserSubscriptionStatus(infoRequest, context);
        }
        if (blockName.contains(getSessionSignedClientToken))
        {
            return createGetSessionSignedClientToken(infoRequest, context);
        }
        if (blockName.contains(anyUserGameCookies))
        {
            return createAnyUserGameCookies(infoRequest, context);
        }
        if (blockName.contains(currentUserLeaderboard))
        {
            return createCurrentUserLeaderboard(infoRequest, context);
        }
        if (blockName.contains(anyUserAnyGameLeaderboardGlobal))
        {
            return createAnyUserAnyGameLeaderboardGlobal(infoRequest, context);
        }
        if (blockName.contains(currentUserAnyGameLeaderboardLocal))
        {
            return createCurrentUserAnyGameLeaderboardLocal(infoRequest, context);
        }
        if (blockName.contains(anyGameLeaderboardGlobal))
        {
            return createAnyGameLeaderboardGlobal(infoRequest, context);
        }
        if (blockName.contains(currentUser))
        {
            return createCurrentUser(infoRequest, context);
        }
        if (blockName.contains(anyUser))
        {
            return createAnyUser(infoRequest, context);
        }
        if (blockName.contains(anyGame))
        {
            return createAnyGame(infoRequest, context);
        }
        return null;
    }

    private static MNWSInfoRequest createCurrentUser(FREObject infoRequest, FREContext context) throws
            FREWrongThreadException,
            FRENoSuchNameException, FRETypeMismatchException, FREASErrorException, FREInvalidObjectException
    {
        return new MNWSInfoRequestCurrentUserInfo(
                new MNWSCurrentUserInfoEventHandler(
                        infoRequest.getProperty("requestId").getAsInt(),
                        context));
    }

    private static MNWSInfoRequest createCurrentUserBuddyList(FREObject infoRequest, FREContext context) throws
            FREWrongThreadException, FRENoSuchNameException, FRETypeMismatchException, FREASErrorException,
            FREInvalidObjectException
    {
        return new MNWSInfoRequestCurrUserBuddyList(
                new MNWSCurrentUserBuddyListEventHandler(
                        infoRequest.getProperty("requestId").getAsInt(),
                        context));
    }

    private static MNWSInfoRequest createAnyUser(FREObject infoRequest, FREContext context) throws
            FREWrongThreadException,
            FRENoSuchNameException, FRETypeMismatchException, FREASErrorException, FREInvalidObjectException
    {
        return new MNWSInfoRequestAnyUser(infoRequest.getProperty("user_id").getAsInt(),
                                          new MNWSAnyUserEventHandler(
                                                  infoRequest.getProperty("requestId").getAsInt(),
                                                  context));
    }

    private static MNWSInfoRequest createCurrentGameRoomList(FREObject infoRequest, FREContext context) throws
            FREWrongThreadException, FRENoSuchNameException, FRETypeMismatchException, FREASErrorException,
            FREInvalidObjectException
    {
        return new MNWSInfoRequestCurrGameRoomList(
                new MNWSCurrentGameRoomListEventHandler(
                        infoRequest.getProperty("requestId").getAsInt(),
                        context));
    }

    private static MNWSInfoRequest createCurrentGameRoomUserList(FREObject infoRequest, FREContext context) throws
            FREWrongThreadException, FRENoSuchNameException, FRETypeMismatchException, FREASErrorException,
            FREInvalidObjectException
    {
        return new MNWSInfoRequestCurrGameRoomUserList(
                infoRequest.getProperty("room_sfid").getAsInt(),
                new MNWSCurrentGameRoomUserListEventHandler(
                        infoRequest.getProperty("requestId").getAsInt(),
                        context));
    }

    private static MNWSInfoRequest createSystemGameNetStats(FREObject infoRequest, FREContext context) throws
            FREWrongThreadException, FRENoSuchNameException, FRETypeMismatchException, FREASErrorException,
            FREInvalidObjectException
    {
        return new MNWSInfoRequestSystemGameNetStats(
                new MNWSSystemNetStatEventHandler(
                        infoRequest.getProperty("requestId").getAsInt(),
                        context));
    }

    private static MNWSInfoRequest createAnyGame(FREObject infoRequest, FREContext context) throws
            FREWrongThreadException, FRENoSuchNameException, FRETypeMismatchException, FREASErrorException,
            FREInvalidObjectException
    {
        return new MNWSInfoRequestAnyGame(
                infoRequest.getProperty("game_id").getAsInt(),
                new MNWSAnyGameEventHandler(
                        infoRequest.getProperty("requestId").getAsInt(),
                        context));

    }

    private static MNWSInfoRequest createAnyGameAchievementList(FREObject infoRequest, FREContext context)
    {
        return null;
    }

    private static MNWSInfoRequest createCurrentUserSubscriptionStatus(FREObject infoRequest, FREContext context) throws
            FREWrongThreadException, FRENoSuchNameException, FRETypeMismatchException, FREASErrorException,
            FREInvalidObjectException
    {
        return new MNWSInfoRequestCurrUserSubscriptionStatus(
                new MNWSCurrUserSubscriptionStatusEventHandler(
                        infoRequest.getProperty("requestId").getAsInt(),
                        context));
    }

    private static MNWSInfoRequest createGetSessionSignedClientToken(FREObject infoRequest, FREContext context) throws
            FREWrongThreadException, FRENoSuchNameException, FRETypeMismatchException, FREASErrorException,
            FREInvalidObjectException
    {
        return new MNWSInfoRequestSessionSignedClientToken(
                infoRequest.getProperty("payload").getAsString(),
                new MNWSSessionSignedClientTokenEventHandler(
                        infoRequest.getProperty("requestId").getAsInt(),
                        context));
    }

    private static MNWSInfoRequest createAnyUserGameCookies(FREObject infoRequest, FREContext context) throws
            FREWrongThreadException, FREInvalidObjectException, FRENoSuchNameException, FRETypeMismatchException,
            FREASErrorException
    {
        FREArray userIds = (FREArray) infoRequest.getProperty("user_id");
        long[] userIdList = new long[(int) userIds.getLength()];
        for (int i = 0; i < userIds.getLength(); i++)
        {
            userIdList[i] = userIds.getObjectAt(i).getAsInt();
        }

        FREArray cookieKeys = (FREArray) infoRequest.getProperty("cookie_key");
        int[] cookieKeyList = new int[(int) cookieKeys.getLength()];
        for (int i = 0; i < cookieKeys.getLength(); i++)
        {
            cookieKeyList[i] = cookieKeys.getObjectAt(i).getAsInt();
        }

        return new MNWSInfoRequestAnyUserGameCookies(
                userIdList,
                cookieKeyList,
                new MNWSSessionAnyUserGameCookiesEventHandler(
                        infoRequest.getProperty("requestId").getAsInt(),
                        context));
    }

    private static MNWSInfoRequest createCurrentUserLeaderboard(FREObject infoRequest, FREContext context) throws
            FREWrongThreadException, FRENoSuchNameException, FRETypeMismatchException, FREASErrorException,
            FREInvalidObjectException
    {
        return new MNWSInfoRequestLeaderboard(
                new MNWSInfoRequestLeaderboard.LeaderboardModeCurrentUser(
                        infoRequest.getProperty("scope").getAsInt(),
                        infoRequest.getProperty("period").getAsInt()),
                new MNWSInfoRequestLeaderboardEventHandler(
                        infoRequest.getProperty("requestId").getAsInt(),
                        context));
    }

    private static MNWSInfoRequest createAnyGameLeaderboardGlobal(FREObject infoRequest, FREContext context) throws
            FREWrongThreadException, FRENoSuchNameException, FRETypeMismatchException, FREASErrorException, FREInvalidObjectException
    {
        return new MNWSInfoRequestLeaderboard(
                new MNWSInfoRequestLeaderboard.LeaderboardModeAnyGameGlobal(
                        infoRequest.getProperty("game_id").getAsInt(),
                        infoRequest.getProperty("game_set_id").getAsInt(),
                        infoRequest.getProperty("period").getAsInt()),
                new MNWSInfoRequestLeaderboardEventHandler(
                        infoRequest.getProperty("requestId").getAsInt(),
                        context));
    }

    private static MNWSInfoRequest createAnyUserAnyGameLeaderboardGlobal(FREObject infoRequest, FREContext context) throws
            FREWrongThreadException, FRENoSuchNameException, FRETypeMismatchException, FREASErrorException, FREInvalidObjectException
    {
        return new MNWSInfoRequestLeaderboard(
                new MNWSInfoRequestLeaderboard.LeaderboardModeAnyUserAnyGameGlobal(
                        infoRequest.getProperty("user_id").getAsInt(),
                        infoRequest.getProperty("game_id").getAsInt(),
                        infoRequest.getProperty("game_set_id").getAsInt(),
                        infoRequest.getProperty("period").getAsInt()),
                new MNWSInfoRequestLeaderboardEventHandler(
                        infoRequest.getProperty("requestId").getAsInt(),
                        context));
    }

    private static MNWSInfoRequest createCurrentUserAnyGameLeaderboardLocal(FREObject infoRequest, FREContext context) throws
            FREWrongThreadException, FRENoSuchNameException, FRETypeMismatchException, FREASErrorException,
            FREInvalidObjectException
    {
        return new MNWSInfoRequestLeaderboard(
                new MNWSInfoRequestLeaderboard.LeaderboardModeCurrUserAnyGameLocal(
                        infoRequest.getProperty("game_id").getAsInt(),
                        infoRequest.getProperty("game_set_id").getAsInt(),
                        infoRequest.getProperty("period").getAsInt()),
                new MNWSInfoRequestLeaderboardEventHandler(
                        infoRequest.getProperty("requestId").getAsInt(),
                        context));
    }
}
