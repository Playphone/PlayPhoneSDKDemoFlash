package com.playphone.multinet.air.providers.wsprovider.handler;

import com.adobe.fre.FREContext;
import com.playphone.multinet.core.ws.data.MNWSAnyUserItem;
import com.playphone.multinet.providers.MNWSInfoRequestAnyUser;
import org.json.JSONException;
import org.json.JSONObject;

public class MNWSAnyUserEventHandler extends MNWSEventHandler implements MNWSInfoRequestAnyUser.IEventHandler
{
    public MNWSAnyUserEventHandler(int requestId, FREContext context)
    {
        super(requestId, context);
    }

    @Override
    public void onCompleted(MNWSInfoRequestAnyUser.RequestResult result)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("request_id", requestId);
            json.put("had_error", result.hadError());

            if (!result.hadError())
            {
                MNWSAnyUserItem item = result.getDataEntry();
                JSONObject jsonItem = new JSONObject();
                jsonItem.put("user_id", item.getUserId());
                jsonItem.put("user_nick_name", item.getUserNickName());
                jsonItem.put("user_avatar_exists", item.getUserAvatarExists());
                jsonItem.put("user_avatar_url", item.getUserAvatarUrl());
                jsonItem.put("user_online_now", item.getUserOnlineNow());
                jsonItem.put("user_gamepoints", item.getUserGamePoints());
                jsonItem.put("my_friend_link_status", item.getMyFriendLinkStatus());
                json.put("data", jsonItem);
            }
            else
            {
                json.put("error_message", result.getErrorMessage());
            }

            context.dispatchStatusEventAsync("onWSRequestReceived", json.toString());
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
    }
}
