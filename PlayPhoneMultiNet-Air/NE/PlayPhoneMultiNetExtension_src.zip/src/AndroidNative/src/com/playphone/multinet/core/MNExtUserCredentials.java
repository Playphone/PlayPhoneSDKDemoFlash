package com.playphone.multinet.core;

import java.util.Date;

public class MNExtUserCredentials extends MNUserCredentials
{
    public MNExtUserCredentials(long userId, String userName, String userAuthSign, Date lastLoginTime,
                                String userAuxInfoText)
    {
        super(userId, userName, userAuthSign, lastLoginTime, userAuxInfoText);
    }
}
