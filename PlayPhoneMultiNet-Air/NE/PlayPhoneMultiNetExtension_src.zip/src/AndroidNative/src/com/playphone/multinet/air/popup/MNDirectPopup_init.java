package com.playphone.multinet.air.popup;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirectPopup;

public class MNDirectPopup_init implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
        MNDirectPopup.init( freObjects[0].getAsInt() );
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
