package com.playphone.multinet.air;

import com.playphone.multinet.MNErrorInfo;
import com.playphone.multinet.MNGameParams;
import com.playphone.multinet.MNUserInfo;
import com.playphone.multinet.core.MNChatMessage;
import com.playphone.multinet.core.MNCurrGameResults;
import com.playphone.multinet.core.MNGameResult;
import com.playphone.multinet.core.MNJoinRoomInvitationParams;
import com.playphone.multinet.providers.MNScoreProgressProvider;
import com.playphone.multinet.providers.MNVItemsProvider;
import com.playphone.multinet.providers.MNVShopProvider;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class EventParam
{
    public static String toJson(MNJoinRoomInvitationParams params)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("fromUserSFId", params.fromUserSFId);
            json.put("fromUserName", params.fromUserName);
            json.put("roomSFId", params.roomSFId);
            json.put("roomName", params.roomName);
            json.put("roomGameId", params.roomGameId);
            json.put("roomGameSetId", params.roomGameSetId);
            json.put("inviteText", params.inviteText);
            return json.toString();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return "";
    }

    public static String toJson(MNCurrGameResults results)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("gameId", results.gameSetId);
            json.put("gameSetId", results.gameSetId);
            json.put("finalResult", results.finalResult);
            json.put("playRoundNumber", results.playRoundNumber);

            JSONArray userPlaces = new JSONArray();
            for(int place:results.userPlaces)
            {
                userPlaces.put(place);
            }

            JSONArray userScores = new JSONArray();
            for(long score:results.userScores)
            {
                userScores.put(score);
            }

            JSONArray users = new JSONArray();
            for(MNUserInfo user:results.users)
            {
                userPlaces.put(getJsonObject(user));
            }

            return json.toString();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return "";
    }

    public static String toJson(MNChatMessage msg)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("isPrivate", msg.isPrivate);
            json.put("message", msg.message);
            json.put("sender", getJsonObject(msg.sender));
            return json.toString();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return "";
    }


    public static String toJson(MNGameResult result)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("gameSetId", result.gameSetId);
            json.put("score", result.score);
            json.put("scorePostLinkId", result.scorePostLinkId);
            return json.toString();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return "";
    }

    public static String toJson(MNVShopProvider.IEventHandler.CheckoutVShopPackFailInfo result)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("errorCode", result.getErrorCode());
            json.put("errorMessage", result.getErrorMessage());
            json.put("clientTransactionId", result.getClientTransactionId());
            return json.toString();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return "";
    }

    public static String toJson(MNVShopProvider.IEventHandler.CheckoutVShopPackSuccessInfo result)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("transaction", getJsonObject(result.getTransaction()));
            return json.toString();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return "";
    }


    public static String toJson(MNVItemsProvider.TransactionError transaction)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("clientTransactionId", transaction.clientTransactionId);
            json.put("serverTransactionId", transaction.serverTransactionId);
            json.put("corrUserId", transaction.corrUserId);
            json.put("failReasonCode", transaction.failReasonCode);
            json.put("errorMessage", transaction.errorMessage);
            return json.toString();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return "";
    }

    public static String toJson(MNVItemsProvider.TransactionInfo transaction)
    {
        try
        {
            return getJsonObject(transaction).toString();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return "";
    }

    public static String toJson(String[] key, String[] value)
    {
        JSONObject json = new JSONObject();
        try
        {
            for (int i = 0; i < key.length; i++)
            {
                json.put(key[i], value[i]);
            }
            return json.toString();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return "";
    }

    public static String toJson(String key, String value)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put(key, value);
            return json.toString();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return "";
    }

    public static String toJson(String key, boolean value)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put(key, value);
            return json.toString();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return "";
    }

    public static String toJson(String key, int value)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put(key, value);
            return json.toString();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return "";
    }

    public static String toJson(MNGameParams params)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("gameSetParams", params.gameSetParams);
            json.put("gameSetId", params.gameSetId);
            json.put("gameSetParams", params.gameSetParams);
            json.put("scorePostLinkId", params.scorePostLinkId);
            json.put("gameSeed", params.gameSeed);
            json.put("gameSetPlayParams", params.gameSetPlayParams);
            json.put("playModel", params.playModel);
            return json.toString();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return "";
    }

    public static String toJson(MNScoreProgressProvider.ScoreItem[] scoreBoard)
    {
        JSONArray json = new JSONArray();
        try
        {
            for (MNScoreProgressProvider.ScoreItem item : scoreBoard)
            {
                JSONObject jsonItem = new JSONObject();
                jsonItem.put("score", item.score);
                jsonItem.put("place", item.place);
                jsonItem.put("userInfo", getJsonObject(item.userInfo));
                json.put(jsonItem);
            }

            return json.toString();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return "";
    }

    public static String toJson(MNUserInfo sender)
    {
        try
        {
            return getJsonObject(sender).toString();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return "";
    }

    public static String toJson(String pluginName, String message, MNUserInfo sender)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("pluginName", pluginName);
            json.put("message", message);
            json.put("sender", getJsonObject(sender));
            return json.toString();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return "";
    }

    public static String toJson(String message, MNUserInfo sender)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("message", message);
            json.put("sender", getJsonObject(sender));
            return json.toString();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return "";
    }

    public static String toJson(MNErrorInfo error)
    {
        JSONObject json = new JSONObject();
        try
        {

            json.put("actionCode", error.actionCode);
            json.put("errorMessage", error.errorMessage);
            return json.toString();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return "";
    }

    private static JSONObject getJsonObject(MNVItemsProvider.TransactionInfo transaction) throws JSONException
    {
        JSONObject json = new JSONObject();
        json.put("clientTransactionId", transaction.clientTransactionId);
        json.put("serverTransactionId", transaction.serverTransactionId);
        json.put("corrUserId", transaction.corrUserId);
        JSONArray arr = new JSONArray();

        for (MNVItemsProvider.TransactionVItemInfo info : transaction.vItems)
        {
            arr.put(getJsonObject(info));
        }
        json.put("vItems", arr);
        return json;
    }

    private static JSONObject getJsonObject(MNVItemsProvider.TransactionVItemInfo info) throws JSONException
    {
        JSONObject obj = new JSONObject();
        obj.put("id", info.id);
        obj.put("delta", info.delta);
        return obj;
    }

    private static JSONObject getJsonObject(MNUserInfo info) throws JSONException
    {
        JSONObject obj = new JSONObject();
        obj.put("userId", info.userId);
        obj.put("userSFId", info.userSFId);
        obj.put("userName", info.userName);
        obj.put("avatarUrl", info.getAvatarUrl());
        return obj;
    }
}
