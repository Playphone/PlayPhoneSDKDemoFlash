package com.playphone.multinet.air.session;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.core.MNGameResult;

public class MNSession_schedulePostScoreOnLogin implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            MNGameResult mgr = new MNGameResult(null);
            mgr.gameSetId = freObjects[0].getProperty("gameSetId").getAsInt();
            mgr.score = freObjects[0].getProperty("gameSetId").getAsInt();
            mgr.scorePostLinkId = freObjects[0].getProperty("gameSetId").getAsString();

            MNDirect.getSession().schedulePostScoreOnLogin(mgr);
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
