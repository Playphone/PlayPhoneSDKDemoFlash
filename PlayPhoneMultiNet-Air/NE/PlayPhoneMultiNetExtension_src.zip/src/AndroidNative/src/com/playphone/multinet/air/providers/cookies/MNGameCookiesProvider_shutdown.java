package com.playphone.multinet.air.providers.cookies;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;
import com.playphone.multinet.MNDirect;

public class MNGameCookiesProvider_shutdown implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        MNDirect.getGameCookiesProvider().shutdown();
        return ret;
    }
}
