package com.playphone.multinet.extwrapper.serializer;

import java.lang.reflect.Array;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.playphone.multinet.MNDirect;
import com.playphone.multinet.MNErrorInfo;
import com.playphone.multinet.MNGameParams;
import com.playphone.multinet.MNUserInfo;
import com.playphone.multinet.core.MNBuddyRoomParams;
import com.playphone.multinet.core.MNCurrGameResults;
import com.playphone.multinet.core.MNJoinRoomInvitationParams;
import com.playphone.multinet.core.ws.data.MNWSAnyGameItem;
import com.playphone.multinet.core.ws.data.MNWSAnyUserItem;
import com.playphone.multinet.core.ws.data.MNWSBuddyListItem;
import com.playphone.multinet.core.ws.data.MNWSCurrUserSubscriptionStatus;
import com.playphone.multinet.core.ws.data.MNWSCurrentUserInfo;
import com.playphone.multinet.core.ws.data.MNWSLeaderboardListItem;
import com.playphone.multinet.core.ws.data.MNWSRoomListItem;
import com.playphone.multinet.core.ws.data.MNWSRoomUserInfoItem;
import com.playphone.multinet.core.ws.data.MNWSSessionSignedClientToken;
import com.playphone.multinet.core.ws.data.MNWSSystemGameNetStats;
import com.playphone.multinet.core.ws.data.MNWSUserGameCookie;
import com.playphone.multinet.extwrapper.MNExtWrapper;
import com.playphone.multinet.extwrapper.MNExtWrapper.WrapperPlatform;
import com.playphone.multinet.providers.MNAchievementsProvider;
import com.playphone.multinet.providers.MNGameSettingsProvider;
import com.playphone.multinet.providers.MNScoreProgressProvider;
import com.playphone.multinet.providers.MNVItemsProvider;
import com.playphone.multinet.providers.MNVShopProvider;
import com.playphone.multinet.providers.MNWSInfoRequestAnyGame;
import com.playphone.multinet.providers.MNWSInfoRequestAnyUser;
import com.playphone.multinet.providers.MNWSInfoRequestAnyUserGameCookies;
import com.playphone.multinet.providers.MNWSInfoRequestCurrGameRoomList;
import com.playphone.multinet.providers.MNWSInfoRequestCurrGameRoomUserList;
import com.playphone.multinet.providers.MNWSInfoRequestCurrUserBuddyList;
import com.playphone.multinet.providers.MNWSInfoRequestCurrUserSubscriptionStatus;
import com.playphone.multinet.providers.MNWSInfoRequestCurrentUserInfo;
import com.playphone.multinet.providers.MNWSInfoRequestLeaderboard;
import com.playphone.multinet.providers.MNWSInfoRequestLeaderboard.LeaderboardMode;
import com.playphone.multinet.providers.MNWSInfoRequestLeaderboard.LeaderboardModeAnyGameGlobal;
import com.playphone.multinet.providers.MNWSInfoRequestLeaderboard.LeaderboardModeAnyUserAnyGameGlobal;
import com.playphone.multinet.providers.MNWSInfoRequestLeaderboard.LeaderboardModeCurrUserAnyGameLocal;
import com.playphone.multinet.providers.MNWSInfoRequestLeaderboard.LeaderboardModeCurrentUser;
import com.playphone.multinet.providers.MNWSInfoRequestSessionSignedClientToken;
import com.playphone.multinet.providers.MNWSInfoRequestSystemGameNetStats;

public class MNJsonSerializer extends MNSerializer {

    public MNJsonSerializer() {
        super(WrapperPlatform.Unity);
    }

    public MNJsonSerializer(WrapperPlatform wrapperPlatform) {
        super(wrapperPlatform);
    }

    @Override
    public String serialize(Object obj) {
        if (obj == null) {
            JSONArray nullJsonArray = new JSONArray();
            nullJsonArray.put(JSONObject.NULL);

            return nullJsonArray.toString();
        }

        MNJsonElement resultJsonElement = getJSONElement(obj);

        if (resultJsonElement == null) {
            // May be it's a boxed primitive type or null. If so, serialize it as array of one element.
            Object[] objects = new Object[1];
            objects[0] = obj;

            resultJsonElement = getJSONElement(objects);
        }

        if (resultJsonElement == null) {
            MNExtWrapper.ELog("Serialization error for object:[" + obj.toString() + "] of type: " + obj.getClass().getName());
            return null;
        }

        return resultJsonElement.toString();
    }

    public String serializeMapToArray(Map<?,?> map) {
        MNJsonElement jsonElement = getJSONArrayFromMap(map);

        if (jsonElement == null) {
            MNExtWrapper.ELog("Serialization to array failed for object:[" + map.toString() + "] of type: " + map.getClass().getName());
            return null;
        }

        return jsonElement.toString();
    }

    public static boolean isObjectTypeSupportedByJSONLib(Object object) {
        boolean result = false;

        if ((object instanceof JSONObject) ||
            (object instanceof JSONArray) ||
            (object instanceof String) ||
            (object instanceof Boolean) ||
            (object instanceof Integer) ||
            (object instanceof Long) ||
            (object instanceof Double) ||
            (object == null)) {
            result = true;
        }

        return result;
    }

    @Override
    public <T> T deserialize(String jsonString,Class<T> type) {
        if (type == Integer.class) {
            Integer[] array = getObjectFromJSON(jsonString,Integer[].class);
            return type.cast(array[0]);
        }
        else if (type == Long.class) {
            Long[] array = getObjectFromJSON(jsonString,Long[].class);
            return type.cast(array[0]);
        }
        else if (type == Double.class) {
            Double[] array = getObjectFromJSON(jsonString,Double[].class);
            return type.cast(array[0]);
        }
        else if (type == Boolean.class) {
            Boolean[] array = getObjectFromJSON(jsonString,Boolean[].class);
            return type.cast(array[0]);
        }
        else if (type == String.class) {
            String[] array = getObjectFromJSON(jsonString,String[].class);
            return type.cast(array[0]);
        }
        else {
            return getObjectFromJSON(jsonString,type);
        }
    }

    @Override
    public <K, V> Map<K,V> deserializeMapFromArray(String jsonString,Class<K> keyType,Class<V> valueType) {
        Map<K,V> result = getMapFromJSONArray(jsonString,keyType,valueType);

        if (result == null) {
            MNExtWrapper.ELog(String.format("Map<%s,%s> Deserialization error. Source Json: <<%s>>",
                                            keyType.getName(),
                                            valueType.getName(),
                                            jsonString));
        }

        return result;
    }

    public MNJsonElement getJSONElement(Object object) {
        try {
            MNExtWrapper.DLog("Serialize object: " + object.getClass().getSimpleName());

            if (object instanceof MNErrorInfo) {
                return getJSONElement((MNErrorInfo)object);
            }

            if (object instanceof MNGameParams) {
                return getJSONElement((MNGameParams)object);
            }

            if (object instanceof MNUserInfo) {
                return getJSONElement((MNUserInfo)object);
            }

            if (object instanceof MNAchievementsProvider.GameAchievementInfo) {
                return getJSONElement((MNAchievementsProvider.GameAchievementInfo)object);
            }

            if (object instanceof MNAchievementsProvider.PlayerAchievementInfo) {
                return getJSONElement((MNAchievementsProvider.PlayerAchievementInfo)object);
            }

            if (object instanceof MNVItemsProvider.GameVItemInfo) {
                return getJSONElement((MNVItemsProvider.GameVItemInfo)object);
            }

            if (object instanceof MNVItemsProvider.PlayerVItemInfo) {
                return getJSONElement((MNVItemsProvider.PlayerVItemInfo)object);
            }

            if (object instanceof MNVItemsProvider.TransactionVItemInfo) {
                return getJSONElement((MNVItemsProvider.TransactionVItemInfo)object);
            }

            if (object instanceof MNVItemsProvider.TransactionInfo) {
                return getJSONElement((MNVItemsProvider.TransactionInfo)object);
            }

            if (object instanceof MNVItemsProvider.TransactionError) {
                return getJSONElement((MNVItemsProvider.TransactionError)object);
            }

            if (object instanceof MNVShopProvider.VShopDeliveryInfo) {
                return getJSONElement((MNVShopProvider.VShopDeliveryInfo)object);
            }

            if (object instanceof MNVShopProvider.VShopPackInfo) {
                return getJSONElement((MNVShopProvider.VShopPackInfo)object);
            }

            if (object instanceof MNVShopProvider.VShopCategoryInfo) {
                return getJSONElement((MNVShopProvider.VShopCategoryInfo)object);
            }

            if (object instanceof MNVShopProvider.VShopPackBuyRequestItem) {
                return getJSONElement((MNVShopProvider.VShopPackBuyRequestItem)object);
            }

            if (object instanceof MNVShopProvider.IEventHandler.CheckoutVShopPackSuccessInfo) {
                return getJSONElement((MNVShopProvider.IEventHandler.CheckoutVShopPackSuccessInfo)object);
            }

            if (object instanceof MNVShopProvider.IEventHandler.CheckoutVShopPackFailInfo) {
                return getJSONElement((MNVShopProvider.IEventHandler.CheckoutVShopPackFailInfo)object);
            }

            if (object instanceof MNGameSettingsProvider.GameSettingInfo) {
                return getJSONElement((MNGameSettingsProvider.GameSettingInfo)object);
            }

            if (object instanceof MNWSAnyGameItem) {
                return getJSONElement((MNWSAnyGameItem)object);
            }

            if (object instanceof MNWSInfoRequestAnyGame.RequestResult) {
                return getJSONElement((MNWSInfoRequestAnyGame.RequestResult)object);
            }

            if (object instanceof MNWSAnyUserItem) {
                return getJSONElement((MNWSAnyUserItem)object);
            }

            if (object instanceof MNWSInfoRequestAnyUser.RequestResult) {
                return getJSONElement((MNWSInfoRequestAnyUser.RequestResult)object);
            }

            if (object instanceof MNWSUserGameCookie) {
                return getJSONElement((MNWSUserGameCookie)object);
            }

            if (object instanceof MNWSInfoRequestAnyUserGameCookies.RequestResult) {
                return getJSONElement((MNWSInfoRequestAnyUserGameCookies.RequestResult)object);
            }

            if (object instanceof MNWSCurrentUserInfo) {
                return getJSONElement((MNWSCurrentUserInfo)object);
            }

            if (object instanceof MNWSInfoRequestCurrentUserInfo.RequestResult) {
                return getJSONElement((MNWSInfoRequestCurrentUserInfo.RequestResult)object);
            }

            if (object instanceof MNWSRoomListItem) {
                return getJSONElement((MNWSRoomListItem)object);
            }

            if (object instanceof MNWSInfoRequestCurrGameRoomList.RequestResult) {
                return getJSONElement((MNWSInfoRequestCurrGameRoomList.RequestResult)object);
            }

            if (object instanceof MNWSRoomUserInfoItem) {
                return getJSONElement((MNWSRoomUserInfoItem)object);
            }

            if (object instanceof MNWSInfoRequestCurrGameRoomUserList.RequestResult) {
                return getJSONElement((MNWSInfoRequestCurrGameRoomUserList.RequestResult)object);
            }

            if (object instanceof MNWSBuddyListItem) {
                return getJSONElement((MNWSBuddyListItem)object);
            }

            if (object instanceof MNWSInfoRequestCurrUserBuddyList.RequestResult) {
                return getJSONElement((MNWSInfoRequestCurrUserBuddyList.RequestResult)object);
            }

            if (object instanceof MNWSCurrUserSubscriptionStatus) {
                return getJSONElement((MNWSCurrUserSubscriptionStatus)object);
            }

            if (object instanceof MNWSInfoRequestCurrUserSubscriptionStatus.RequestResult) {
                return getJSONElement((MNWSInfoRequestCurrUserSubscriptionStatus.RequestResult)object);
            }

            if (object instanceof MNWSSessionSignedClientToken) {
                return getJSONElement((MNWSSessionSignedClientToken)object);
            }

            if (object instanceof MNWSInfoRequestSessionSignedClientToken.RequestResult) {
                return getJSONElement((MNWSInfoRequestSessionSignedClientToken.RequestResult)object);
            }

            if (object instanceof MNWSSystemGameNetStats) {
                return getJSONElement((MNWSSystemGameNetStats)object);
            }

            if (object instanceof MNWSInfoRequestSystemGameNetStats.RequestResult) {
                return getJSONElement((MNWSInfoRequestSystemGameNetStats.RequestResult)object);
            }

            if (object instanceof MNWSLeaderboardListItem) {
                return getJSONElement((MNWSLeaderboardListItem)object);
            }

            if (object instanceof MNWSInfoRequestLeaderboard.RequestResult) {
                return getJSONElement((MNWSInfoRequestLeaderboard.RequestResult)object);
            }

            if (object instanceof MNScoreProgressProvider.ScoreItem) {
                return getJSONElement((MNScoreProgressProvider.ScoreItem)object);
            }

            if (object instanceof MNBuddyRoomParams) {
                return getJSONElement((MNBuddyRoomParams)object);
            }

            if (object instanceof MNJoinRoomInvitationParams) {
                return getJSONElement((MNJoinRoomInvitationParams)object);
            }

            if (object instanceof MNCurrGameResults) {
                return getJSONElement((MNCurrGameResults)object);
            }

            if (object instanceof Map<?,?>) {
                return getJSONElement((Map<?,?>)object);
            }

            if (object.getClass().isArray()) {
                return getJSONElement((Object[])object);
            }
        }
        catch (JSONException e) {
            MNExtWrapper.DLog("Can not create JSONObject from " + object.getClass().getSimpleName());
            e.printStackTrace();
        }

        return null;
    }

    protected MNJsonElement getJSONElement(Object[] objectsArray) {
        if (objectsArray == null) {
            return null;
        }

        try {
            MNExtWrapper.DLog("Serialize array: " + objectsArray.getClass().getSimpleName());

            JSONArray array = new JSONArray();

            for (int index = 0; index < objectsArray.length; index++) {
                if (isObjectTypeSupportedByJSONLib(objectsArray[index])) {
                    array.put(index,objectsArray[index]);
                }
                else {
                    MNJsonElement jsonElement = getJSONElement(objectsArray[index]);

                    if (jsonElement.isArray()) {
                        array.put(index,jsonElement.getElement(JSONArray.class));
                    }
                    else if (jsonElement.isObject()) {
                        array.put(index,jsonElement.getElement(JSONObject.class));
                    }
                    else {
                        throw new JSONException("");
                    }
                }
            }

            return new MNJsonElement(array);
        }
        catch (JSONException e) {
            MNExtWrapper.DLog("Can not create JSONObject from " + objectsArray.getClass().getSimpleName());
            e.printStackTrace();
        }

        return null;
    }

    protected MNJsonElement getJSONElement(MNErrorInfo errorInfo) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("ActionCode"),errorInfo.actionCode);
        json.put(formatKey("ErrorMessage"),errorInfo.errorMessage);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNGameParams gameParams) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("GameSetId"),gameParams.gameSetId);
        json.put(formatKey("GameSetParams"),gameParams.gameSetParams);
        json.put(formatKey("ScorePostLinkId"),gameParams.scorePostLinkId);
        json.put(formatKey("GameSeed"),gameParams.gameSeed);
        json.put(formatKey("PlayModel"),gameParams.playModel);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNUserInfo userInfo) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("UserId"),userInfo.userId);
        json.put(formatKey("UserSFId"),userInfo.userSFId);
        json.put(formatKey("UserName"),userInfo.userName);
        json.put(formatKey("UserAvatarUrl"),userInfo.getAvatarUrl());

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNAchievementsProvider.GameAchievementInfo achInfo) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("Id"),achInfo.id);
        json.put(formatKey("Name"),achInfo.name);
        json.put(formatKey("Flags"),achInfo.flags);
        json.put(formatKey("Description"),achInfo.description);
        json.put(formatKey("Points"),achInfo.points);
        json.put(formatKey("Params"),achInfo.params);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNAchievementsProvider.PlayerAchievementInfo achInfo) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("Id"),achInfo.id);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNVItemsProvider.GameVItemInfo gameVItemInfo) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("Id"),gameVItemInfo.id);
        json.put(formatKey("Name"),gameVItemInfo.name);
        json.put(formatKey("Model"),gameVItemInfo.model);
        json.put(formatKey("Description"),gameVItemInfo.description);
        json.put(formatKey("Params"),gameVItemInfo.params);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNVItemsProvider.PlayerVItemInfo playerVItemInfo) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("Id"),playerVItemInfo.id);
        json.put(formatKey("Count"),playerVItemInfo.count);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNVItemsProvider.TransactionVItemInfo transVItemInfo) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("Id"),transVItemInfo.id);
        json.put(formatKey("Delta"),transVItemInfo.delta);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNVItemsProvider.TransactionInfo transInfo) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("ClientTransactionId"),transInfo.clientTransactionId);
        json.put(formatKey("ServerTransactionId"),transInfo.serverTransactionId);
        json.put(formatKey("CorrUserId"),transInfo.corrUserId);
        json.put(formatKey("VItems"),getJSONElement(transInfo.vItems).getElement(JSONArray.class));

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNVItemsProvider.TransactionError transError) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("ClientTransactionId"),transError.clientTransactionId);
        json.put(formatKey("ServerTransactionId"),transError.serverTransactionId);
        json.put(formatKey("CorrUserId"),transError.corrUserId);
        json.put(formatKey("FailReasonCode"),transError.failReasonCode);
        json.put(formatKey("ErrorMessage"),transError.errorMessage);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNVShopProvider.VShopDeliveryInfo deliveryInfo) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("VItemId"),deliveryInfo.vItemId);
        json.put(formatKey("Amount"),deliveryInfo.amount);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNVShopProvider.VShopPackInfo vPackInfo) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("Id"),vPackInfo.id);
        json.put(formatKey("Name"),vPackInfo.name);
        json.put(formatKey("Model"),vPackInfo.model);
        json.put(formatKey("Description"),vPackInfo.description);
        json.put(formatKey("AppParams"),vPackInfo.appParams);
        json.put(formatKey("SortPos"),vPackInfo.sortPos);
        json.put(formatKey("CategoryId"),vPackInfo.categoryId);
        json.put(formatKey("Delivery"),getJSONElement(vPackInfo.delivery).getElement(JSONArray.class));
        json.put(formatKey("PriceItemId"),vPackInfo.priceItemId);
        json.put(formatKey("PriceValue"),vPackInfo.priceValue);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNVShopProvider.VShopCategoryInfo vCategoryInfo) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("Id"),vCategoryInfo.id);
        json.put(formatKey("Name"),vCategoryInfo.name);
        json.put(formatKey("SortPos"),vCategoryInfo.sortPos);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNVShopProvider.VShopPackBuyRequestItem vPackRequest) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("Id"),vPackRequest.id);
        json.put(formatKey("Amount"),vPackRequest.amount);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNVShopProvider.IEventHandler.CheckoutVShopPackSuccessInfo successInfo) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("Transaction"),getJSONElement(successInfo.getTransaction()).jsonObject);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNVShopProvider.IEventHandler.CheckoutVShopPackFailInfo failInfo) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("ErrorCode"),failInfo.getErrorCode());
        json.put(formatKey("ErrorMessage"),failInfo.getErrorMessage());
        json.put(formatKey("ClientTransactionId"),failInfo.getClientTransactionId());

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNGameSettingsProvider.GameSettingInfo settingInfo) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("Id"),settingInfo.getId());
        json.put(formatKey("Name"),settingInfo.getName());
        json.put(formatKey("Params"),settingInfo.getParams());
        json.put(formatKey("SysParams"),settingInfo.getSysParams());
        json.put(formatKey("MultiplayerEnabled"),settingInfo.isMultiplayerEnabled());
        json.put(formatKey("LeaderboardVisible"),settingInfo.isLeaderboardVisible());

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSAnyGameItem item) throws JSONException {
        if (item == null) {
            return null;
        }

        JSONObject json = new JSONObject();

        json.put(formatKey("GameId"),item.getGameId() == null ? JSONObject.NULL : item.getGameId());
        json.put(formatKey("GameName"),item.getGameName() == null ? JSONObject.NULL : item.getGameName());
        json.put(formatKey("GameDesc"),item.getGameDesc() == null ? JSONObject.NULL : item.getGameDesc());
        json.put(formatKey("GameGenreId"),item.getGameGenreId() == null ? JSONObject.NULL : item.getGameGenreId());
        json.put(formatKey("GameFlags"),item.getGameFlags() == null ? JSONObject.NULL : item.getGameFlags());
        json.put(formatKey("GameStatus"),item.getGameStatus() == null ? JSONObject.NULL : item.getGameStatus());
        json.put(formatKey("GamePlayModel"),item.getGamePlayModel() == null ? JSONObject.NULL : item.getGamePlayModel());
        json.put(formatKey("GameIconUrl"),item.getGameIconUrl() == null ? JSONObject.NULL : item.getGameIconUrl());
        json.put(formatKey("DeveloperId"),item.getDeveloperId() == null ? JSONObject.NULL : item.getDeveloperId());

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSInfoRequestAnyGame.RequestResult result) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("HadError"),result.hadError());
        json.put(formatKey("ErrorMessage"),result.getErrorMessage() == null ? "" : result.getErrorMessage());

        MNJsonElement dataEntryJson = getJSONElement(result.getDataEntry());

        json.put(formatKey("DataEntry"),dataEntryJson != null ? dataEntryJson.jsonObject : JSONObject.NULL);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSAnyUserItem item) throws JSONException {
        if (item == null) {
            return null;
        }

        JSONObject json = new JSONObject();

        json.put(formatKey("UserId"),item.getUserId() == null ? JSONObject.NULL : item.getUserId());
        json.put(formatKey("UserNickName"),item.getUserNickName() == null ? JSONObject.NULL : item.getUserNickName());
        json.put(formatKey("UserAvatarExists"),item.getUserAvatarExists() == null ? JSONObject.NULL : item.getUserAvatarExists());
        json.put(formatKey("UserAvatarUrl"),item.getUserAvatarUrl() == null ? JSONObject.NULL : item.getUserAvatarUrl());
        json.put(formatKey("UserOnlineNow"),item.getUserOnlineNow() == null ? JSONObject.NULL : item.getUserOnlineNow());
        json.put(formatKey("UserGamePoints"),item.getUserGamePoints() == null ? JSONObject.NULL : item.getUserGamePoints());
        json.put(formatKey("MyFriendLinkStatus"),item.getMyFriendLinkStatus() == null ? JSONObject.NULL : item.getMyFriendLinkStatus());

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSInfoRequestAnyUser.RequestResult result) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("HadError"),result.hadError());
        json.put(formatKey("ErrorMessage"),result.getErrorMessage() == null ? "" : result.getErrorMessage());

        MNJsonElement dataEntryJson = getJSONElement(result.getDataEntry());

        json.put(formatKey("DataEntry"),dataEntryJson != null ? dataEntryJson.jsonObject : JSONObject.NULL);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSUserGameCookie item) throws JSONException {
        if (item == null) {
            return null;
        }

        JSONObject json = new JSONObject();

        json.put(formatKey("UserId"),item.getUserId() == null ? JSONObject.NULL : item.getUserId());
        json.put(formatKey("CookieKey"),item.getCookieKey() == null ? JSONObject.NULL : item.getCookieKey());
        json.put(formatKey("CookieValue"),item.getCookieValue() == null ? JSONObject.NULL : item.getCookieValue());

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSInfoRequestAnyUserGameCookies.RequestResult result) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("HadError"),result.hadError());
        json.put(formatKey("ErrorMessage"),result.getErrorMessage() == null ? "" : result.getErrorMessage());

        MNJsonElement dataEntryJson = getJSONElement(result.getDataEntry());

        json.put(formatKey("DataEntry"),dataEntryJson != null ? dataEntryJson.jsonArray : JSONObject.NULL);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSCurrentUserInfo item) throws JSONException {
        if (item == null) {
            return null;
        }

        JSONObject json = new JSONObject();

        json.put(formatKey("UserId"),item.getUserId() == null ? JSONObject.NULL : item.getUserId());
        json.put(formatKey("UserNickName"),item.getUserNickName() == null ? JSONObject.NULL : item.getUserNickName());
        json.put(formatKey("UserAvatarExists"),item.getUserAvatarExists() == null ? JSONObject.NULL : item.getUserAvatarExists());
        json.put(formatKey("UserAvatarUrl"),item.getUserAvatarUrl() == null ? JSONObject.NULL : item.getUserAvatarUrl());
        json.put(formatKey("UserOnlineNow"),item.getUserOnlineNow() == null ? JSONObject.NULL : item.getUserOnlineNow());
        json.put(formatKey("UserGamePoints"),item.getUserGamePoints() == null ? JSONObject.NULL : item.getUserGamePoints());
        json.put(formatKey("UserEmail"),item.getUserEmail() == null ? JSONObject.NULL : item.getUserEmail());
        json.put(formatKey("UserStatus"),item.getUserStatus() == null ? JSONObject.NULL : item.getUserStatus());
        json.put(formatKey("UserAvatarHasCustomImg"),item.getUserAvatarHasCustomImg() == null ? JSONObject.NULL : item.getUserAvatarHasCustomImg());
        json.put(formatKey("UserAvatarHasExternalUrl"),item.getUserAvatarHasExternalUrl() == null ? JSONObject.NULL : item.getUserAvatarHasExternalUrl());

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSInfoRequestCurrentUserInfo.RequestResult result) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("HadError"),result.hadError());
        json.put(formatKey("ErrorMessage"),result.getErrorMessage() == null ? "" : result.getErrorMessage());

        MNJsonElement dataEntryJson = getJSONElement(result.getDataEntry());

        json.put(formatKey("DataEntry"),dataEntryJson != null ? dataEntryJson.jsonObject : JSONObject.NULL);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSRoomListItem item) throws JSONException {
        if (item == null) {
            return null;
        }

        JSONObject json = new JSONObject();

        json.put(formatKey("GameId"),item.getGameId() == null ? JSONObject.NULL : item.getGameId());
        json.put(formatKey("RoomSFId"),item.getRoomSFId() == null ? JSONObject.NULL : item.getRoomSFId());
        json.put(formatKey("RoomName"),item.getRoomName() == null ? JSONObject.NULL : item.getRoomName());
        json.put(formatKey("RoomUserCount"),item.getRoomUserCount() == null ? JSONObject.NULL : item.getRoomUserCount());
        json.put(formatKey("RoomIsLobby"),item.getRoomIsLobby() == null ? JSONObject.NULL : item.getRoomIsLobby());
        json.put(formatKey("GameSetId"),item.getGameSetId() == null ? JSONObject.NULL : item.getGameSetId());

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSInfoRequestCurrGameRoomList.RequestResult result) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("HadError"),result.hadError());
        json.put(formatKey("ErrorMessage"),result.getErrorMessage() == null ? "" : result.getErrorMessage());

        MNJsonElement dataEntryJson = getJSONElement(result.getDataEntry());

        json.put(formatKey("DataEntry"),dataEntryJson != null ? dataEntryJson.jsonArray : JSONObject.NULL);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSRoomUserInfoItem item) throws JSONException {
        if (item == null) {
            return null;
        }

        JSONObject json = new JSONObject();

        json.put(formatKey("UserId"),item.getUserId() == null ? JSONObject.NULL : item.getUserId());
        json.put(formatKey("UserNickName"),item.getUserNickName() == null ? JSONObject.NULL : item.getUserNickName());
        json.put(formatKey("UserAvatarExists"),item.getUserAvatarExists() == null ? JSONObject.NULL : item.getUserAvatarExists());
        json.put(formatKey("UserAvatarUrl"),item.getUserAvatarUrl() == null ? JSONObject.NULL : item.getUserAvatarUrl());
        json.put(formatKey("UserOnlineNow"),item.getUserOnlineNow() == null ? JSONObject.NULL : item.getUserOnlineNow());
        json.put(formatKey("RoomSFId"),item.getRoomSFId() == null ? JSONObject.NULL : item.getRoomSFId());

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSInfoRequestCurrGameRoomUserList.RequestResult result) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("HadError"),result.hadError());
        json.put(formatKey("ErrorMessage"),result.getErrorMessage() == null ? "" : result.getErrorMessage());

        MNJsonElement dataEntryJson = getJSONElement(result.getDataEntry());

        json.put(formatKey("DataEntry"),dataEntryJson != null ? dataEntryJson.jsonArray : JSONObject.NULL);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSBuddyListItem item) throws JSONException {
        if (item == null) {
            return null;
        }

        JSONObject json = new JSONObject();

        json.put(formatKey("FriendUserId"),item.getFriendUserId() == null ? JSONObject.NULL : item.getFriendUserId());
        json.put(formatKey("FriendUserNickName"),item.getFriendUserNickName() == null ? JSONObject.NULL : item.getFriendUserNickName());
        json.put(formatKey("FriendSnIdList"),item.getFriendSnIdList() == null ? JSONObject.NULL : item.getFriendSnIdList());
        json.put(formatKey("FriendSnUserAsnIdList"),item.getFriendSnUserAsnIdList() == null ? JSONObject.NULL : item.getFriendSnUserAsnIdList());
        json.put(formatKey("FriendInGameId"),item.getFriendInGameId() == null ? JSONObject.NULL : item.getFriendInGameId());
        json.put(formatKey("FriendInGameName"),item.getFriendInGameName() == null ? JSONObject.NULL : item.getFriendInGameName());
        json.put(formatKey("FriendInGameIconUrl"),item.getFriendInGameIconUrl() == null ? JSONObject.NULL : item.getFriendInGameIconUrl());
        json.put(formatKey("FriendHasCurrentGame"),item.getFriendHasCurrentGame() == null ? JSONObject.NULL : item.getFriendHasCurrentGame());
        json.put(formatKey("FriendUserLocale"),item.getFriendUserLocale() == null ? JSONObject.NULL : item.getFriendUserLocale());
        json.put(formatKey("FriendUserAvatarUrl"),item.getFriendUserAvatarUrl() == null ? JSONObject.NULL : item.getFriendUserAvatarUrl());
        json.put(formatKey("FriendUserOnlineNow"),item.getFriendUserOnlineNow() == null ? JSONObject.NULL : item.getFriendUserOnlineNow());
        json.put(formatKey("FriendUserSfid"),item.getFriendUserSfid() == null ? JSONObject.NULL : item.getFriendUserSfid());
        json.put(formatKey("FriendSnId"),item.getFriendSnId() == null ? JSONObject.NULL : item.getFriendSnId());
        json.put(formatKey("FriendSnUserAsnId"),item.getFriendSnUserAsnId() == null ? JSONObject.NULL : item.getFriendSnUserAsnId());
        json.put(formatKey("FriendFlags"),item.getFriendFlags() == null ? JSONObject.NULL : item.getFriendFlags());
        json.put(formatKey("FriendIsIgnored"),item.getFriendIsIgnored() == null ? JSONObject.NULL : item.getFriendIsIgnored());
        json.put(formatKey("FriendInRoomSfid"),item.getFriendInRoomSfid() == null ? JSONObject.NULL : item.getFriendInRoomSfid());
        json.put(formatKey("FriendInRoomIsLobby"),item.getFriendInRoomIsLobby() == null ? JSONObject.NULL : item.getFriendInRoomIsLobby());
        json.put(formatKey("FriendCurrGameAchievementsList"),item.getFriendCurrGameAchievementsList() == null ? JSONObject.NULL : item.getFriendCurrGameAchievementsList());

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSInfoRequestCurrUserBuddyList.RequestResult result) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("HadError"),result.hadError());
        json.put(formatKey("ErrorMessage"),result.getErrorMessage() == null ? "" : result.getErrorMessage());

        MNJsonElement dataEntryJson = getJSONElement(result.getDataEntry());

        json.put(formatKey("DataEntry"),dataEntryJson != null ? dataEntryJson.jsonArray : JSONObject.NULL);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSCurrUserSubscriptionStatus item) throws JSONException {
        if (item == null) {
            return null;
        }

        JSONObject json = new JSONObject();

        json.put(formatKey("HasSubscription"),item.getHasSubscription() == null ? JSONObject.NULL : item.getHasSubscription());
        json.put(formatKey("OffersAvailable"),item.getOffersAvailable() == null ? JSONObject.NULL : item.getOffersAvailable());
        json.put(formatKey("IsSubscriptionAvailable"),item.getIsSubscriptionAvailable() == null ? JSONObject.NULL : item.getIsSubscriptionAvailable());

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSInfoRequestCurrUserSubscriptionStatus.RequestResult result) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("HadError"),result.hadError());
        json.put(formatKey("ErrorMessage"),result.getErrorMessage() == null ? "" : result.getErrorMessage());

        MNJsonElement dataEntryJson = getJSONElement(result.getDataEntry());

        json.put(formatKey("DataEntry"),dataEntryJson != null ? dataEntryJson.jsonObject : JSONObject.NULL);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSSessionSignedClientToken item) throws JSONException {
        if (item == null) {
            return null;
        }

        JSONObject json = new JSONObject();

        json.put(formatKey("ClientTokenBody"),item.getClientTokenBody() == null ? JSONObject.NULL : item.getClientTokenBody());
        json.put(formatKey("ClientTokenSign"),item.getClientTokenSign() == null ? JSONObject.NULL : item.getClientTokenSign());

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSInfoRequestSessionSignedClientToken.RequestResult result) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("HadError"),result.hadError());
        json.put(formatKey("ErrorMessage"),result.getErrorMessage() == null ? "" : result.getErrorMessage());

        MNJsonElement dataEntryJson = getJSONElement(result.getDataEntry());

        json.put(formatKey("DataEntry"),dataEntryJson != null ? dataEntryJson.jsonObject : JSONObject.NULL);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSSystemGameNetStats item) throws JSONException {
        if (item == null) {
            return null;
        }

        JSONObject json = new JSONObject();

        json.put(formatKey("ServTotalUsers"),item.getServTotalUsers() == null ? JSONObject.NULL : item.getServTotalUsers());
        json.put(formatKey("ServTotalGames"),item.getServTotalGames() == null ? JSONObject.NULL : item.getServTotalGames());
        json.put(formatKey("ServOnlineUsers"),item.getServOnlineUsers() == null ? JSONObject.NULL : item.getServOnlineUsers());
        json.put(formatKey("ServOnlineRooms"),item.getServOnlineRooms() == null ? JSONObject.NULL : item.getServOnlineRooms());
        json.put(formatKey("ServOnlineGames"),item.getServOnlineGames() == null ? JSONObject.NULL : item.getServOnlineGames());
        json.put(formatKey("GameOnlineUsers"),item.getGameOnlineUsers() == null ? JSONObject.NULL : item.getGameOnlineUsers());
        json.put(formatKey("GameOnlineRooms"),item.getGameOnlineRooms() == null ? JSONObject.NULL : item.getGameOnlineRooms());

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSInfoRequestSystemGameNetStats.RequestResult result) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("HadError"),result.hadError());
        json.put(formatKey("ErrorMessage"),result.getErrorMessage() == null ? "" : result.getErrorMessage());

        MNJsonElement dataEntryJson = getJSONElement(result.getDataEntry());

        json.put(formatKey("DataEntry"),dataEntryJson != null ? dataEntryJson.jsonObject : JSONObject.NULL);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSLeaderboardListItem item) throws JSONException {
        if (item == null) {
            return null;
        }

        JSONObject json = new JSONObject();
        /*
        MNExtWrapper.DLog("GameId="+((item.getGameId()==null)?"null":item.getGameId().toString())+
        ";UserId="+((item.getUserId()==null)?"null":item.getUserId().toString())+
        ";UserNickName="+((item.getUserNickName()==null)?"null":item.getUserNickName().toString())+
        ";UserAvatarUrl="+((item.getUserAvatarUrl()==null)?"null":item.getUserAvatarUrl().toString())+
        ";UserOnlineNow="+((item.getUserOnlineNow()==null)?"null":item.getUserOnlineNow().toString())+
        ";UserIsFriend="+((item.getUserIsFriend()==null)?"null":item.getUserIsFriend().toString())+
        ";UserSfid="+((item.getUserSfid()==null)?"null":item.getUserSfid().toString())+
        ";UserIsIgnored="+((item.getUserIsIgnored()==null)?"null":item.getUserIsIgnored().toString())+
        ";UserLocale="+((item.getUserLocale()==null)?"null":item.getUserLocale().toString())+
        ";OutHiScore="+((item.getOutHiScore()==null)?"null":item.getOutHiScore().toString())+
        ";OutHiScoreText="+((item.getOutHiScoreText()==null)?"null":item.getOutHiScoreText().toString())+
        ";OutHiDateTime="+((item.getOutHiDateTime()==null)?"null":item.getOutHiDateTime().toString())+
        ";OutHiDateTimeDiff="+((item.getOutHiDateTimeDiff()==null)?"null":item.getOutHiDateTimeDiff().toString())+
        ";OutUserPlace="+((item.getOutUserPlace()==null)?"null":item.getOutUserPlace().toString())+
        ";GamesetId="+((item.getGamesetId()==null)?"null":item.getGamesetId().toString())+
        ";UserAchievementsList="+((item.getUserAchievementsList()==null)?"null":item.getUserAchievementsList().toString()));
        */
        json.put(formatKey("GameId"),item.getGameId() == null ? JSONObject.NULL : item.getGameId());
        json.put(formatKey("UserId"),item.getUserId() == null ? JSONObject.NULL : item.getUserId());
        json.put(formatKey("UserNickName"),item.getUserNickName() == null ? JSONObject.NULL : item.getUserNickName());
        json.put(formatKey("UserAvatarUrl"),item.getUserAvatarUrl() == null ? JSONObject.NULL : item.getUserAvatarUrl());
        json.put(formatKey("UserOnlineNow"),item.getUserOnlineNow() == null ? JSONObject.NULL : item.getUserOnlineNow());
        json.put(formatKey("UserIsFriend"),item.getUserIsFriend() == null ? JSONObject.NULL : item.getUserIsFriend());
        json.put(formatKey("UserSfid"),item.getUserSfid() == null ? JSONObject.NULL : item.getUserSfid());
        json.put(formatKey("UserIsIgnored"),item.getUserIsIgnored() == null ? JSONObject.NULL : item.getUserIsIgnored());
        json.put(formatKey("UserLocale"),item.getUserLocale() == null ? JSONObject.NULL : item.getUserLocale());
        json.put(formatKey("OutHiScore"),item.getOutHiScore() == null ? JSONObject.NULL : item.getOutHiScore());
        json.put(formatKey("OutHiScoreText"),item.getOutHiScoreText() == null ? JSONObject.NULL : item.getOutHiScoreText());
        json.put(formatKey("OutHiDateTime"),item.getOutHiDateTime() == null ? JSONObject.NULL : item.getOutHiDateTime());
        json.put(formatKey("OutHiDateTimeDiff"),item.getOutHiDateTimeDiff() == null ? JSONObject.NULL : item.getOutHiDateTimeDiff());
        json.put(formatKey("OutUserPlace"),item.getOutUserPlace() == null ? JSONObject.NULL : item.getOutUserPlace());
        json.put(formatKey("GamesetId"),item.getGamesetId() == null ? JSONObject.NULL : item.getGamesetId());
        json.put(formatKey("UserAchievementsList"),item.getUserAchievementsList() == null ? JSONObject.NULL : item.getUserAchievementsList());

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNWSInfoRequestLeaderboard.RequestResult result) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("HadError"),result.hadError());
        json.put(formatKey("ErrorMessage"),result.getErrorMessage() == null ? "" : result.getErrorMessage());

        MNJsonElement dataEntryJson = getJSONElement(result.getDataEntry());

        json.put(formatKey("DataEntry"),dataEntryJson != null ? dataEntryJson.jsonArray : JSONObject.NULL);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNScoreProgressProvider.ScoreItem scoreItem) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("UserInfo"),getJSONElement(scoreItem.userInfo).jsonObject);
        json.put(formatKey("Score"),scoreItem.score);
        json.put(formatKey("Place"),scoreItem.place);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNBuddyRoomParams buddyRoomParams) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("RoomName"),buddyRoomParams.roomName);
        json.put(formatKey("GameSetId"),buddyRoomParams.gameSetId);
        json.put(formatKey("ToUserIdList"),buddyRoomParams.toUserIdList);
        json.put(formatKey("ToUserSFIdList"),buddyRoomParams.toUserSFIdList);
        json.put(formatKey("InviteText"),buddyRoomParams.inviteText);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNJoinRoomInvitationParams params) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("RoomGameId"),params.roomGameId);
        json.put(formatKey("RoomName"),params.roomName);
        json.put(formatKey("RoomSFId"),params.roomSFId);
        json.put(formatKey("InviteText"),params.inviteText);
        json.put(formatKey("RoomGameSetId"),params.roomGameSetId);
        json.put(formatKey("FromUserName"),params.fromUserName);
        json.put(formatKey("FromUserSFId"),params.fromUserSFId);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(MNCurrGameResults params) throws JSONException {
        JSONObject json = new JSONObject();

        json.put(formatKey("gameId"),params.gameId);
        json.put(formatKey("gameSetId"),params.gameSetId);
        json.put(formatKey("finalResult"),params.finalResult);
        json.put(formatKey("playRoundNumber"),params.playRoundNumber);

        MNJsonElement userPlacesJson = getJSONElement(params.userPlaces);
        MNJsonElement userScoresJson = getJSONElement(params.userScores);
        MNJsonElement usersJson = getJSONElement(params.users);

        json.put(formatKey("userPlaces"),userPlacesJson != null ? userPlacesJson.jsonArray : JSONObject.NULL);
        json.put(formatKey("userScores"),userScoresJson != null ? userScoresJson.jsonArray : JSONObject.NULL);
        json.put(formatKey("users"),usersJson != null ? usersJson.jsonArray : JSONObject.NULL);

        return new MNJsonElement(json);
    }

    protected MNJsonElement getJSONElement(Map<?,?> srcMap) {
        try {
            JSONObject json = new JSONObject();

            for (Object key : srcMap.keySet()) {
                Object value = srcMap.get(key);

                if (value == null) {
                    json.put(key.toString(),JSONObject.NULL);
                }
                else {
                    MNJsonElement jsonElement = getJSONElement(value);

                    if (jsonElement == null) {
                        // value for the key can not be represented with valid json string (it could have primitive type)
                        json.put(key.toString(),value);
                    }
                    else if (jsonElement.isArray()) {
                        json.put(key.toString(),jsonElement.getElement(JSONArray.class));
                    }
                    else if (jsonElement.isObject()) {
                        json.put(key.toString(),jsonElement.getElement(JSONObject.class));
                    }
                    else {
                        throw new JSONException("");
                    }
                }
            }

            return new MNJsonElement(json);
        }
        catch (JSONException e) {
            MNExtWrapper.DLog("Can not create JSONObject from " + srcMap.getClass().getSimpleName());
            e.printStackTrace();
        }

        return null;
    }

    protected MNJsonElement getJSONArrayFromMap(Map<?,?> srcMap) {
        Object[] dstArray = new Object[srcMap.size() * 2];

        int index = 0;
        for (Object key : srcMap.keySet()) {
            dstArray[index++] = key;
            dstArray[index++] = srcMap.get(key);
        }

        return getJSONElement(dstArray);
    }

    protected <K, V> Map<K,V> getMapFromJSONArray(String jsonString,Class<K> keyType,Class<V> valueType) {
        try {
            Map<K,V> resultMap = new HashMap<K,V>();
            K key;
            V value;

            JSONArray mapJsonArray = new JSONArray(jsonString);

            int index = 0;

            if (mapJsonArray.length() % 2 != 0) {
                MNExtWrapper.ELog("Invalid Map serialization: <<" + jsonString + ">>");
                return null;
            }

            while (index < mapJsonArray.length()) {
                if ((keyType.equals(Integer.class)) || (keyType.equals(Integer.TYPE))) {
                    key = getJSONArrayElement(mapJsonArray,index,keyType);
                    value = getJSONArrayElement(mapJsonArray,index + 1,valueType);

                    resultMap.put(key,value);
                    index += 2;
                }
            }

            return resultMap;
        }
        catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
    }

    protected <T> T getObjectFromJSON(String jsonString,Class<T> type) {
        try {
            if (type.isArray()) {
                if (type.equals(Class.forName("[I"))) {
                    Integer[] intArray = getObjectFromJSONArray(jsonString,Integer.class);

                    return type.cast(integerArrayToPrimitiveIntArray(intArray));
                }
                else if (type.equals(Class.forName("[J"))) {
                    Long[] longArray = getObjectFromJSONArray(jsonString,Long.class);

                    return type.cast(longArrayToPrimitiveLongArray(longArray));
                }
                else if (type.equals(Class.forName("[D"))) {
                    Double[] longArray = getObjectFromJSONArray(jsonString,Double.class);

                    return type.cast(doubleArrayToPrimitiveDoubleArray(longArray));
                }
                else if (type.equals(Class.forName("[Z"))) {
                    Boolean[] longArray = getObjectFromJSONArray(jsonString,Boolean.class);

                    return type.cast(booleanArrayToPrimitiveBooleanArray(longArray));
                }

                return type.cast(getObjectFromJSONArray(jsonString,type.getComponentType()));
            }
            else {
                JSONObject json = new JSONObject(jsonString);
                return getObjectFromJSONObject(json,type);
            }
        }
        catch (JSONException e) {
            e.printStackTrace();
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return null;
    }

    private <T> T getObjectFromJSONObject(JSONObject json,Class<T> type) {
        try {
            if (type == MNErrorInfo.class) {
                MNErrorInfo error;
                error = new MNErrorInfo(json.getInt(formatKey("ActionCode")),json.getString(formatKey("ErrorMessage")));

                return type.cast(error);
            }
            else if (type == MNGameParams.class) {
                MNGameParams gameParams = new MNGameParams(json.getInt(formatKey("GameSetId")),
                                                           json.getString(formatKey("GameSetParams")),
                                                           json.getString(formatKey("ScorePostLinkId")),
                                                           json.getInt(formatKey("GameSeed")),
                                                           json.getInt(formatKey("PlayModel")));

                return type.cast(gameParams);
            }
            else if (type == MNUserInfo.class) {
                String webBaseUrl = null;

                if (MNDirect.getSession() != null) {
                    webBaseUrl = MNDirect.getSession().getWebServerURL();
                }

                MNUserInfo userInfo = new MNUserInfo(json.getLong(formatKey("UserId")),
                                                     json.getInt(formatKey("UserSFId")),
                                                     json.getString(formatKey("UserName")),
                                                     webBaseUrl);

                return type.cast(userInfo);
            }
            else if (type == MNAchievementsProvider.GameAchievementInfo.class) {
                MNAchievementsProvider.GameAchievementInfo achInfo = new MNAchievementsProvider.GameAchievementInfo(json.getInt(formatKey("Id")),
                                                                                                                    json.getString(formatKey("Name")),
                                                                                                                    json.getInt(formatKey("Flags")),
                                                                                                                    json.getString(formatKey("Description")),
                                                                                                                    json.getString(formatKey("Params")),
                                                                                                                    json.getInt(formatKey("Points")));

                return type.cast(achInfo);
            }
            else if (type == MNAchievementsProvider.PlayerAchievementInfo.class) {
                MNAchievementsProvider.PlayerAchievementInfo achInfo = new MNAchievementsProvider.PlayerAchievementInfo(json.getInt(formatKey("Id")));

                return type.cast(achInfo);
            }
            else if (type == MNVItemsProvider.GameVItemInfo.class) {
                MNVItemsProvider.GameVItemInfo gameVItemInfo = new MNVItemsProvider.GameVItemInfo(json.getInt(formatKey("Id")),
                                                                                                  json.getString(formatKey("Name")),
                                                                                                  json.getInt(formatKey("Model")),
                                                                                                  json.getString(formatKey("Description")),
                                                                                                  json.getString(formatKey("Params")));
                return type.cast(gameVItemInfo);
            }
            else if (type == MNVItemsProvider.PlayerVItemInfo.class) {
                MNVItemsProvider.PlayerVItemInfo playerVItemInfo = new MNVItemsProvider.PlayerVItemInfo(json.getInt(formatKey("Id")),
                                                                                                        json.getLong(formatKey("Count")));
                return type.cast(playerVItemInfo);
            }
            else if (type == MNVItemsProvider.TransactionVItemInfo.class) {
                MNVItemsProvider.TransactionVItemInfo transVItemInfo = new MNVItemsProvider.TransactionVItemInfo(json.getInt(formatKey("Id")),
                                                                                                                 json.getLong(formatKey("Delta")));
                return type.cast(transVItemInfo);
            }
            else if (type == MNVItemsProvider.TransactionInfo.class) {
                JSONArray vItemsJsonArray = json.getJSONArray(formatKey("VItems"));

                MNVItemsProvider.TransactionVItemInfo[] vItems = null;

                if (vItemsJsonArray.length() > 0) {
                    vItems = new MNVItemsProvider.TransactionVItemInfo[vItemsJsonArray.length()];

                    for (int index = 0; index < vItemsJsonArray.length(); index++) {
                        vItems[index] = getObjectFromJSON(vItemsJsonArray.getJSONObject(index).toString(),MNVItemsProvider.TransactionVItemInfo.class);
                    }
                }

                MNVItemsProvider.TransactionInfo transInfo = new MNVItemsProvider.TransactionInfo(json.getLong(formatKey("ClientTransactionId")),
                                                                                                  json.getLong(formatKey("ServerTransactionId")),
                                                                                                  json.getLong(formatKey("CorrUserId")),
                                                                                                  vItems);

                return type.cast(transInfo);
            }
            else if (type == MNVItemsProvider.TransactionError.class) {
                MNVItemsProvider.TransactionError transError = new MNVItemsProvider.TransactionError(json.getLong(formatKey("ClientTransactionId")),
                                                                                                     json.getLong(formatKey("ServerTransactionId")),
                                                                                                     json.getLong(formatKey("CorrUserId")),
                                                                                                     json.getInt(formatKey("FailReasonCode")),
                                                                                                     json.getString(formatKey("ErrorMessage")));
                return type.cast(transError);
            }
            else if (type == MNVShopProvider.VShopDeliveryInfo.class) {
                MNVShopProvider.VShopDeliveryInfo transError = new MNVShopProvider.VShopDeliveryInfo(json.getInt(formatKey("VItemId")),
                                                                                                     json.getLong(formatKey("Amount")));
                return type.cast(transError);
            }
            else if (type == MNVShopProvider.VShopPackInfo.class) {
                int id = json.getInt(formatKey("Id"));
                String name = json.getString(formatKey("Name"));
                int model = json.getInt(formatKey("Model"));
                String description = json.getString(formatKey("Description"));
                String appParams = json.getString(formatKey("AppParams"));
                int sortPos = json.getInt(formatKey("SortPos"));
                int categoryId = json.getInt(formatKey("CategoryId"));
                int priceItemId = json.getInt(formatKey("PriceItemId"));
                long priceValue = json.getLong(formatKey("PriceValue"));

                JSONArray deliveryJsonArray = json.getJSONArray(formatKey("Delivery"));

                MNVShopProvider.VShopDeliveryInfo[] deliveryInfoItems = null;

                if (deliveryJsonArray.length() > 0) {
                    deliveryInfoItems = new MNVShopProvider.VShopDeliveryInfo[deliveryJsonArray.length()];

                    for (int index = 0; index < deliveryJsonArray.length(); index++) {
                        deliveryInfoItems[index] = getObjectFromJSON(deliveryJsonArray.getJSONObject(index).toString(),MNVShopProvider.VShopDeliveryInfo.class);
                    }
                }

                MNVShopProvider.VShopPackInfo vPackInfo = new MNVShopProvider.VShopPackInfo(id,name);
                vPackInfo.model = model;
                vPackInfo.description = description;
                vPackInfo.appParams = appParams;
                vPackInfo.sortPos = sortPos;
                vPackInfo.categoryId = categoryId;
                vPackInfo.priceItemId = priceItemId;
                vPackInfo.priceValue = priceValue;
                vPackInfo.delivery = deliveryInfoItems.clone();

                return type.cast(vPackInfo);
            }
            else if (type == MNVShopProvider.VShopCategoryInfo.class) {
                int id = json.getInt(formatKey("Id"));
                String name = json.getString(formatKey("Name"));
                int sortPos = json.getInt(formatKey("SortPos"));

                MNVShopProvider.VShopCategoryInfo categoryinfo = new MNVShopProvider.VShopCategoryInfo(id,name);
                categoryinfo.sortPos = sortPos;

                return type.cast(categoryinfo);
            }
            else if (type == MNVShopProvider.VShopPackBuyRequestItem.class) {
                MNVShopProvider.VShopPackBuyRequestItem vPackBuyRequest = new MNVShopProvider.VShopPackBuyRequestItem(json.getInt(formatKey("Id")),
                                                                                                                      json.getLong(formatKey("Amount")));
                return type.cast(vPackBuyRequest);
            }
            else if (type == MNVShopProvider.IEventHandler.CheckoutVShopPackSuccessInfo.class) {
                MNVItemsProvider.TransactionInfo transaction = getObjectFromJSONObject(json.getJSONObject(formatKey("Transaction")),MNVItemsProvider.TransactionInfo.class);

                MNVShopProvider.IEventHandler.CheckoutVShopPackSuccessInfo successInfo = new MNVShopProvider.IEventHandler.CheckoutVShopPackSuccessInfo(transaction);

                return type.cast(successInfo);
            }
            else if (type == MNVShopProvider.IEventHandler.CheckoutVShopPackFailInfo.class) {
                MNVShopProvider.IEventHandler.CheckoutVShopPackFailInfo failInfo = new MNVShopProvider.IEventHandler.CheckoutVShopPackFailInfo(json.getInt(formatKey("ErrorCode")),
                                                                                                                                               json.getString(formatKey("ErrorMessage")),
                                                                                                                                               json.getLong(formatKey("ClientTransactionId")));

                return type.cast(failInfo);
            }
            else if (type == MNGameSettingsProvider.GameSettingInfo.class) {
                MNGameSettingsProvider.GameSettingInfo settingInfo = new MNGameSettingsProvider.GameSettingInfo(json.getInt(formatKey("Id")),
                                                                                                                json.getString(formatKey("Name")),
                                                                                                                json.getString(formatKey("Params")),
                                                                                                                json.getString(formatKey("SysParams")),
                                                                                                                json.getBoolean(formatKey("MultiplayerEnabled")),
                                                                                                                json.getBoolean(formatKey("LeaderboardVisible")));
                return type.cast(settingInfo);
            }
            else if (type == MNScoreProgressProvider.ScoreItem.class) {
                MNScoreProgressProvider.ScoreItem scoreItem = new MNScoreProgressProvider.ScoreItem(getObjectFromJSON(json.getJSONObject(formatKey("UserInfo")).toString(),MNUserInfo.class),
                                                                                                    json.getLong(formatKey("Score")),
                                                                                                    json.getInt(formatKey("Place")));

                return type.cast(scoreItem);
            }
            else if (type == MNWSInfoRequestLeaderboard.LeaderboardMode.class) {
                LeaderboardMode mode = null;
                String specificModeClassName = json.getString(formatKey("Mode"));

                if (specificModeClassName.equals("LeaderboardModeCurrentUser")) {
                    mode = new LeaderboardModeCurrentUser(json.getInt(formatKey("Scope")),
                                                          json.getInt(formatKey("Period")));
                }
                else if (specificModeClassName.equals("LeaderboardModeAnyGameGlobal")) {
                    mode = new LeaderboardModeAnyGameGlobal(json.getInt(formatKey("GameId")),
                                                            json.getInt(formatKey("GameSetId")),
                                                            json.getInt(formatKey("Period")));
                }
                else if (specificModeClassName.equals("LeaderboardModeAnyUserAnyGameGlobal")) {
                    mode = new LeaderboardModeAnyUserAnyGameGlobal(json.getLong(formatKey("UserId")),
                                                                   json.getInt(formatKey("GameId")),
                                                                   json.getInt(formatKey("GameSetId")),
                                                                   json.getInt(formatKey("Period")));
                }
                else if (specificModeClassName.equals("LeaderboardModeCurrUserAnyGameLocal")) {
                    mode = new LeaderboardModeCurrUserAnyGameLocal(json.getInt(formatKey("GameId")),
                                                                   json.getInt(formatKey("GameSetId")),
                                                                   json.getInt(formatKey("Period")));
                }
                else {
                    return null;
                }

                return type.cast(mode);
            }
            else if (type == MNBuddyRoomParams.class) {
                MNBuddyRoomParams params = new MNBuddyRoomParams(json.getString(formatKey("RoomName")),
                                                                 json.getInt(formatKey("GameSetId")),
                                                                 json.getString(formatKey("ToUserIdList")),
                                                                 json.getString(formatKey("ToUserSFIdList")),
                                                                 json.getString(formatKey("InviteText")));
                return type.cast(params);
            }
            else if (type == MNJoinRoomInvitationParams.class) {
                MNJoinRoomInvitationParams params = new MNJoinRoomInvitationParams(json.getInt(formatKey("FromUserSFId")),
                                                                                   json.getString(formatKey("FromUserName")),
                                                                                   json.getInt(formatKey("RoomSFId")),
                                                                                   json.getString(formatKey("RoomName")),
                                                                                   json.getInt(formatKey("RoomGameId")),
                                                                                   json.getInt(formatKey("RoomGameSetId")),
                                                                                   json.getString(formatKey("InviteText")));
                return type.cast(params);
            }
            else {
                return null;
            }
        }
        catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
    }

    protected <T> T[] getObjectFromJSONArray(String jsonString,Class<T> type) throws JSONException {
        JSONArray srcJSONArray = new JSONArray(jsonString);
        @SuppressWarnings("unchecked")
        T[] result = (T[])Array.newInstance(type,srcJSONArray.length());

        for (int index = 0; index < srcJSONArray.length(); index++) {
            result[index] = getJSONArrayElement(srcJSONArray,index,type);

            /*
            if ((type.equals(Integer.class)) || (type.equals(Integer.TYPE))) {
                result[index] = type.cast(srcJSONArray.getInt(index));
            }
            else {
                JSONObject childJSONObject = srcJSONArray.optJSONObject(index);

                if (childJSONObject != null) {
                    result[index] = getObjectFromJSON(childJSONObject.toString(),type);
                }
                else {
                    result[index] = getObjectFromJSON(srcJSONArray.getJSONArray(index).toString(),type);
                }
            }
            */
        }

        return result;
    }

    protected int[] integerArrayToPrimitiveIntArray(Integer[] srcArray) {
        int[] resultArray = new int[srcArray.length];

        for (int index = 0; index < srcArray.length; index++) {
            resultArray[index] = srcArray[index].intValue();
        }

        return resultArray;
    }

    protected long[] longArrayToPrimitiveLongArray(Long[] srcArray) {
        long[] resultArray = new long[srcArray.length];

        for (int index = 0; index < srcArray.length; index++) {
            resultArray[index] = srcArray[index].longValue();
        }

        return resultArray;
    }

    protected double[] doubleArrayToPrimitiveDoubleArray(Double[] srcArray) {
        double[] resultArray = new double[srcArray.length];

        for (int index = 0; index < srcArray.length; index++) {
            resultArray[index] = srcArray[index].doubleValue();
        }

        return resultArray;
    }

    protected boolean[] booleanArrayToPrimitiveBooleanArray(Boolean[] srcArray) {
        boolean[] resultArray = new boolean[srcArray.length];

        for (int index = 0; index < srcArray.length; index++) {
            resultArray[index] = srcArray[index].booleanValue();
        }

        return resultArray;
    }

    protected <T> T getJSONArrayElement(JSONArray srcJSONArray,int index,Class<T> elementType) throws JSONException {
        T result;

        if ((elementType.equals(Integer.class)) || (elementType.equals(Integer.TYPE))) {
            result = elementType.cast(srcJSONArray.getInt(index));
        }
        else if ((elementType.equals(Long.class)) || (elementType.equals(Long.TYPE))) {
            result = elementType.cast(srcJSONArray.getLong(index));
        }
        else if ((elementType.equals(Boolean.class)) || (elementType.equals(Boolean.TYPE))) {
            result = elementType.cast(srcJSONArray.getBoolean(index));
        }
        else if ((elementType.equals(Double.class)) || (elementType.equals(Double.TYPE))) {
            result = elementType.cast(srcJSONArray.getDouble(index));
        }
        else if (elementType.equals(String.class)) {
            result = elementType.cast(srcJSONArray.getString(index));
        }
        else {
            JSONObject childJSONObject = srcJSONArray.optJSONObject(index);

            if (childJSONObject != null) {
                result = getObjectFromJSON(childJSONObject.toString(),elementType);
            }
            else {
                result = getObjectFromJSON(srcJSONArray.getJSONArray(index).toString(),elementType);
            }
        }

        return result;
    }
}
