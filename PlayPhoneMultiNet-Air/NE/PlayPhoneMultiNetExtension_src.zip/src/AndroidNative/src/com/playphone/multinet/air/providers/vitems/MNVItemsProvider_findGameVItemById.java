package com.playphone.multinet.air.providers.vitems;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.providers.MNVItemsProvider;

public class MNVItemsProvider_findGameVItemById implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            MNVItemsProvider.GameVItemInfo item = MNDirect.getVItemsProvider().findGameVItemById( freObjects[0].getAsInt() );
            ret = FREObject.newObject("com.playphone.multinet.providers.GameVItemInfo",
                                      new FREObject[]
                                      {
                                              FREObject.newObject(item.id),
                                              FREObject.newObject(item.name),
                                              FREObject.newObject(item.model),
                                              FREObject.newObject(item.description),
                                              FREObject.newObject(item.params)
                                      });
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
