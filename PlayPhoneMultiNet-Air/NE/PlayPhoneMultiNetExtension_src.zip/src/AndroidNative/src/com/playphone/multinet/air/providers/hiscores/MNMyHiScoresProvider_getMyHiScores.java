package com.playphone.multinet.air.providers.hiscores;

import java.util.Map;

import com.adobe.fre.FREASErrorException;
import com.adobe.fre.FREArray;
import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREInvalidObjectException;
import com.adobe.fre.FREObject;
import com.adobe.fre.FRETypeMismatchException;
import com.adobe.fre.FREWrongThreadException;
import com.playphone.multinet.MNDirect;

public class MNMyHiScoresProvider_getMyHiScores implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREArray ret = null;

        try
        {
            Map<Integer,Long> hiscores = MNDirect.getMyHiScoresProvider().getMyHiScores();

            ret = FREArray.newArray(hiscores.size() * 2);
            int index = 0;
            
            for(Map.Entry<Integer,Long> item : hiscores.entrySet())
            {
                ret.setObjectAt(index,FREObject.newObject(item.getKey().intValue()));
                ret.setObjectAt(index+1,FREObject.newObject(item.getValue().longValue()));
                index += 2;
            }
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
