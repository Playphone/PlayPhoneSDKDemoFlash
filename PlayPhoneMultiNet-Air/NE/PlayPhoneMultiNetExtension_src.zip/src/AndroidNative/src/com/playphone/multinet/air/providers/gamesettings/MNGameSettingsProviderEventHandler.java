package com.playphone.multinet.air.providers.gamesettings;

import com.adobe.fre.FREContext;
import com.playphone.multinet.providers.MNGameSettingsProvider.IEventHandler;


public class MNGameSettingsProviderEventHandler implements IEventHandler
{
    private FREContext context;

    public MNGameSettingsProviderEventHandler(FREContext context)
    {
        this.context = context;
    }

    public void onGameSettingListUpdated()
    {
        context.dispatchStatusEventAsync("onGameSettingListUpdated", "");
    }


}

