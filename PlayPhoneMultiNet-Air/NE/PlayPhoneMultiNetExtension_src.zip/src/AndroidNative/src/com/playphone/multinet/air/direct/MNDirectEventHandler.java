package com.playphone.multinet.air.direct;

import com.adobe.fre.FREContext;
import com.playphone.multinet.IMNDirectEventHandler;

import com.playphone.multinet.core.MNSession;
import com.playphone.multinet.MNGameParams;
import java.util.Map;
import java.util.Hashtable;
import com.playphone.multinet.air.PlayPhoneMultiNetExt;
import java.lang.String;
import com.playphone.multinet.MNUserInfo;
import com.playphone.multinet.MNErrorInfo;


public class MNDirectEventHandler implements IMNDirectEventHandler
{
    private FREContext context;

    public MNDirectEventHandler(FREContext context)
    {
        this.context = context;
    }

	public void mnDirectSessionReady (MNSession session )
	{
		context.dispatchStatusEventAsync("mnDirectSessionReady", "");
	}

	public void mnDirectDoStartGameWithParams (MNGameParams params )
	{
		Map<String,Object> paramsMap = new Hashtable<String,Object>();

		paramsMap.put("params",params);

		context.dispatchStatusEventAsync("mnDirectDoStartGameWithParams", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
	}

	public void mnDirectDoFinishGame ( )
	{
		context.dispatchStatusEventAsync("mnDirectDoFinishGame", "");
	}

	public void mnDirectDoCancelGame ( )
	{
		context.dispatchStatusEventAsync("mnDirectDoCancelGame", "");
	}

	public void mnDirectViewDoGoBack ( )
	{
		context.dispatchStatusEventAsync("mnDirectViewDoGoBack", "");
	}

	public void mnDirectDidReceiveGameMessage (String message, MNUserInfo sender )
	{
		Map<String,Object> paramsMap = new Hashtable<String,Object>();

		paramsMap.put("message",message);
		paramsMap.put("sender",sender);

		context.dispatchStatusEventAsync("mnDirectDidReceiveGameMessage", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
	}

	public void mnDirectSessionStatusChanged (int newStatus )
	{
		Map<String,Object> paramsMap = new Hashtable<String,Object>();

		paramsMap.put("newStatus",newStatus);

		context.dispatchStatusEventAsync("mnDirectSessionStatusChanged", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
	}

	public void mnDirectErrorOccurred (MNErrorInfo error )
	{
		Map<String,Object> paramsMap = new Hashtable<String,Object>();

		paramsMap.put("error",error);

		context.dispatchStatusEventAsync("mnDirectErrorOccurred", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
	}


}

