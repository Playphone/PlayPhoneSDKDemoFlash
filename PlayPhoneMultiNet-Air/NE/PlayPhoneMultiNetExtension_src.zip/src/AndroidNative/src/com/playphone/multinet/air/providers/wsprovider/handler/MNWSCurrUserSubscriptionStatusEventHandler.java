package com.playphone.multinet.air.providers.wsprovider.handler;

import com.adobe.fre.FREContext;
import com.playphone.multinet.core.ws.data.MNWSCurrUserSubscriptionStatus;
import com.playphone.multinet.core.ws.data.MNWSRoomUserInfoItem;
import com.playphone.multinet.providers.MNWSInfoRequestCurrUserSubscriptionStatus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MNWSCurrUserSubscriptionStatusEventHandler extends MNWSEventHandler implements
        MNWSInfoRequestCurrUserSubscriptionStatus.IEventHandler
{
    public MNWSCurrUserSubscriptionStatusEventHandler(int requestId, FREContext context)
    {
        super(requestId, context);
    }

    @Override
    public void onCompleted(MNWSInfoRequestCurrUserSubscriptionStatus.RequestResult result)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("request_id", requestId);
            json.put("had_error", result.hadError());

            if (!result.hadError())
            {
                MNWSCurrUserSubscriptionStatus item = result.getDataEntry();
                JSONObject arrItem = new JSONObject();

                arrItem.put("has_subscription", item.getHasSubscription());
                arrItem.put("offers_available", item.getOffersAvailable());
                arrItem.put("is_subscription_available", item.getIsSubscriptionAvailable());

                json.put("data", arrItem);
            }
            else
            {
                json.put("error_message", result.getErrorMessage());
            }

            context.dispatchStatusEventAsync("onWSRequestReceived", json.toString());
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
    }
}
