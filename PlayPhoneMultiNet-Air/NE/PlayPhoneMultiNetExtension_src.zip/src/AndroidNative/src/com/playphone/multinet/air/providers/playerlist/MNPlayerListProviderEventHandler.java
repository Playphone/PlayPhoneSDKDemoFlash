package com.playphone.multinet.air.providers.playerlist;

import com.adobe.fre.FREContext;
import com.playphone.multinet.providers.MNPlayerListProvider.IEventHandler;
import com.playphone.multinet.MNUserInfo;
import java.util.Map;
import java.util.Hashtable;
import com.playphone.multinet.air.PlayPhoneMultiNetExt;


public class MNPlayerListProviderEventHandler implements IEventHandler
{
    private FREContext context;

    public MNPlayerListProviderEventHandler(FREContext context)
    {
        this.context = context;
    }

    public void onPlayerJoin (MNUserInfo player )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("player",player);

        context.dispatchStatusEventAsync("onPlayerJoin", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void onPlayerLeft (MNUserInfo player )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("player",player);

        context.dispatchStatusEventAsync("onPlayerLeft", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }


}

