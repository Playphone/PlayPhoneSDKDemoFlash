package com.playphone.multinet.core;

public class MNExtremeStorage extends MNVarStorage
{
    public MNExtremeStorage(IMNPlatform platform)
    {
        super(platform);
    }

    public MNExtremeStorage(IMNPlatform platform, String path)
    {
        super(platform, path);
    }
}
