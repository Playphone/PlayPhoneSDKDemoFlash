package com.playphone.multinet.air.providers.vshop;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.providers.MNVShopProvider;

public class MNVShopProvider_findVShopPackById implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            MNVShopProvider.VShopPackInfo pack = MNDirect.getVShopProvider().findVShopPackById( freObjects[0].getAsInt() );
            FREArray delivery = FREArray.newArray(pack.delivery.length);
            for(int i = 0; i < pack.delivery.length; i++)
            {
                delivery.setObjectAt(i, FREObject.newObject("com.playphone.multinet.providers.VShopDeliveryInfo",
                                                            new FREObject[]
                                                            {
                                                                    FREObject.newObject(pack.delivery[i].vItemId),
                                                                    FREObject.newObject(pack.delivery[i].amount)
                                                            }
                                                           ));
            }

            ret = FREObject.newObject( "com.playphone.multinet.providers.VShopPackInfo",
                                       new FREObject[]
                                       {
                                            FREObject.newObject(pack.id),
                                            FREObject.newObject(pack.name),
                                            FREObject.newObject(pack.model),
                                            FREObject.newObject(pack.description),
                                            FREObject.newObject(pack.appParams),
                                            FREObject.newObject(pack.sortPos),
                                            FREObject.newObject(pack.categoryId),
                                               delivery,
                                            FREObject.newObject(pack.priceItemId),
                                            FREObject.newObject(pack.priceValue)
                                       });
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
