package com.playphone.multinet.air.providers.hiscores;

import com.adobe.fre.FREContext;
import com.playphone.multinet.providers.MNMyHiScoresProvider.IEventHandler;
import java.util.Map;
import java.util.Hashtable;
import com.playphone.multinet.air.PlayPhoneMultiNetExt;


public class MNMyHiScoresProviderEventHandler implements IEventHandler
{
    private FREContext context;

    public MNMyHiScoresProviderEventHandler(FREContext context)
    {
        this.context = context;
    }

    public void onNewHiScore (long newScore, int gameSetId, int periodMask )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("newScore",newScore);
        paramsMap.put("gameSetId",gameSetId);
        paramsMap.put("periodMask",periodMask);

        context.dispatchStatusEventAsync("onNewHiScore", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }


}

