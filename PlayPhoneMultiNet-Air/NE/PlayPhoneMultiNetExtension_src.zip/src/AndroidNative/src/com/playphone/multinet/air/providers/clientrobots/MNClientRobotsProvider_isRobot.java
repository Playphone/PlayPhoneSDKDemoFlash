package com.playphone.multinet.air.providers.clientrobots;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.MNUserInfo;

public class MNClientRobotsProvider_isRobot implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            ret = FREObject.newObject(MNDirect.getClientRobotsProvider().isRobot(
                    new MNUserInfo((long)freObjects[0].getProperty("userId").getAsDouble(),
                                   freObjects[0].getProperty("userSFId").getAsInt(),
                                   freObjects[0].getProperty("userName").getAsString(),
                                   MNDirect.getSession().getWebServerURL())));
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
