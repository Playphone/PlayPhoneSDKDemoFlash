package com.playphone.multinet.air.providers.wsprovider.handler;

import com.adobe.fre.*;
import com.playphone.multinet.core.ws.data.MNWSCurrentUserInfo;
import com.playphone.multinet.providers.MNWSInfoRequestCurrentUserInfo;
import org.json.JSONException;
import org.json.JSONObject;

public class MNWSCurrentUserInfoEventHandler extends MNWSEventHandler implements MNWSInfoRequestCurrentUserInfo.IEventHandler
{
    public MNWSCurrentUserInfoEventHandler(int requestId, FREContext context)
    {
        super(requestId, context);
    }

    @Override
    public void onCompleted(final MNWSInfoRequestCurrentUserInfo.RequestResult result)
    {
        MNWSCurrentUserInfo res = result.getDataEntry();
        JSONObject json = new JSONObject();
        try
        {
            json.put("request_id", requestId);
            json.put("had_error", result.hadError());

            if (!result.hadError())
            {
                JSONObject jsonItem = new JSONObject();
                jsonItem.put("user_id", res.getUserId());
                jsonItem.put("user_nick_name", res.getUserNickName());
                jsonItem.put("user_avatar_exists", res.getUserAvatarExists());
                jsonItem.put("user_avatar_url", res.getUserAvatarUrl());
                jsonItem.put("user_online_now", res.getUserOnlineNow());
                jsonItem.put("user_email", res.getUserEmail());
                jsonItem.put("user_status", res.getUserStatus());
                jsonItem.put("user_avatar_has_custom_img", res.getUserAvatarHasCustomImg());
                jsonItem.put("user_avatar_has_external_url", res.getUserAvatarHasExternalUrl());
                jsonItem.put("user_gamepoints", res.getUserGamePoints());
                json.put("data", jsonItem);
            }
            else
            {
                json.put("error_message", result.getErrorMessage());
            }

            context.dispatchStatusEventAsync("onWSRequestReceived", json.toString());
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
    }
}
