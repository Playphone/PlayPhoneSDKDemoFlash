package com.playphone.multinet.air.providers.vitems;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.providers.MNVItemsProvider;

public class MNVItemsProvider_reqAddPlayerVItemTransaction implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            FREArray arg = (FREArray) freObjects[0];
            MNVItemsProvider.TransactionVItemInfo[] items = new MNVItemsProvider.TransactionVItemInfo[(int) arg.getLength()];
            for (int i = 0; i < arg.getLength(); i++)
            {
                items[i] = new MNVItemsProvider.TransactionVItemInfo( arg.getObjectAt(i).getProperty("id").getAsInt(),
                                                                      (long)arg.getObjectAt(i).getProperty("delta").getAsDouble());
            }
            MNDirect.getVItemsProvider().reqAddPlayerVItemTransaction(items, (long)freObjects[1].getAsDouble());
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
