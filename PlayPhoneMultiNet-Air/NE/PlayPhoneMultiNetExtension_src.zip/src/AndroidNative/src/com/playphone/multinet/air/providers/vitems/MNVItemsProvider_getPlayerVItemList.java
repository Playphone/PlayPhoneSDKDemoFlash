package com.playphone.multinet.air.providers.vitems;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.providers.MNVItemsProvider;

public class MNVItemsProvider_getPlayerVItemList implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREArray ret = null;
        try
        {
            MNVItemsProvider.PlayerVItemInfo[] players = MNDirect.getVItemsProvider().getPlayerVItemList();
            ret = FREArray.newArray(players.length);
            for(int i = 0; i < players.length; i++)
            {
                ret.setObjectAt( i,FREObject.newObject("com.playphone.multinet.providers.PlayerVItemInfo",
                                                       new FREObject[]
                                                       {
                                                               FREObject.newObject(players[i].id),
                                                               FREObject.newObject(players[i].count)
                                                       }));
            }
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
