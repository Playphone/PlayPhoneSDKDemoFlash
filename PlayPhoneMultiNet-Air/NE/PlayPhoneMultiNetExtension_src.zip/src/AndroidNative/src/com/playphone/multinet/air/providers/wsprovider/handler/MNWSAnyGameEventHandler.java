package com.playphone.multinet.air.providers.wsprovider.handler;

import com.adobe.fre.FREContext;
import com.playphone.multinet.core.ws.data.MNWSAnyGameItem;
import com.playphone.multinet.providers.MNWSInfoRequestAnyGame;
import org.json.JSONException;
import org.json.JSONObject;

public class MNWSAnyGameEventHandler  extends MNWSEventHandler implements MNWSInfoRequestAnyGame.IEventHandler
{
    public MNWSAnyGameEventHandler(int requestId, FREContext context)
    {
        super(requestId, context);
    }

    @Override
    public void onCompleted(MNWSInfoRequestAnyGame.RequestResult result)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("request_id", requestId);
            json.put("had_error", result.hadError());

            if (!result.hadError())
            {
                MNWSAnyGameItem item = result.getDataEntry();
                JSONObject jsonItem = new JSONObject();
                jsonItem.put("game_id", item.getGameId());
                jsonItem.put("game_name", item.getGameName());
                jsonItem.put("game_desc", item.getGameDesc());
                jsonItem.put("gamegenre_id", item.getGameGenreId());
                jsonItem.put("game_flags", item.getGameFlags());
                jsonItem.put("game_status", item.getGameStatus());
                jsonItem.put("game_play_model", item.getGamePlayModel());
                jsonItem.put("game_icon_url", item.getGameIconUrl());
                jsonItem.put("developer_id", item.getDeveloperId());
                json.put("data", jsonItem);
            }
            else
            {
                json.put("error_message", result.getErrorMessage());
            }

            context.dispatchStatusEventAsync("onWSRequestReceived", json.toString());
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
    }
}
