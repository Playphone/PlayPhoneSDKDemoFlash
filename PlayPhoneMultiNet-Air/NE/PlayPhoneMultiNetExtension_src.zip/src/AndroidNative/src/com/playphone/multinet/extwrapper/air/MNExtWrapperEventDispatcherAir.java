package com.playphone.multinet.extwrapper.air;

import java.util.HashMap;
import java.util.Map;

import com.adobe.fre.FREContext;
import com.playphone.multinet.air.PlayPhoneMultiNetExt;
import com.playphone.multinet.extwrapper.IMNExtWrapperEventDispatcher;
import com.playphone.multinet.extwrapper.MNExtWrapper;

public class MNExtWrapperEventDispatcherAir implements IMNExtWrapperEventDispatcher {
    public MNExtWrapperEventDispatcherAir(FREContext context) {
        super();

        this.freContext = context;
    }

    public void dispatchEvent(String eventName,Object[] eventParams,String[] eventParamsNames) {
        MNExtWrapper.DLog(String.format("dispatchEvent:%s withParams:%h andParamsNames:%h",eventName,eventParams,eventParamsNames));

        
        if (eventName.equals("MNWSInfoRequestEventHandler")) 
        {
            eventName = "onWSRequestReceived";
        }
        
        String paramsPassString = null;

        if ((eventParams == null) || (eventParams.length == 0))
        {
            paramsPassString = "";
        }
        else
        {
            Map<String,Object> paramsDict = new HashMap<String,Object>(eventParams.length);

            for (int index = 0; index < eventParams.length; index++)
            {
                String key = null;

                if ((eventParamsNames == null) || (eventParamsNames.length <= index))
                {
                    key = String.format("UnnamedParam%d",index + 1);
                }
                else
                {
                    key = eventParamsNames[index];
                }

                paramsDict.put(key,eventParams[index]);
            }

            paramsPassString = PlayPhoneMultiNetExt.serializer.serialize(paramsDict);
        }

        if (freContext == null)
        {
            MNExtWrapper.ELog("Can not dispatch event. freContext == NULL");
        }
        else
        {
            freContext.dispatchStatusEventAsync(eventName,paramsPassString);
        }
    }

    private FREContext freContext = null;
}
