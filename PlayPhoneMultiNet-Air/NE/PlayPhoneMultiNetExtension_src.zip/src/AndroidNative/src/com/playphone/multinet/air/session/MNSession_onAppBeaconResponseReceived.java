package com.playphone.multinet.air.session;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.core.MNAppBeaconResponse;

public class MNSession_onAppBeaconResponseReceived implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            MNDirect.getSession().onAppBeaconResponseReceived(new MNAppBeaconResponse(
                    freObjects[0].getProperty("responseText").getAsString(),
                    freObjects[0].getProperty("callSeqNumber").getAsInt()));
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
