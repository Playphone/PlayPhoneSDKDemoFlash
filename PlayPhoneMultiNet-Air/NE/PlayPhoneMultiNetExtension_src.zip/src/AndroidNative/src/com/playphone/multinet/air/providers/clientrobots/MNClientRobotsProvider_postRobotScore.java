package com.playphone.multinet.air.providers.clientrobots;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.MNUserInfo;

public class MNClientRobotsProvider_postRobotScore implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            MNDirect.getClientRobotsProvider().postRobotScore(
                    new MNUserInfo(freObjects[0].getProperty("userId").getAsInt(),
                                   freObjects[0].getProperty("userSFId").getAsInt(),
                                   freObjects[0].getProperty("userName").getAsString(),
                                   MNDirect.getSession().getWebServerURL()),
                    (long)freObjects[1].getAsDouble());

        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
