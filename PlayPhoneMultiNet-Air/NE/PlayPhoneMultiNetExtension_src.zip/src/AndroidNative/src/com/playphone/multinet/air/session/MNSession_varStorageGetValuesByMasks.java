package com.playphone.multinet.air.session;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;

import java.util.Map;

public class MNSession_varStorageGetValuesByMasks implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            FREArray arg = (FREArray) freObjects[0];
            String[] masks = new String[(int) arg.getLength()];
            for (int i = 0; i < arg.getLength(); i++)
            {
                masks[i] = arg.getObjectAt(i).getAsString();
            }

            Map<String, String> values = MNDirect.getSession().varStorageGetValuesByMasks(masks);

            if( values.size() > 0 )
            {
                ret = FREObject.newObject("flash.utils.Dictionary", new FREObject[0]);

                for (Map.Entry<String, String> pair : values.entrySet())
                {
                    ret.setProperty(pair.getKey(), FREObject.newObject(pair.getValue()));
                }
            }
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        catch (FREReadOnlyException e)
        {
            e.printStackTrace();
        }
        catch (Throwable e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
