package com.playphone.multinet.air.session;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.core.MNBuddyRoomParams;

public class MNSession_reqCreateBuddyRoom implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            MNDirect.getSession().reqCreateBuddyRoom(new MNBuddyRoomParams(
                    freObjects[0].getProperty("roomName").getAsString(),
                    freObjects[0].getProperty("gameSetId").getAsInt(),
                    freObjects[0].getProperty("toUserIdList").getAsString(),
                    freObjects[0].getProperty("toUserSFIdList").getAsString(),
                    freObjects[0].getProperty("inviteText").getAsString()));
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
