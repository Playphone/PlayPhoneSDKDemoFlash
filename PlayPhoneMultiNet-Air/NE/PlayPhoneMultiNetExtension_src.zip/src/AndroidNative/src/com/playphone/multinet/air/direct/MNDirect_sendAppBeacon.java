package com.playphone.multinet.air.direct;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;

public class MNDirect_sendAppBeacon implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            MNDirect.sendAppBeacon(freObjects[0].getAsString(), freObjects[1].getAsString());
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
