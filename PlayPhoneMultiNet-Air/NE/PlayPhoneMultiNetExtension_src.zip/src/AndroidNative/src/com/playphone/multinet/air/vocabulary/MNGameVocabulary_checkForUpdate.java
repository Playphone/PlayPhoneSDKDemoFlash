package com.playphone.multinet.air.vocabulary;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;

public class MNGameVocabulary_checkForUpdate implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        MNDirect.getSession().getGameVocabulary().checkForUpdate();
        return ret;
    }
}
