package com.playphone.multinet.air.providers.wsprovider;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREInvalidObjectException;
import com.adobe.fre.FREObject;
import com.adobe.fre.FRETypeMismatchException;
import com.adobe.fre.FREWrongThreadException;
import com.playphone.multinet.air.PlayPhoneMultiNetExt;
import com.playphone.multinet.extwrapper.MNWSProviderExtWrapper;

public class MNWSProvider_send implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            String requestParamsJSON = freObjects[0].getAsString();
            
            MNWSProviderExtWrapper wsProvideerWrapper = new MNWSProviderExtWrapper(PlayPhoneMultiNetExt.serializer,PlayPhoneMultiNetExt.eventDispatcher);
            int loaderId = wsProvideerWrapper.send(requestParamsJSON);
            
            return FREObject.newObject(loaderId);
            /*
            FREArray args = (FREArray) freObjects[0];
            MNWSInfoRequest[] requests = new MNWSInfoRequest[(int) args.getLength()];
            for( int i = 0 ; i < args.getLength(); i++ )
            {
                requests[i] = WSInfoCreator.create( args.getObjectAt(i), freContext );
            }
            MNDirect.getWSProvider().send(requests);
            */
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        /*
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        */
        catch (Throwable e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
