package com.playphone.multinet.air.popup;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirectPopup;

public class MNDirectPopup_setActive implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
        MNDirectPopup.setActive( freObjects[0].getAsBool() );
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
