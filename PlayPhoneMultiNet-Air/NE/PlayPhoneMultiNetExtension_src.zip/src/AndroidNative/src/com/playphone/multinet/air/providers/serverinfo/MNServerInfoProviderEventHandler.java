package com.playphone.multinet.air.providers.serverinfo;

import com.adobe.fre.FREContext;
import com.playphone.multinet.providers.MNServerInfoProvider.IEventHandler;
import java.lang.String;
import java.util.Map;
import java.util.Hashtable;
import com.playphone.multinet.air.PlayPhoneMultiNetExt;


public class MNServerInfoProviderEventHandler implements IEventHandler
{
    private FREContext context;

    public MNServerInfoProviderEventHandler(FREContext context)
    {
        this.context = context;
    }

    public void onServerInfoItemReceived (int key, String value )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("key",key);
        paramsMap.put("value",value);

        context.dispatchStatusEventAsync("onServerInfoItemReceived", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void onServerInfoItemRequestFailedWithError (int key, String error )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("key",key);
        paramsMap.put("error",error);

        context.dispatchStatusEventAsync("onServerInfoItemRequestFailedWithError", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }


}

