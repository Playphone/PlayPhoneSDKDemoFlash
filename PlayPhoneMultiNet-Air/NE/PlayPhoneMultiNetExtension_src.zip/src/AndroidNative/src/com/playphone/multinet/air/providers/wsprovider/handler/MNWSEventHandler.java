package com.playphone.multinet.air.providers.wsprovider.handler;

import com.adobe.fre.FREContext;

public class MNWSEventHandler 
{
    protected int requestId;
    protected FREContext context;
    
    public MNWSEventHandler(int requestId, FREContext context)
    {
        this.requestId = requestId;
        this.context = context;
    }
}
