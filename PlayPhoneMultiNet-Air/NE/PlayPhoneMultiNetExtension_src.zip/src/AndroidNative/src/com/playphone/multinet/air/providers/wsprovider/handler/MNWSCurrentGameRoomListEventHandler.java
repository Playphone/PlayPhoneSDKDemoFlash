package com.playphone.multinet.air.providers.wsprovider.handler;

import com.adobe.fre.FREContext;
import com.playphone.multinet.core.ws.data.MNWSRoomListItem;
import com.playphone.multinet.providers.MNWSInfoRequestCurrGameRoomList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MNWSCurrentGameRoomListEventHandler extends MNWSEventHandler implements MNWSInfoRequestCurrGameRoomList.IEventHandler
{
    public MNWSCurrentGameRoomListEventHandler(int requestId, FREContext context)
    {
        super(requestId, context);
    }

    @Override
    public void onCompleted(MNWSInfoRequestCurrGameRoomList.RequestResult result)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("request_id", requestId);
            json.put("had_error", result.hadError());

            if (!result.hadError())
            {
                JSONArray arr = new JSONArray();
                for (MNWSRoomListItem item : result.getDataEntry())
                {
                    JSONObject arrItem = new JSONObject();

                    arrItem.put("room_sfid", item.getRoomSFId());
                    arrItem.put("room_name", item.getRoomName());
                    arrItem.put("room_user_count", item.getRoomUserCount());
                    arrItem.put("room_is_lobby", item.getRoomIsLobby());
                    arrItem.put("game_id", item.getGameId());
                    arrItem.put("gameset_id", item.getGameSetId());

                    arr.put(arrItem);
                }
                json.put("data", arr);
            }
            else
            {
                json.put("error_message", result.getErrorMessage());
            }

            context.dispatchStatusEventAsync("onWSRequestReceived", json.toString());
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
    }
}
