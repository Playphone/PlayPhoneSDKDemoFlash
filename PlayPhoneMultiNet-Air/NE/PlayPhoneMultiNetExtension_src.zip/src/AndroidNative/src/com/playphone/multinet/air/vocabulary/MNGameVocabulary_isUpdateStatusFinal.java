package com.playphone.multinet.air.vocabulary;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.core.MNGameVocabulary;

public class MNGameVocabulary_isUpdateStatusFinal implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            ret = FREObject.newObject(MNDirect.getSession().getGameVocabulary().isUpdateStatusFinal(freObjects[0].getAsInt()));
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
