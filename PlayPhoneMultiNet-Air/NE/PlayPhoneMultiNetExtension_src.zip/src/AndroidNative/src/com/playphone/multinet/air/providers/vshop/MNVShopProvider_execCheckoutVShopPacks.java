package com.playphone.multinet.air.providers.vshop;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;

public class MNVShopProvider_execCheckoutVShopPacks implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            FREArray arg0 = (FREArray) freObjects[0];
            int[] packIdArray = new int[(int) arg0.getLength()];

            FREArray arg1 = (FREArray) freObjects[1];
            int[] packCountArray = new int[(int) arg1.getLength()];

            for (int i = 0; i < arg0.getLength(); i++)
            {
                packIdArray[i] = arg0.getObjectAt(i).getAsInt();
                packCountArray[i] = arg1.getObjectAt(i).getAsInt();
            }

            MNDirect.getVShopProvider().execCheckoutVShopPacks(packIdArray,
                                                               packCountArray,
                                                               (long)freObjects[2].getAsDouble());
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
