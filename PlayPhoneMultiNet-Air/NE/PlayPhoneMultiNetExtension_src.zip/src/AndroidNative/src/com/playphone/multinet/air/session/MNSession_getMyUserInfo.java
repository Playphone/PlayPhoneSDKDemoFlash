package com.playphone.multinet.air.session;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.MNUserInfo;

public class MNSession_getMyUserInfo implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            MNUserInfo my = MNDirect.getSession().getMyUserInfo();

            ret = FREObject.newObject("com.playphone.multinet.MNUserInfo",
                                      new FREObject[]
                                      {
                                              FREObject.newObject( my.userId ),
                                              FREObject.newObject( my.userSFId ),
                                              FREObject.newObject( my.userName ),
                                              FREObject.newObject( my.getAvatarUrl() )
                                      });
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
