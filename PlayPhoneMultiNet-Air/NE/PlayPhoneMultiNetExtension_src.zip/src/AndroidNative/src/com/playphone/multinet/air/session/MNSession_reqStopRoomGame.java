package com.playphone.multinet.air.session;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;
import com.playphone.multinet.MNDirect;

public class MNSession_reqStopRoomGame implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        MNDirect.getSession().reqStopRoomGame();
        return ret;
    }
}
