package com.playphone.multinet.air.providers.roomcookies;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;

public class MNGameRoomCookiesProvider_getCurrentGameRoomCookie implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            ret = FREObject.newObject(
                    MNDirect.getGameRoomCookiesProvider().getCurrentGameRoomCookie(freObjects[0].getAsInt()));
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
