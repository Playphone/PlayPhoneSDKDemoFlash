package com.playphone.multinet.air.providers.roomcookies;

import com.adobe.fre.FREContext;
import com.playphone.multinet.providers.MNGameRoomCookiesProvider.IEventHandler;
import java.lang.String;
import java.util.Map;
import java.util.Hashtable;
import com.playphone.multinet.air.PlayPhoneMultiNetExt;


public class MNGameRoomCookiesProviderEventHandler implements IEventHandler
{
    private FREContext context;

    public MNGameRoomCookiesProviderEventHandler(FREContext context)
    {
        this.context = context;
    }

    public void onGameRoomCookieDownloadSucceeded (int roomSFId, int key, String cookie )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("roomSFId",roomSFId);
        paramsMap.put("key",key);
        paramsMap.put("cookie",cookie);

        context.dispatchStatusEventAsync("onGameRoomCookieDownloadSucceeded", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void onGameRoomCookieDownloadFailedWithError (int roomSFId, int key, String error )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("roomSFId",roomSFId);
        paramsMap.put("key",key);
        paramsMap.put("error",error);

        context.dispatchStatusEventAsync("onGameRoomCookieDownloadFailedWithError", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void onCurrentGameRoomCookieUpdated (int key, String newCookieValue )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("key",key);
        paramsMap.put("newCookieValue",newCookieValue);

        context.dispatchStatusEventAsync("onCurrentGameRoomCookieUpdated", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }


}

