package com.playphone.multinet.air.button;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirectButton;

public class MNDirectButton_setInited implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
        MNDirectButton.setInited( freObjects[0].getAsBool() );
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
