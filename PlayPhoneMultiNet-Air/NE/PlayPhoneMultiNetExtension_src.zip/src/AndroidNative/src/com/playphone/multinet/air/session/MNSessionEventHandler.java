package com.playphone.multinet.air.session;

import com.adobe.fre.FREContext;
import com.playphone.multinet.core.IMNSessionEventHandler;
import java.util.Map;
import java.util.Hashtable;
import com.playphone.multinet.air.PlayPhoneMultiNetExt;
import java.lang.String;
import com.playphone.multinet.core.MNAppHostCallInfo;
import com.playphone.multinet.MNErrorInfo;
import com.playphone.multinet.MNGameParams;
import com.playphone.multinet.core.MNGameResult;
import com.playphone.multinet.core.MNChatMessage;
import com.playphone.multinet.MNUserInfo;
import com.playphone.multinet.core.MNCurrGameResults;
import com.playphone.multinet.core.MNJoinRoomInvitationParams;
import com.playphone.multinet.core.IMNSessionEventHandler.AuthTokenChangedEvent;
import com.playphone.multinet.core.MNAppBeaconResponse;


public class MNSessionEventHandler implements IMNSessionEventHandler
{
    private FREContext context;

    public MNSessionEventHandler(FREContext context)
    {
        this.context = context;
    }

    public void mnSessionUserChanged (long userId )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("userId",userId);

        context.dispatchStatusEventAsync("mnSessionUserChanged", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionLoginInitiated ( )
    {
        context.dispatchStatusEventAsync("mnSessionLoginInitiated", "");
    }

    public void mnSessionExecAppCommandReceived (String cmdName, String cmdParam )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("cmdName",cmdName);
        paramsMap.put("cmdParam",cmdParam);

        context.dispatchStatusEventAsync("mnSessionExecAppCommandReceived", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionExecUICommandReceived (String cmdName, String cmdParam )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("cmdName",cmdName);
        paramsMap.put("cmdParam",cmdParam);

        context.dispatchStatusEventAsync("mnSessionExecUICommandReceived", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionWebEventReceived (String eventName, String eventParam, String callbackId )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("eventName",eventName);
        paramsMap.put("eventParam",eventParam);
        paramsMap.put("callbackId",callbackId);

        context.dispatchStatusEventAsync("mnSessionWebEventReceived", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionSysEventReceived (String eventName, String eventParam, String callbackId )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("eventName",eventName);
        paramsMap.put("eventParam",eventParam);
        paramsMap.put("callbackId",callbackId);

        context.dispatchStatusEventAsync("mnSessionSysEventReceived", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public boolean mnSessionAppHostCallReceived (MNAppHostCallInfo arg0 )
    {
        context.dispatchStatusEventAsync("mnSessionAppHostCallReceived", "");
        return false;
    }

    public void mnSessionAppStartParamUpdated (String param )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("param",param);

        context.dispatchStatusEventAsync("mnSessionAppStartParamUpdated", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionErrorOccurred (MNErrorInfo errorInfo )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("errorInfo",errorInfo);

        context.dispatchStatusEventAsync("mnSessionErrorOccurred", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionDoStartGameWithParams (MNGameParams gameParams )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("gameParams",gameParams);

        context.dispatchStatusEventAsync("mnSessionDoStartGameWithParams", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionGameFinishedWithResult (MNGameResult gameResult )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("gameResult",gameResult);

        context.dispatchStatusEventAsync("mnSessionGameFinishedWithResult", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionDefaultGameSetIdChangedTo (int gameSetId )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("gameSetId",gameSetId);

        context.dispatchStatusEventAsync("mnSessionDefaultGameSetIdChangedTo", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionStatusChanged (int newStatus, int oldStatus )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("newStatus",newStatus);
        paramsMap.put("oldStatus",oldStatus);

        context.dispatchStatusEventAsync("mnSessionStatusChanged", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionWebFrontURLReady (String url )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("url",url);

        context.dispatchStatusEventAsync("mnSessionWebFrontURLReady", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionConfigLoaded ( )
    {
        context.dispatchStatusEventAsync("mnSessionConfigLoaded", "");
    }

    public void mnSessionChatPrivateMessageReceived (MNChatMessage chatMessage )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("chatMessage",chatMessage);

        context.dispatchStatusEventAsync("mnSessionChatPrivateMessageReceived", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionChatPublicMessageReceived (MNChatMessage chatMessage )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("chatMessage",chatMessage);

        context.dispatchStatusEventAsync("mnSessionChatPublicMessageReceived", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionRoomUserStatusChanged (int userStatus )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("userStatus",userStatus);

        context.dispatchStatusEventAsync("mnSessionRoomUserStatusChanged", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionGameStartCountdownTick (int secondsLeft )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("secondsLeft",secondsLeft);

        context.dispatchStatusEventAsync("mnSessionGameStartCountdownTick", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionDoFinishGame ( )
    {
        context.dispatchStatusEventAsync("mnSessionDoFinishGame", "");
    }

    public void mnSessionDoCancelGame ( )
    {
        context.dispatchStatusEventAsync("mnSessionDoCancelGame", "");
    }

    public void mnSessionRoomUserJoin (MNUserInfo userInfo )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("userInfo",userInfo);

        context.dispatchStatusEventAsync("mnSessionRoomUserJoin", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionRoomUserLeave (MNUserInfo userInfo )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("userInfo",userInfo);

        context.dispatchStatusEventAsync("mnSessionRoomUserLeave", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionCurrGameResultsReceived (MNCurrGameResults gameResults )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("gameResults",gameResults);

        context.dispatchStatusEventAsync("mnSessionCurrGameResultsReceived", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionJoinRoomInvitationReceived (MNJoinRoomInvitationParams params )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("params",params);

        context.dispatchStatusEventAsync("mnSessionJoinRoomInvitationReceived", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionGameMessageReceived (String message, MNUserInfo sender )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("message",message);
        paramsMap.put("sender",sender);

        context.dispatchStatusEventAsync("mnSessionGameMessageReceived", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionPluginMessageReceived (String pluginName, String message, MNUserInfo sender )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("pluginName",pluginName);
        paramsMap.put("message",message);
        paramsMap.put("sender",sender);

        context.dispatchStatusEventAsync("mnSessionPluginMessageReceived", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionSocNetLoggedOut (int socNetId )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("socNetId",socNetId);

        context.dispatchStatusEventAsync("mnSessionSocNetLoggedOut", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionSocNetTokenStatusChanged (int socNetId, AuthTokenChangedEvent eventData )
    {
        context.dispatchStatusEventAsync("mnSessionSocNetTokenStatusChanged", "");
    }

    public void mnSessionDevUsersInfoChanged ( )
    {
        context.dispatchStatusEventAsync("mnSessionDevUsersInfoChanged", "");
    }

    public void mnSessionAppBeaconResponseReceived (MNAppBeaconResponse beaconResponse )
    {
        context.dispatchStatusEventAsync("mnSessionAppBeaconResponseReceived", "");
    }

    public void mnSessionVShopReadyStatusChanged (boolean isVShopReady )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("isVShopReady",isVShopReady);

        context.dispatchStatusEventAsync("mnSessionVShopReadyStatusChanged", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnSessionConfigLoadStarted ( )
    {
        context.dispatchStatusEventAsync("mnSessionConfigLoadStarted", "");
    }


}

