package com.playphone.multinet.air.direct;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREInvalidObjectException;
import com.adobe.fre.FREObject;
import com.adobe.fre.FRETypeMismatchException;
import com.adobe.fre.FREWrongThreadException;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.air.vocabulary.MNGameVocabularyEventHandler;

public class MNDirect_init implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            int gameId = freObjects[0].getAsInt();
            String secret = freObjects[1].getAsString();

            MNDirect.init(gameId,
                          secret,
                          new MNDirectEventHandler(freContext),
                          freContext.getActivity());

            MNDirect.handleApplicationIntent(freContext.getActivity().getIntent());

            MNDirect.getSession().getGameVocabulary().addEventHandler(new MNGameVocabularyEventHandler(freContext));
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }

        return ret;
    }
}
