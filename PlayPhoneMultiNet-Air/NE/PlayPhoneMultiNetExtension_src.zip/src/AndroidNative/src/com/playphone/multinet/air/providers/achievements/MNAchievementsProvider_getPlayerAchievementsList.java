package com.playphone.multinet.air.providers.achievements;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.providers.MNAchievementsProvider;

public class MNAchievementsProvider_getPlayerAchievementsList implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            MNAchievementsProvider.PlayerAchievementInfo[] list = MNDirect.getAchievementsProvider().getPlayerAchievementsList();

            FREArray rr = FREArray.newArray(list.length);
            for (int i = 0; i < list.length; i++)
            {
                rr.setObjectAt(i, FREObject.newObject("com.playphone.multinet.providers.PlayerAchievementInfo",
                                                      new FREObject[]
                                                      {
                                                              FREObject.newObject(list[i].id)
                                                      }));
            }
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
