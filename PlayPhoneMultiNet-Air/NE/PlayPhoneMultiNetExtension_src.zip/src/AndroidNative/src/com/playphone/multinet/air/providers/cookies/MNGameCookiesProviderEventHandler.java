package com.playphone.multinet.air.providers.cookies;

import com.adobe.fre.FREContext;
import com.playphone.multinet.providers.MNGameCookiesProvider.IEventHandler;
import java.lang.String;
import java.util.Map;
import java.util.Hashtable;
import com.playphone.multinet.air.PlayPhoneMultiNetExt;


public class MNGameCookiesProviderEventHandler implements IEventHandler
{
    private FREContext context;

    public MNGameCookiesProviderEventHandler(FREContext context)
    {
        this.context = context;
    }

    public void onGameCookieUploadFailedWithError (int key, String error )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("key",key);
        paramsMap.put("error",error);

        context.dispatchStatusEventAsync("onGameCookieUploadFailedWithError", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void onGameCookieDownloadSucceeded (int key, String cookie )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("key",key);
        paramsMap.put("cookie",cookie);

        context.dispatchStatusEventAsync("onGameCookieDownloadSucceeded", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void onGameCookieDownloadFailedWithError (int key, String error )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("key",key);
        paramsMap.put("error",error);

        context.dispatchStatusEventAsync("onGameCookieDownloadFailedWithError", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void onGameCookieUploadSucceeded (int key )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("key",key);

        context.dispatchStatusEventAsync("onGameCookieUploadSucceeded", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }


}

