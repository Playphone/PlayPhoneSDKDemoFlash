package com.playphone.multinet.air.providers.scoreprogress;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.providers.MNScoreProgressProvider;

public class MNScoreProgressProvider_setScoreComparator implements FREFunction
{
    private static final int MoreIsBetter = 1;
    private static final int LessIsBetter = 2;
    
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            int type = freObjects[0].getAsInt();
            if( type == MoreIsBetter )
            {
                MNDirect.getScoreProgressProvider().setScoreComparator(
                        new MNScoreProgressProvider.ScoreComparatorMoreIsBetter());
            }

            if( type == LessIsBetter )
            {
                MNDirect.getScoreProgressProvider().setScoreComparator(
                        new MNScoreProgressProvider.ScoreComparatorLessIsBetter());
            }
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
