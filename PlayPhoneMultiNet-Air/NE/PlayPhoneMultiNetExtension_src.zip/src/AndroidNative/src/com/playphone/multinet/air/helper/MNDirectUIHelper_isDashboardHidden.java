package com.playphone.multinet.air.helper;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;
import com.adobe.fre.FREWrongThreadException;
import com.playphone.multinet.MNDirectUIHelper;

public class MNDirectUIHelper_isDashboardHidden implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
        ret = FREObject.newObject( MNDirectUIHelper.isDashboardHidden(  ) );
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
