package com.playphone.multinet.air.providers.achievements;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.providers.MNAchievementsProvider;

public class MNAchievementsProvider_getGameAchievementsList implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREArray ret = null;
        MNAchievementsProvider.GameAchievementInfo[] list = MNDirect.getAchievementsProvider().getGameAchievementsList();
        try
        {
            if(list != null)
            {
                ret = FREArray.newArray(list.length);
                for( int i = 0; i < list.length; i++ )
                {
                    ret.setObjectAt(i, FREObject.newObject("com.playphone.multinet.providers.GameAchievementInfo",
                                                           new FREObject[]
                                                           {
                                                                   FREObject.newObject(list[i].id),
                                                                   FREObject.newObject(list[i].name),
                                                                   FREObject.newObject(list[i].flags),
                                                                   FREObject.newObject(list[i].description),
                                                                   FREObject.newObject(list[i].params),
                                                                   FREObject.newObject(list[i].points)
                                                           }));
                }
            }
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
