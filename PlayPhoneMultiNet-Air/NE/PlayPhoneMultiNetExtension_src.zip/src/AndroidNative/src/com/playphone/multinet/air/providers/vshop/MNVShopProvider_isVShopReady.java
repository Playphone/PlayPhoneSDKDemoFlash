package com.playphone.multinet.air.providers.vshop;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;
import com.adobe.fre.FREWrongThreadException;
import com.playphone.multinet.MNDirect;

public class MNVShopProvider_isVShopReady implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            ret = FREObject.newObject(MNDirect.getVShopProvider().isVShopReady());
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
