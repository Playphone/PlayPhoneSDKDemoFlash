package com.playphone.multinet.air.providers.scoreprogress;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;
import com.playphone.multinet.MNDirect;

public class MNScoreProgressProvider_stop implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        MNDirect.getScoreProgressProvider().stop();
        return ret;
    }
}
