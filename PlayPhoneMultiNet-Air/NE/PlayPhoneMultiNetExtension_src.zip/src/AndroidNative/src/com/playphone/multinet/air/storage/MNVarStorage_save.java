package com.playphone.multinet.air.storage;

import com.adobe.fre.*;
import com.playphone.multinet.core.MNExtUserCredentials;
import com.playphone.multinet.core.MNExtremeStorage;
import com.playphone.multinet.core.MNPlatformAndroid;
import com.playphone.multinet.core.MNSession;

import java.util.Calendar;


public class MNVarStorage_save implements FREFunction
{
    @Override
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        try
        {
            FREArray creds = (FREArray) freObjects[0];
            MNPlatformAndroid android = new MNPlatformAndroid(freContext.getActivity());
            MNExtremeStorage varStorage = new MNExtremeStorage(android, MNSession.VAR_STORAGE_FILE_NAME);

            for (int i = 0; i < creds.getLength(); i++)
            {
                int userId = creds.getObjectAt(i).getProperty("userId").getAsInt();

                if( MNExtUserCredentials.getCredentialsByUserId(varStorage, userId) != null )
                {
                    String userName = creds.getObjectAt(i).getProperty("userName").getAsString();
                    String userAuthSign = creds.getObjectAt(i).getProperty("userAuthSign").getAsString();

                    Calendar cal = Calendar.getInstance();
                    MNExtUserCredentials cred =
                            new MNExtUserCredentials(userId, userName, userAuthSign, cal.getTime(), "");
                    MNExtUserCredentials.updateCredentials(varStorage, cred);
                }
            }

            varStorage.writeToFile(MNSession.VAR_STORAGE_FILE_NAME);
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }

        return null;
    }
}