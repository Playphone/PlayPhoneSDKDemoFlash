package com.playphone.multinet.air.providers.roomcookies;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;
import com.playphone.multinet.MNDirect;

public class MNGameRoomCookiesProvider_addEventHandler implements FREFunction {
    private static boolean eventHandlerAdded = false;
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        if (!eventHandlerAdded) {

            eventHandlerAdded = true;
            MNDirect.getGameRoomCookiesProvider().addEventHandler(new MNGameRoomCookiesProviderEventHandler(freContext) );
        }
        
       return null;
    }
}
