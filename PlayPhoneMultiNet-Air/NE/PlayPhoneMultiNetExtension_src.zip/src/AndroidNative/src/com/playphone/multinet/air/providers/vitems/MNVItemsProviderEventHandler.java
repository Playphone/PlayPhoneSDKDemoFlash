package com.playphone.multinet.air.providers.vitems;

import com.adobe.fre.FREContext;
import com.playphone.multinet.providers.MNVItemsProvider.IEventHandler;
import com.playphone.multinet.providers.MNVItemsProvider.TransactionInfo;
import java.util.Map;
import java.util.Hashtable;
import com.playphone.multinet.air.PlayPhoneMultiNetExt;
import com.playphone.multinet.providers.MNVItemsProvider.TransactionError;


public class MNVItemsProviderEventHandler implements IEventHandler
{
    private FREContext context;

    public MNVItemsProviderEventHandler(FREContext context)
    {
        this.context = context;
    }

    public void onVItemsListUpdated ( )
    {
        context.dispatchStatusEventAsync("onVItemsListUpdated", "");
    }

    public void onVItemsTransactionCompleted (TransactionInfo transaction )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("transaction",transaction);

        context.dispatchStatusEventAsync("onVItemsTransactionCompleted", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void onVItemsTransactionFailed (TransactionError error )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("error",error);

        context.dispatchStatusEventAsync("onVItemsTransactionFailed", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }


}

