package com.playphone.multinet.extwrapper;

import android.util.Log;

import com.playphone.multinet.extwrapper.serializer.MNJsonSerializer;
import com.playphone.multinet.extwrapper.serializer.MNSerializer;

public class MNExtWrapper {
    public enum WrapperPlatform
    {
        Unity,
        Air
    }
    
    private static String  MNExtWrapperLogTag    = "MNExtWrapper";
    private static String  MNExtWrapperLogPrefix = "MNUW:Java:";
    public static MNSerializer serializer = new MNJsonSerializer();

    public static final int DEBUG_LEVEL_OFF = 0;
    public static final int DEBUG_LEVEL_NORMAL = 1;
    public static final int DEBUG_LEVEL_DETAILED = 2;

    private static int currentDebugLevel = DEBUG_LEVEL_OFF;

    public static void setDebugLevel(int debugLevel) {
    	currentDebugLevel = debugLevel;
    }

    public static void MARK() {
        if (currentDebugLevel >= DEBUG_LEVEL_NORMAL) {
            int markedStackTraceElementIndex = 3;
            Log.d(MNExtWrapperLogTag,MNExtWrapperLogPrefix + Thread.currentThread().getStackTrace()[markedStackTraceElementIndex].toString());
        }
    }

    public static void DLog(String message) {
    	DLog(message,DEBUG_LEVEL_NORMAL);
    }

    public static void DLog(String message,int debugLevel) {
    	if (currentDebugLevel >= debugLevel) {
            Log.d(MNExtWrapperLogTag,MNExtWrapperLogPrefix + message);
        }
    }

    public static void ELog(String message) {
        Log.e(MNExtWrapperLogTag,MNExtWrapperLogPrefix + message);
    }
}
