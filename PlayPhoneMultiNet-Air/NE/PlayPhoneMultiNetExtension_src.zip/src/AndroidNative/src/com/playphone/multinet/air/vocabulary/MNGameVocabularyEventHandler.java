package com.playphone.multinet.air.vocabulary;

import com.adobe.fre.FREContext;
import com.playphone.multinet.core.MNGameVocabulary.IEventHandler;
import java.util.Map;
import java.util.Hashtable;
import com.playphone.multinet.air.PlayPhoneMultiNetExt;


public class MNGameVocabularyEventHandler implements IEventHandler
{
    private FREContext context;

    public MNGameVocabularyEventHandler(FREContext context)
    {
        this.context = context;
    }

    public void mnGameVocabularyDownloadFinished (int downloadStatus )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("downloadStatus",downloadStatus);

        context.dispatchStatusEventAsync("mnGameVocabularyDownloadFinished", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnGameVocabularyStatusUpdated (int updateStatus )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("updateStatus",updateStatus);

        context.dispatchStatusEventAsync("mnGameVocabularyStatusUpdated", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void mnGameVocabularyDownloadStarted ( )
    {
        context.dispatchStatusEventAsync("mnGameVocabularyDownloadStarted", "");
    }


}

