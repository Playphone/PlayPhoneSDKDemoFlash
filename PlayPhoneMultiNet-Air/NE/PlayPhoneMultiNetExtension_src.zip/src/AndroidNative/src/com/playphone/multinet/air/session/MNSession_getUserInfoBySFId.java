package com.playphone.multinet.air.session;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.MNUserInfo;

public class MNSession_getUserInfoBySFId implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            MNUserInfo user = MNDirect.getSession().getUserInfoBySFId(freObjects[0].getAsInt());
            ret = FREObject.newObject("com.playphone.multinet.MNUserInfo",
                                      new FREObject[]
                                      {
                                              FREObject.newObject( user.userId ),
                                              FREObject.newObject( user.userSFId ),
                                              FREObject.newObject( user.userName ),
                                              FREObject.newObject( user.getAvatarUrl() )
                                      });
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
