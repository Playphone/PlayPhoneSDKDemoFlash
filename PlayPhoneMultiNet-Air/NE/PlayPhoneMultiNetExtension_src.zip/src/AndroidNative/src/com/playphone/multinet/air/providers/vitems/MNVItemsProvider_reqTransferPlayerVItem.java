package com.playphone.multinet.air.providers.vitems;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;

public class MNVItemsProvider_reqTransferPlayerVItem implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            MNDirect.getVItemsProvider().reqTransferPlayerVItem(freObjects[0].getAsInt(),
                                                                (long)freObjects[1].getAsDouble(),
                                                                (long)freObjects[2].getAsDouble(),
                                                                (long)freObjects[3].getAsDouble());
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
