package com.playphone.multinet.air.providers.wsprovider.handler;

import com.adobe.fre.FREContext;
import com.playphone.multinet.core.ws.data.MNWSLeaderboardListItem;
import com.playphone.multinet.core.ws.data.MNWSRoomUserInfoItem;
import com.playphone.multinet.providers.MNWSInfoRequestCurrGameRoomUserList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MNWSCurrentGameRoomUserListEventHandler extends MNWSEventHandler implements
        MNWSInfoRequestCurrGameRoomUserList.IEventHandler
{
    public MNWSCurrentGameRoomUserListEventHandler(int requestId, FREContext context)
    {
        super(requestId, context);
    }

    @Override
    public void onCompleted(MNWSInfoRequestCurrGameRoomUserList.RequestResult result)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("request_id", requestId);
            json.put("had_error", result.hadError());

            if (!result.hadError())
            {
                JSONArray arr = new JSONArray();
                for (MNWSRoomUserInfoItem item : result.getDataEntry())
                {
                    JSONObject arrItem = new JSONObject();

                    arrItem.put("room_sfid", item.getRoomSFId());
                    arrItem.put("user_id", item.getUserId());
                    arrItem.put("user_nick_name", item.getUserNickName());
                    arrItem.put("user_avatar_exists", item.getUserAvatarExists());
                    arrItem.put("user_avatar_url", item.getUserAvatarUrl());
                    arrItem.put("user_online_now", item.getUserOnlineNow());

                    arr.put(arrItem);
                }
                json.put("data", arr);
            }
            else
            {
                json.put("error_message", result.getErrorMessage());
            }

            context.dispatchStatusEventAsync("onWSRequestReceived", json.toString());
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
    }
}
