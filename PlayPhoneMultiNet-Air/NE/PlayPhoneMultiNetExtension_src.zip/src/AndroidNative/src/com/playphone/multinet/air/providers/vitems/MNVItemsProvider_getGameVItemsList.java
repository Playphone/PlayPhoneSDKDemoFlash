package com.playphone.multinet.air.providers.vitems;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.providers.MNVItemsProvider;

public class MNVItemsProvider_getGameVItemsList implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREArray ret = null;
        try
        {
            MNVItemsProvider.GameVItemInfo[] items = MNDirect.getVItemsProvider().getGameVItemsList();
            ret = FREArray.newArray(items.length);
            for (int i = 0; i < items.length; i++)
            {
                ret.setObjectAt(i, FREObject.newObject("com.playphone.multinet.providers.GameVItemInfo",
                                                       new FREObject[]
                                                       {
                                                               FREObject.newObject(items[i].id),
                                                               FREObject.newObject(items[i].name),
                                                               FREObject.newObject(items[i].model),
                                                               FREObject.newObject(items[i].description),
                                                               FREObject.newObject(items[i].params)
                                                       })
                               );
            }

        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
