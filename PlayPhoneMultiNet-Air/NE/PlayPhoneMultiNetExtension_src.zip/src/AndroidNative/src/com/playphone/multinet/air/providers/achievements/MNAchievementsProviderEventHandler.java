package com.playphone.multinet.air.providers.achievements;

import com.adobe.fre.FREContext;
import com.playphone.multinet.providers.MNAchievementsProvider.IEventHandler;
import java.util.Map;
import java.util.Hashtable;
import com.playphone.multinet.air.PlayPhoneMultiNetExt;


public class MNAchievementsProviderEventHandler implements IEventHandler
{
    private FREContext context;

    public MNAchievementsProviderEventHandler(FREContext context)
    {
        this.context = context;
    }

    public void onPlayerAchievementUnlocked (int achievementId )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("achievementId",achievementId);

        context.dispatchStatusEventAsync("onPlayerAchievementUnlocked", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void onGameAchievementListUpdated ( )
    {
        context.dispatchStatusEventAsync("onGameAchievementListUpdated", "");
    }


}

