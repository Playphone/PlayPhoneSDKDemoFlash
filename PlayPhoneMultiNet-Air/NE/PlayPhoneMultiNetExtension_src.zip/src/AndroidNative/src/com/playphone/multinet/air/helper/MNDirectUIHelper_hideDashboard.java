package com.playphone.multinet.air.helper;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;
import com.playphone.multinet.MNDirectUIHelper;

public class MNDirectUIHelper_hideDashboard implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        MNDirectUIHelper.hideDashboard(  );
        return ret;
    }
}
