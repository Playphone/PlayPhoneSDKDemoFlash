package com.playphone.multinet.extwrapper;

import java.lang.reflect.Method;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.playphone.multinet.MNDirect;
import com.playphone.multinet.extwrapper.serializer.MNSerializer;
import com.playphone.multinet.providers.MNWSInfoRequest;
import com.playphone.multinet.providers.MNWSInfoRequestAnyGame;
import com.playphone.multinet.providers.MNWSInfoRequestAnyUser;
import com.playphone.multinet.providers.MNWSInfoRequestAnyUserGameCookies;
import com.playphone.multinet.providers.MNWSInfoRequestCurrGameRoomList;
import com.playphone.multinet.providers.MNWSInfoRequestCurrGameRoomUserList;
import com.playphone.multinet.providers.MNWSInfoRequestCurrUserBuddyList;
import com.playphone.multinet.providers.MNWSInfoRequestCurrUserSubscriptionStatus;
import com.playphone.multinet.providers.MNWSInfoRequestCurrentUserInfo;
import com.playphone.multinet.providers.MNWSInfoRequestLeaderboard;
import com.playphone.multinet.providers.MNWSInfoRequestSessionSignedClientToken;
import com.playphone.multinet.providers.MNWSInfoRequestSystemGameNetStats;
import com.playphone.multinet.providers.MNWSLoader;

public class MNWSProviderExtWrapper {

    public MNWSProviderExtWrapper(MNSerializer serializer,IMNExtWrapperEventDispatcher eventDispatcher) {
        this.eventDispatcher = eventDispatcher;
        this.serializer = serializer;
    }

    protected static final String      requestIdKey     = "Id";
    protected static final String      requestNameKey   = "Name";
    protected static final String      requestParamsKey = "Parameters";

    public HashMap<Integer,MNWSLoader> loaderMap        = new HashMap<Integer,MNWSLoader>();

    protected MNWSInfoRequestAnyGame prepareMNWSInfoRequestAnyGame(int gameId,final int requestId,final int loaderId) {
        MNWSInfoRequestAnyGame request = new MNWSInfoRequestAnyGame
            (gameId,//deserialize if needed
            new MNWSInfoRequestAnyGame.IEventHandler() {
                @Override
                public void onCompleted(MNWSInfoRequestAnyGame.RequestResult requestResult) {
                    synchronized (loaderMap) {
                        loaderMap.remove(loaderId);
                    }

                    Object[] eventParams = new Object[] { requestId,requestResult };
                    String[] eventParamsNames = new String[] { serializer.formatKey("id"),serializer.formatKey("requestResult") };
                    eventDispatcher.dispatchEvent("MNWSInfoRequestEventHandler",eventParams,eventParamsNames);
                }
            });

        return request;
    }

    protected MNWSInfoRequestAnyGame MNWSInfoRequestAnyGame(JSONObject paramsJsonObject,int requestId,int loaderId) throws JSONException {
        return prepareMNWSInfoRequestAnyGame(paramsJsonObject.getInt(serializer.formatKey("gameId")),requestId,loaderId);
    }

    protected MNWSInfoRequestAnyUser prepareMNWSInfoRequestAnyUser(long userId,final int requestId,final int loaderId) {
        MNWSInfoRequestAnyUser request = new MNWSInfoRequestAnyUser
            (userId,//deserialize if needed
            new MNWSInfoRequestAnyUser.IEventHandler() {
                @Override
                public void onCompleted(MNWSInfoRequestAnyUser.RequestResult requestResult) {
                    synchronized (loaderMap) {
                        loaderMap.remove(loaderId);
                    }

                    Object[] eventParams = new Object[] { requestId,requestResult };
                    String[] eventParamsNames = new String[] { serializer.formatKey("id"),serializer.formatKey("requestResult") };
                    eventDispatcher.dispatchEvent("MNWSInfoRequestEventHandler",eventParams,eventParamsNames);
                }
            });

        return request;
    }

    protected MNWSInfoRequestAnyUser MNWSInfoRequestAnyUser(JSONObject paramsJsonObject,int requestId,int loaderId) throws JSONException {
        return prepareMNWSInfoRequestAnyUser(paramsJsonObject.getLong(serializer.formatKey("userId")),requestId,loaderId);
    }

    protected MNWSInfoRequestAnyUserGameCookies prepareMNWSInfoRequestAnyUserGameCookies(JSONArray userIdListJsonArray,JSONArray cookieKeyListJsonArray,final int requestId,final int loaderId) {
        MNWSInfoRequestAnyUserGameCookies request = new MNWSInfoRequestAnyUserGameCookies
            (serializer.deserialize(userIdListJsonArray.toString(),long[].class),
             serializer.deserialize(cookieKeyListJsonArray.toString(),int[].class),
             new MNWSInfoRequestAnyUserGameCookies.IEventHandler() {
                 @Override
                 public void onCompleted(MNWSInfoRequestAnyUserGameCookies.RequestResult requestResult) {
                     synchronized (loaderMap) {
                         loaderMap.remove(loaderId);
                     }

                     Object[] eventParams = new Object[] { requestId,requestResult };
                     String[] eventParamsNames = new String[] { serializer.formatKey("id"),serializer.formatKey("requestResult") };
                     eventDispatcher.dispatchEvent("MNWSInfoRequestEventHandler",eventParams,eventParamsNames);
                 }
             });

        return request;
    }

    protected MNWSInfoRequestAnyUserGameCookies MNWSInfoRequestAnyUserGameCookies(JSONObject paramsJsonObject,int requestId,int loaderId) throws JSONException {
        return prepareMNWSInfoRequestAnyUserGameCookies(paramsJsonObject.getJSONArray(serializer.formatKey("userIdList")),
                                                        paramsJsonObject.getJSONArray(serializer.formatKey("cookieKeyList")),
                                                        requestId,
                                                        loaderId);
    }

    protected MNWSInfoRequestCurrentUserInfo prepareMNWSInfoRequestCurrentUserInfo(final int requestId,final int loaderId) {
        MNWSInfoRequestCurrentUserInfo request = new MNWSInfoRequestCurrentUserInfo
            (new MNWSInfoRequestCurrentUserInfo.IEventHandler() {
                @Override
                public void onCompleted(MNWSInfoRequestCurrentUserInfo.RequestResult requestResult) {
                    synchronized (loaderMap) {
                        loaderMap.remove(loaderId);
                    }

                    Object[] eventParams = new Object[] { requestId,requestResult };
                    String[] eventParamsNames = new String[] { serializer.formatKey("id"),serializer.formatKey("requestResult") };
                    eventDispatcher.dispatchEvent("MNWSInfoRequestEventHandler",eventParams,eventParamsNames);
                }
            });

        return request;
    }

    protected MNWSInfoRequestCurrentUserInfo MNWSInfoRequestCurrentUserInfo(JSONObject paramsJsonObject,int requestId,int loaderId) throws JSONException {
        return prepareMNWSInfoRequestCurrentUserInfo(requestId,loaderId);
    }

    protected MNWSInfoRequestCurrGameRoomList prepareMNWSInfoRequestCurrGameRoomList(final int requestId,final int loaderId) {
        MNWSInfoRequestCurrGameRoomList request = new MNWSInfoRequestCurrGameRoomList
            (new MNWSInfoRequestCurrGameRoomList.IEventHandler() {
                @Override
                public void onCompleted(MNWSInfoRequestCurrGameRoomList.RequestResult requestResult) {
                    synchronized (loaderMap) {
                        loaderMap.remove(loaderId);
                    }

                    Object[] eventParams = new Object[] { requestId,requestResult };
                    String[] eventParamsNames = new String[] { serializer.formatKey("id"),serializer.formatKey("requestResult") };
                    eventDispatcher.dispatchEvent("MNWSInfoRequestEventHandler",eventParams,eventParamsNames);
                }
            });

        return request;
    }

    protected MNWSInfoRequestCurrGameRoomList MNWSInfoRequestCurrGameRoomList(JSONObject paramsJsonObject,int requestId,int loaderId) throws JSONException {
        return prepareMNWSInfoRequestCurrGameRoomList(requestId,loaderId);
    }

    protected MNWSInfoRequestCurrGameRoomUserList prepareMNWSInfoRequestCurrGameRoomUserList(int roomSFId,final int requestId,final int loaderId) {
        MNWSInfoRequestCurrGameRoomUserList request = new MNWSInfoRequestCurrGameRoomUserList
            (roomSFId,
             new MNWSInfoRequestCurrGameRoomUserList.IEventHandler() {
                 @Override
                 public void onCompleted(MNWSInfoRequestCurrGameRoomUserList.RequestResult requestResult) {
                     synchronized (loaderMap) {
                         loaderMap.remove(loaderId);
                     }

                     Object[] eventParams = new Object[] { requestId,requestResult };
                     String[] eventParamsNames = new String[] { serializer.formatKey("id"),serializer.formatKey("requestResult") };
                     eventDispatcher.dispatchEvent("MNWSInfoRequestEventHandler",eventParams,eventParamsNames);
                 }
             });

        return request;
    }

    protected MNWSInfoRequestCurrGameRoomUserList MNWSInfoRequestCurrGameRoomUserList(JSONObject paramsJsonObject,int requestId,int loaderId) throws JSONException {
        return prepareMNWSInfoRequestCurrGameRoomUserList(paramsJsonObject.getInt(serializer.formatKey("roomSFId")),requestId,loaderId);
    }

    protected MNWSInfoRequestCurrUserBuddyList prepareMNWSInfoRequestCurrUserBuddyList(final int requestId,final int loaderId) {
        MNWSInfoRequestCurrUserBuddyList request = new MNWSInfoRequestCurrUserBuddyList
            (new MNWSInfoRequestCurrUserBuddyList.IEventHandler() {
                @Override
                public void onCompleted(MNWSInfoRequestCurrUserBuddyList.RequestResult requestResult) {
                    synchronized (loaderMap) {
                        loaderMap.remove(loaderId);
                    }

                    Object[] eventParams = new Object[] { requestId,requestResult };
                    String[] eventParamsNames = new String[] { serializer.formatKey("id"),serializer.formatKey("requestResult") };
                    eventDispatcher.dispatchEvent("MNWSInfoRequestEventHandler",eventParams,eventParamsNames);
                }
            });

        return request;
    }

    protected MNWSInfoRequestCurrUserBuddyList MNWSInfoRequestCurrUserBuddyList(JSONObject paramsJsonObject,int requestId,int loaderId) throws JSONException {
        return prepareMNWSInfoRequestCurrUserBuddyList(requestId,loaderId);
    }

    protected MNWSInfoRequestCurrUserSubscriptionStatus prepareMNWSInfoRequestCurrUserSubscriptionStatus(final int requestId,final int loaderId) {
        MNWSInfoRequestCurrUserSubscriptionStatus request = new MNWSInfoRequestCurrUserSubscriptionStatus
            (new MNWSInfoRequestCurrUserSubscriptionStatus.IEventHandler() {
                @Override
                public void onCompleted(MNWSInfoRequestCurrUserSubscriptionStatus.RequestResult requestResult) {
                    synchronized (loaderMap) {
                        loaderMap.remove(loaderId);
                    }

                    Object[] eventParams = new Object[] { requestId,requestResult };
                    String[] eventParamsNames = new String[] { serializer.formatKey("id"),serializer.formatKey("requestResult") };
                    eventDispatcher.dispatchEvent("MNWSInfoRequestEventHandler",eventParams,eventParamsNames);
                }
            });

        return request;
    }

    protected MNWSInfoRequestCurrUserSubscriptionStatus MNWSInfoRequestCurrUserSubscriptionStatus(JSONObject paramsJsonObject,int requestId,int loaderId) throws JSONException {
        return prepareMNWSInfoRequestCurrUserSubscriptionStatus(requestId,loaderId);
    }

    protected MNWSInfoRequestSessionSignedClientToken prepareMNWSInfoRequestSessionSignedClientToken(String payload,final int requestId,final int loaderId) {
        MNWSInfoRequestSessionSignedClientToken request = new MNWSInfoRequestSessionSignedClientToken
            (payload,
             new MNWSInfoRequestSessionSignedClientToken.IEventHandler() {
                 @Override
                 public void onCompleted(MNWSInfoRequestSessionSignedClientToken.RequestResult requestResult) {
                     synchronized (loaderMap) {
                         loaderMap.remove(loaderId);
                     }

                     Object[] eventParams = new Object[] { requestId,requestResult };
                     String[] eventParamsNames = new String[] { serializer.formatKey("id"),serializer.formatKey("requestResult") };
                     eventDispatcher.dispatchEvent("MNWSInfoRequestEventHandler",eventParams,eventParamsNames);
                 }
             });

        return request;
    }

    protected MNWSInfoRequestSessionSignedClientToken MNWSInfoRequestSessionSignedClientToken(JSONObject paramsJsonObject,int requestId,int loaderId) throws JSONException {
        return prepareMNWSInfoRequestSessionSignedClientToken(paramsJsonObject.getString(serializer.formatKey("payload")),requestId,loaderId);
    }

    protected MNWSInfoRequestSystemGameNetStats prepareMNWSInfoRequestSystemGameNetStats(final int requestId,final int loaderId) {
        MNWSInfoRequestSystemGameNetStats request = new MNWSInfoRequestSystemGameNetStats
            (new MNWSInfoRequestSystemGameNetStats.IEventHandler() {
                @Override
                public void onCompleted(MNWSInfoRequestSystemGameNetStats.RequestResult requestResult) {
                    synchronized (loaderMap) {
                        loaderMap.remove(loaderId);
                    }

                    Object[] eventParams = new Object[] { requestId,requestResult };
                    String[] eventParamsNames = new String[] { serializer.formatKey("id"),serializer.formatKey("requestResult") };
                    eventDispatcher.dispatchEvent("MNWSInfoRequestEventHandler",eventParams,eventParamsNames);
                }
            });

        return request;
    }

    protected MNWSInfoRequestSystemGameNetStats MNWSInfoRequestSystemGameNetStats(JSONObject paramsJsonObject,int requestId,int loaderId) throws JSONException {
        return prepareMNWSInfoRequestSystemGameNetStats(requestId,loaderId);
    }

    protected MNWSInfoRequestLeaderboard prepareMNWSInfoRequestLeaderboard(JSONObject leaderboardMode,final int requestId,final int loaderId) {
        MNWSInfoRequestLeaderboard request = new MNWSInfoRequestLeaderboard
            (serializer.deserialize(leaderboardMode.toString(),MNWSInfoRequestLeaderboard.LeaderboardMode.class),
             new MNWSInfoRequestLeaderboard.IEventHandler() {
                 @Override
                 public void onCompleted(MNWSInfoRequestLeaderboard.RequestResult requestResult) {
                     synchronized (loaderMap) {
                         loaderMap.remove(loaderId);
                     }

                     Object[] eventParams = new Object[] { requestId,requestResult };
                     String[] eventParamsNames = new String[] { serializer.formatKey("id"),serializer.formatKey("requestResult") };
                     eventDispatcher.dispatchEvent("MNWSInfoRequestEventHandler",eventParams,eventParamsNames);
                 }
             });

        return request;
    }

    protected MNWSInfoRequestLeaderboard MNWSInfoRequestLeaderboard(JSONObject paramsJsonObject,int requestId,int loaderId) throws JSONException {
        return prepareMNWSInfoRequestLeaderboard(paramsJsonObject.getJSONObject(serializer.formatKey("LeaderboardMode")),requestId,loaderId);
    }

    protected MNWSInfoRequest prepareInfoRequest(JSONObject requestJsonObject,int loaderId) throws Exception {
        MNWSInfoRequest request = null;

        String requestName = requestJsonObject.getString(serializer.formatKey(requestNameKey));

        MNExtWrapper.DLog("prepareInfoRequest.getMethod(" + requestName + ")");

        Method method = MNWSProviderExtWrapper.class.getDeclaredMethod(requestName,JSONObject.class,Integer.TYPE,Integer.TYPE);
        request = (MNWSInfoRequest)method.invoke(this,
                                                 requestJsonObject.getJSONObject(serializer.formatKey(requestParamsKey)),
                                                 getRequestId(requestJsonObject),
                                                 loaderId);

        return request;
    }

    protected int getRequestId(JSONObject requestJsonObject) throws JSONException {
        return requestJsonObject.getInt(serializer.formatKey(requestIdKey));
    }

    public static final int LOADER_ID_INVALID = -1;

    public int send(String requestJsonArray) {
        MNExtWrapper.DLog("MNWSProviderExtWrapper.send(" + requestJsonArray + ")");

        int loaderId = getLoaderId();
        MNWSInfoRequest[] requests = null;
        JSONArray requestArray;

        try {
            requestArray = new JSONArray(requestJsonArray);

            if (requestArray != null) {
                requests = new MNWSInfoRequest[requestArray.length()];

                for (int requestIndex = 0; requestIndex < requestArray.length(); requestIndex++) {
                    JSONObject requestJsonObject = requestArray.getJSONObject(requestIndex);

                    requests[requestIndex] = prepareInfoRequest(requestJsonObject,loaderId);
                }

                synchronized (loaderMap) {
                    MNWSLoader loader = MNDirect.getWSProvider().send(requests);

                    loaderMap.put(loaderId,loader);
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            loaderId = LOADER_ID_INVALID;
        }

        /*
          [{"id":9001, "name":"MNWSInfoRequestAnyGame", "parameters":{"gameId":1}}]
          
          [
           {"id":9001, "name":"MNWSInfoRequestAnyGame", "parameters":{"gameId":1}},
           {"id":9002, "name":"MNWSInfoRequestAnyGame", "parameters":{"gameId":2}},
           {"id":9003, "name":"MNWSInfoRequestAnyGame", "parameters":{"gameId":3}}
          ]
        */

        return loaderId;
    }

    public void cancelRequest(final int requestId) {
        synchronized (loaderMap) {
            MNWSLoader loader = loaderMap.get(requestId);

            if (loader != null) {
                loaderMap.remove(requestId);
                loader.cancel();
            }
        }
    }

    private long                         loaderId        = System.currentTimeMillis();

    private IMNExtWrapperEventDispatcher eventDispatcher = null;
    private MNSerializer                 serializer      = null;

    protected synchronized int getLoaderId() {
        loaderId++;

        if (loaderId > Integer.MAX_VALUE) {
            loaderId = loaderId % Integer.MAX_VALUE;
        }

        return (int)loaderId;
    }

}
