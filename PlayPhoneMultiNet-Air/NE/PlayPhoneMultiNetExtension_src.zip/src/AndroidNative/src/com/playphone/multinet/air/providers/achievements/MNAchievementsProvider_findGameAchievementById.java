package com.playphone.multinet.air.providers.achievements;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.providers.MNAchievementsProvider;

public class MNAchievementsProvider_findGameAchievementById implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            MNAchievementsProvider.GameAchievementInfo achievement =
                    MNDirect.getAchievementsProvider().findGameAchievementById(freObjects[0].getAsInt());

            ret = FREObject.newObject("com.playphone.multinet.providers.GameAchievementInfo",
                                      new FREObject[]
                                      {
                                              FREObject.newObject(achievement.id),
                                              FREObject.newObject(achievement.name),
                                              FREObject.newObject(achievement.flags),
                                              FREObject.newObject(achievement.description),
                                              FREObject.newObject(achievement.params),
                                              FREObject.newObject(achievement.points)
                                      });
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
