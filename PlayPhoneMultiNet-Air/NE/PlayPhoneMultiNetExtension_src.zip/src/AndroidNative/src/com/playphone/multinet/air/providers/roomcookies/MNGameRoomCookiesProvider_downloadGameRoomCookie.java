package com.playphone.multinet.air.providers.roomcookies;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;

public class MNGameRoomCookiesProvider_downloadGameRoomCookie implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            MNDirect.getGameRoomCookiesProvider().downloadGameRoomCookie(freObjects[0].getAsInt(),
                                                                         freObjects[1].getAsInt());
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
