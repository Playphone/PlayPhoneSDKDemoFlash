package com.playphone.multinet.air.providers.vshop;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.providers.MNVShopProvider;

public class MNVShopProvider_findVShopCategoryById implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            MNVShopProvider.VShopCategoryInfo category = MNDirect.getVShopProvider().findVShopCategoryById(freObjects[0].getAsInt());
            ret = FREObject.newObject( "com.playphone.multinet.providers.VShopCategoryInfo",
                                       new FREObject[]
                                       {
                                               FREObject.newObject(category.id),
                                               FREObject.newObject(category.name),
                                               FREObject.newObject(category.sortPos)
                                       });
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
