package com.playphone.multinet.air.button;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirectButton;

public class MNDirectButton_hide implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        MNDirectButton.hide(  );
        return ret;
    }
}
