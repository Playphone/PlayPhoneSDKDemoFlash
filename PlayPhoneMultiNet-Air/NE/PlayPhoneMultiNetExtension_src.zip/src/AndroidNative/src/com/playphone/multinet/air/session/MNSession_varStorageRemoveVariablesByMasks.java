package com.playphone.multinet.air.session;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;

public class MNSession_varStorageRemoveVariablesByMasks implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            FREArray arg = (FREArray) freObjects[0];
            String[] masks = new String[(int) arg.getLength()];
            
            for (int i = 0; i < arg.getLength(); i++)
            {
                masks[i] = arg.getObjectAt(i).getAsString();
            }
            
            MNDirect.getSession().varStorageRemoveVariablesByMasks(masks);
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
