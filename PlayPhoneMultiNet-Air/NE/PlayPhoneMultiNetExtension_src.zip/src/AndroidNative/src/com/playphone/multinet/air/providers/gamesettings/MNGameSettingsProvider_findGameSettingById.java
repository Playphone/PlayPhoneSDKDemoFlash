package com.playphone.multinet.air.providers.gamesettings;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.providers.MNGameSettingsProvider;

public class MNGameSettingsProvider_findGameSettingById implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            MNGameSettingsProvider.GameSettingInfo info = MNDirect.getGameSettingsProvider().findGameSettingById(freObjects[0].getAsInt());
            ret = FREObject.newObject("com.playphone.multinet.providers.GameSettingInfo",
                                      new FREObject[]
                                      {
                                              FREObject.newObject(info.getId()),
                                              FREObject.newObject(info.getName()),
                                              FREObject.newObject(info.getParams()),
                                              FREObject.newObject(info.getSysParams()),
                                              FREObject.newObject(info.isMultiplayerEnabled()),
                                              FREObject.newObject(info.isLeaderboardVisible())
                                      });
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
