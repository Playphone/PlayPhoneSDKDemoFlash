package com.playphone.multinet.air;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREExtension;
import com.playphone.multinet.extwrapper.MNExtWrapper;
import com.playphone.multinet.extwrapper.air.MNExtWrapperEventDispatcherAir;
import com.playphone.multinet.extwrapper.serializer.MNJsonSerializer;
import com.playphone.multinet.extwrapper.serializer.MNSerializer;

public class PlayPhoneMultiNetExt implements FREExtension
{
    public static MNSerializer                   serializer      = new MNJsonSerializer(MNExtWrapper.WrapperPlatform.Air);
    public static MNExtWrapperEventDispatcherAir eventDispatcher = null;

    public void initialize()
    {
    }

    public FREContext createContext(String s)
    {
        FREContext freContext = new MNReferrerContext();
        eventDispatcher = new MNExtWrapperEventDispatcherAir(freContext);
        return freContext;
    }

    public void dispose()
    {
    }
}
