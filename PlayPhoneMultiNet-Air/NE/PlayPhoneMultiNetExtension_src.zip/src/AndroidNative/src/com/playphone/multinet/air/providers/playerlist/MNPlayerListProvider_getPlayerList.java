package com.playphone.multinet.air.providers.playerlist;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.MNUserInfo;

public class MNPlayerListProvider_getPlayerList implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREArray ret = null;
        try
        {
            MNUserInfo[] players = MNDirect.getPlayerListProvider().getPlayerList();
            ret = FREArray.newArray(players.length);
            for (int i = 0; i < players.length; i++)
            {
                ret.setObjectAt(i, FREObject.newObject("com.playphone.multinet.MNUserInfo",
                                                       new FREObject[]
                                                       {
                                                               FREObject.newObject( players[i].userId ),
                                                               FREObject.newObject( players[i].userSFId ),
                                                               FREObject.newObject( players[i].userName ),
                                                               FREObject.newObject( players[i].getAvatarUrl() )
                                                       }));
            }
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
