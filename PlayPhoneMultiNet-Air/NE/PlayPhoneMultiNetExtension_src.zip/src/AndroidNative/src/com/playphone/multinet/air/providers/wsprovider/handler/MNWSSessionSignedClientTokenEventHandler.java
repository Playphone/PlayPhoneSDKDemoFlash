package com.playphone.multinet.air.providers.wsprovider.handler;

import com.adobe.fre.FREContext;
import com.playphone.multinet.core.ws.data.MNWSCurrUserSubscriptionStatus;
import com.playphone.multinet.core.ws.data.MNWSSessionSignedClientToken;
import com.playphone.multinet.providers.MNWSInfoRequestSessionSignedClientToken;
import org.json.JSONException;
import org.json.JSONObject;

public class MNWSSessionSignedClientTokenEventHandler extends MNWSEventHandler implements
        MNWSInfoRequestSessionSignedClientToken.IEventHandler
{
    public MNWSSessionSignedClientTokenEventHandler(int requestId, FREContext context)
    {
        super(requestId, context);
    }

    @Override
    public void onCompleted(MNWSInfoRequestSessionSignedClientToken.RequestResult result)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("request_id", requestId);
            json.put("had_error", result.hadError());

            if (!result.hadError())
            {
                MNWSSessionSignedClientToken item = result.getDataEntry();
                JSONObject arrItem = new JSONObject();

                arrItem.put("client_token_body", item.getClientTokenBody());
                arrItem.put("client_token_sign", item.getClientTokenSign());

                json.put("data", arrItem);
            }
            else
            {
                json.put("error_message", result.getErrorMessage());
            }

            context.dispatchStatusEventAsync("onWSRequestReceived", json.toString());
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
    }
}
