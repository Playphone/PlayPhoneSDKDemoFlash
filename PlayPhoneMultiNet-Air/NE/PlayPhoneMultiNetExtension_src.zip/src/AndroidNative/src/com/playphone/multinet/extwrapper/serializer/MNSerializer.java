package com.playphone.multinet.extwrapper.serializer;

import java.util.Map;

import com.playphone.multinet.extwrapper.MNExtWrapper;
import com.playphone.multinet.extwrapper.MNExtWrapperTools;

public abstract class MNSerializer {
    public MNSerializer(MNExtWrapper.WrapperPlatform wrapperPlatform) {
        this.wrapperPlatform = wrapperPlatform;
    }
    
    public abstract String serialize(Object obj);
    public abstract String serializeMapToArray(Map<?,?> map);

    public abstract <T> T deserialize(String jsonString,Class<T> type);
    public abstract <K,V> Map<K,V> deserializeMapFromArray(String jsonString,Class<K> keyType,Class<V> valueType);

    public String formatKey(String key) {
        String result = null;

        if (wrapperPlatform == MNExtWrapper.WrapperPlatform.Unity) {
            result = MNExtWrapperTools.capitalize(key);
        }
        else if (wrapperPlatform == MNExtWrapper.WrapperPlatform.Air) {
            result = MNExtWrapperTools.decapitalize(key);
        }
        else {
            result = key;
        }

        return result;
    }

    protected MNExtWrapper.WrapperPlatform wrapperPlatform;
}
