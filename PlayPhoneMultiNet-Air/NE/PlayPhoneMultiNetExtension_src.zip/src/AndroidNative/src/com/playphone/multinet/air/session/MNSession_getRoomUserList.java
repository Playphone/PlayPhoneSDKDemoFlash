package com.playphone.multinet.air.session;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.MNUserInfo;

public class MNSession_getRoomUserList implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREArray ret = null;
        try
        {
            MNUserInfo[] users = MNDirect.getSession().getRoomUserList();
            ret = FREArray.newArray(users.length);
            for (int i = 0; i < users.length; i++)
            {
                ret.setObjectAt(i, FREObject.newObject("com.playphone.multinet.MNUserInfo",
                                                       new FREObject[]
                                                       {
                                                               FREObject.newObject( users[i].userId ),
                                                               FREObject.newObject( users[i].userSFId ),
                                                               FREObject.newObject( users[i].userName ),
                                                               FREObject.newObject( users[i].getAvatarUrl() )
                                                       }));
            }
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
