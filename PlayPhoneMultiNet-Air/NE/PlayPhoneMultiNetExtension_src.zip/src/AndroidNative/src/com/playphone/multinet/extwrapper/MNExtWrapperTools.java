package com.playphone.multinet.extwrapper;

public class MNExtWrapperTools {
    public static String capitalize(String word) {
        if (word.equalsIgnoreCase("playphone")) {
            word = "PlayPhone";
        }
        else if (word.equalsIgnoreCase("multinet")) {
            word = "MultiNet";
        }
        else if (word.startsWith("mn")) {
            word = word.replaceFirst("mn","MN");
        }
        else {
            word = word.substring(0,1).toUpperCase() + word.substring(1);
        }

        return word;
    }
    
    public static String decapitalize(String word) {
        if (word.equalsIgnoreCase("PlayPhone")) {
            word = "playphone";
        }
        else if (word.equalsIgnoreCase("MultiNet")) {
            word = "multinet";
        }
        else if (word.startsWith("MN")) {
            word = word.replaceFirst("MN","mn");
        }
        else {
            word = word.substring(0,1).toLowerCase() + word.substring(1);
        }

        return word;
    }
}
