package com.playphone.multinet.air.session;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.MNGameParams;

public class MNSession_startGameWithParams implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
            MNDirect.getSession().startGameWithParams(
                    new MNGameParams(freObjects[0].getProperty("gameSetId").getAsInt(),
                                     freObjects[0].getProperty("gameSetParams").getAsString(),
                                     freObjects[0].getProperty("scorePostLinkId").getAsString(),
                                     freObjects[0].getProperty("gameSeed").getAsInt(),
                                     freObjects[0].getProperty("playModel").getAsInt()));
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
