package com.playphone.multinet.air.helper;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirectUIHelper;

public class MNDirectUIHelper_setDashboardStyle implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        try
        {
        MNDirectUIHelper.setDashboardStyle( freObjects[0].getAsInt() );
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
