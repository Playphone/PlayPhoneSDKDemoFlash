package com.playphone.multinet.air.providers.scoreprogress;

import com.adobe.fre.FREContext;
import com.playphone.multinet.providers.MNScoreProgressProvider.IEventHandler;
import com.playphone.multinet.providers.MNScoreProgressProvider.ScoreItem;
import java.util.Map;
import java.util.Hashtable;
import com.playphone.multinet.air.PlayPhoneMultiNetExt;


public class MNScoreProgressProviderEventHandler implements IEventHandler
{
    private FREContext context;

    public MNScoreProgressProviderEventHandler(FREContext context)
    {
        this.context = context;
    }

    public void onScoresUpdated (ScoreItem[] scoreBoard )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("scoreBoard",scoreBoard);

        context.dispatchStatusEventAsync("onScoresUpdated", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }


}

