package com.playphone.multinet.air.providers.wsprovider.handler;

import com.adobe.fre.FREContext;
import com.playphone.multinet.air.providers.wsprovider.handler.MNWSEventHandler;
import com.playphone.multinet.core.ws.data.MNWSLeaderboardListItem;
import com.playphone.multinet.providers.MNWSInfoRequestLeaderboard;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MNWSInfoRequestLeaderboardEventHandler extends MNWSEventHandler
        implements MNWSInfoRequestLeaderboard.IEventHandler
{
    public MNWSInfoRequestLeaderboardEventHandler(int requestId, FREContext context)
    {
        super(requestId, context);
    }

    @Override
    public void onCompleted(MNWSInfoRequestLeaderboard.RequestResult result)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("request_id", requestId);
            json.put("had_error", result.hadError());

            if (!result.hadError())
            {
                JSONArray arr = new JSONArray();
                for (MNWSLeaderboardListItem item : result.getDataEntry())
                {
                    JSONObject arrItem = new JSONObject();
                    arrItem.put("user_id", item.getUserId());
                    arrItem.put("user_nick_name", item.getUserNickName());
                    arrItem.put("user_avatar_url", item.getUserAvatarUrl());
                    arrItem.put("user_is_friend", item.getUserIsFriend());
                    arrItem.put("user_online_now", item.getUserOnlineNow());
                    arrItem.put("user_is_ignored", item.getUserIsIgnored());
                    arrItem.put("out_hi_score", item.getOutHiScore());
                    arrItem.put("out_hi_datetime", item.getOutHiDateTime());
                    arrItem.put("out_user_place", item.getOutUserPlace());
                    arrItem.put("game_id", item.getGameId());
                    arrItem.put("gameset_id", item.getGameId());
                    arrItem.put("user_sfid", item.getUserSfid());
                    arrItem.put("user_achievemenets_list", item.getUserAchievementsList());
                    arrItem.put("out_hi_score_text", item.getOutHiScoreText());
                    arrItem.put("user_locale", item.getUserLocale());
                    arr.put(arrItem);
                }
                json.put("data", arr);
            }
            else
            {
                json.put("error_message", result.getErrorMessage());
            }

            context.dispatchStatusEventAsync("onWSRequestReceived", json.toString());
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
    }
}
