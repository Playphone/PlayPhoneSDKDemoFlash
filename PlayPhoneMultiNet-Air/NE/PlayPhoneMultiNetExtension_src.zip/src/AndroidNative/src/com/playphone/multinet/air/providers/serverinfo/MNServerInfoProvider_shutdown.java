package com.playphone.multinet.air.providers.serverinfo;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;
import com.playphone.multinet.MNDirect;

public class MNServerInfoProvider_shutdown implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREObject ret = null;
        MNDirect.getServerInfoProvider().shutdown();
        return ret;
    }
}
