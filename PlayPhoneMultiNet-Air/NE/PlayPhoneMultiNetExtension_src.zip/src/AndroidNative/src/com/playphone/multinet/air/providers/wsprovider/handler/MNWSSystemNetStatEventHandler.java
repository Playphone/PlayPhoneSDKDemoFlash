package com.playphone.multinet.air.providers.wsprovider.handler;

import com.adobe.fre.FREContext;
import com.playphone.multinet.core.ws.data.MNWSSystemGameNetStats;
import com.playphone.multinet.providers.MNWSInfoRequestSystemGameNetStats;
import org.json.JSONException;
import org.json.JSONObject;

public class MNWSSystemNetStatEventHandler extends MNWSEventHandler implements MNWSInfoRequestSystemGameNetStats.IEventHandler
{
    public MNWSSystemNetStatEventHandler(int requestId, FREContext context)
    {
        super(requestId, context);
    }

    @Override
    public void onCompleted(MNWSInfoRequestSystemGameNetStats.RequestResult result)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("request_id", requestId);
            json.put("had_error", result.hadError());

            if (!result.hadError())
            {
                MNWSSystemGameNetStats item = result.getDataEntry();
                JSONObject jsonItem = new JSONObject();
                jsonItem.put("serv_total_users", item.getServOnlineUsers());
                jsonItem.put("serv_total_games", item.getServTotalGames());
                jsonItem.put("serv_online_users", item.getServOnlineUsers());
                jsonItem.put("serv_online_rooms", item.getServOnlineRooms());
                jsonItem.put("serv_online_games", item.getServOnlineGames());
                jsonItem.put("game_online_users", item.getGameOnlineUsers());
                jsonItem.put("game_online_rooms", item.getServOnlineRooms());

                json.put("data", jsonItem);
            }
            else
            {
                json.put("error_message", result.getErrorMessage());
            }

            context.dispatchStatusEventAsync("onWSRequestReceived", json.toString());
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
    }
}
