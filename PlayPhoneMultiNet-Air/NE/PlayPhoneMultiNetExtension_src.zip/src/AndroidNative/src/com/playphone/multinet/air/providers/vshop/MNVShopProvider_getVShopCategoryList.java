package com.playphone.multinet.air.providers.vshop;

import com.adobe.fre.*;
import com.playphone.multinet.MNDirect;
import com.playphone.multinet.providers.MNVShopProvider;

public class MNVShopProvider_getVShopCategoryList implements FREFunction
{
    public FREObject call(FREContext freContext, FREObject[] freObjects)
    {
        FREArray ret = null;
        try
        {
            MNVShopProvider.VShopCategoryInfo[] categories = MNDirect.getVShopProvider().getVShopCategoryList();
            ret = FREArray.newArray(categories.length);
            for (int i = 0; i < categories.length; i++)
            {
                ret.setObjectAt(i, FREObject.newObject("com.playphone.multinet.providers.VShopCategoryInfo",
                                                       new FREObject[]
                                                       {
                                                               FREObject.newObject(categories[i].id),
                                                               FREObject.newObject(categories[i].name),
                                                               FREObject.newObject(categories[i].sortPos)
                                                       }));
            }
        }
        catch (FREWrongThreadException e)
        {
            e.printStackTrace();
        }
        catch (FREASErrorException e)
        {
            e.printStackTrace();
        }
        catch (FREInvalidObjectException e)
        {
            e.printStackTrace();
        }
        catch (FRENoSuchNameException e)
        {
            e.printStackTrace();
        }
        catch (FRETypeMismatchException e)
        {
            e.printStackTrace();
        }
        return ret;
    }
}
