package com.playphone.multinet.air.providers.vshop;

import com.adobe.fre.FREContext;
import com.playphone.multinet.providers.MNVShopProvider.IEventHandler;
import com.playphone.multinet.providers.MNVShopProvider.IEventHandler.CheckoutVShopPackSuccessInfo;
import java.util.Map;
import java.util.Hashtable;
import com.playphone.multinet.air.PlayPhoneMultiNetExt;
import com.playphone.multinet.providers.MNVShopProvider.IEventHandler.CheckoutVShopPackFailInfo;


public class MNVShopProviderEventHandler implements IEventHandler
{
    private FREContext context;

    public MNVShopProviderEventHandler(FREContext context)
    {
        this.context = context;
    }

    public void onVShopInfoUpdated ( )
    {
        context.dispatchStatusEventAsync("onVShopInfoUpdated", "");
    }

    public void showDashboard ( )
    {
        context.dispatchStatusEventAsync("showDashboard", "");
    }

    public void hideDashboard ( )
    {
        context.dispatchStatusEventAsync("hideDashboard", "");
    }

    public void onCheckoutVShopPackSuccess (CheckoutVShopPackSuccessInfo result )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("result",result);

        context.dispatchStatusEventAsync("onCheckoutVShopPackSuccess", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void onCheckoutVShopPackFail (CheckoutVShopPackFailInfo result )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("result",result);

        context.dispatchStatusEventAsync("onCheckoutVShopPackFail", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }

    public void onVShopReadyStatusChanged (boolean isVShopReady )
    {
        Map<String,Object> paramsMap = new Hashtable<String,Object>();

        paramsMap.put("isVShopReady",isVShopReady);

        context.dispatchStatusEventAsync("onVShopReadyStatusChanged", PlayPhoneMultiNetExt.serializer.serialize(paramsMap));
    }


}

