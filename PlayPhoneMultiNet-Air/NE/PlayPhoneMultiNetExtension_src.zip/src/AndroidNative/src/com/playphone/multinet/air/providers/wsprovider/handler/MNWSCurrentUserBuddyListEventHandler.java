package com.playphone.multinet.air.providers.wsprovider.handler;

import com.adobe.fre.FREContext;
import com.playphone.multinet.core.ws.data.MNWSBuddyListItem;
import com.playphone.multinet.core.ws.data.MNWSRoomUserInfoItem;
import com.playphone.multinet.providers.MNWSInfoRequestCurrUserBuddyList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MNWSCurrentUserBuddyListEventHandler extends MNWSEventHandler implements MNWSInfoRequestCurrUserBuddyList.IEventHandler
{
    public MNWSCurrentUserBuddyListEventHandler(int requestId, FREContext context)
    {
        super(requestId, context);
    }

    @Override
    public void onCompleted(MNWSInfoRequestCurrUserBuddyList.RequestResult result)
    {
        JSONObject json = new JSONObject();
        try
        {
            json.put("request_id", requestId);
            json.put("had_error", result.hadError());

            if (!result.hadError())
            {
                JSONArray arr = new JSONArray();
                for (MNWSBuddyListItem item : result.getDataEntry())
                {
                    JSONObject arrItem = new JSONObject();

                    arrItem.put("friend_sn_id", item.getFriendSnId());
                    arrItem.put("friend_sn_user_asnid_list", item.getFriendSnUserAsnId());
                    arrItem.put("friend_user_id", item.getFriendUserId());
                    arrItem.put("friend_user_nick_name", item.getFriendUserNickName());
                    arrItem.put("friend_sn_id_list", item.getFriendSnIdList());
                    arrItem.put("friend_in_game_id", item.getFriendInGameId());
                    arrItem.put("friend_in_game_name", item.getFriendInGameName());
                    arrItem.put("friend_in_game_icon_url", item.getFriendInGameIconUrl());
                    arrItem.put("friend_has_current_game", item.getFriendHasCurrentGame());
                    arrItem.put("friend_user_avatar_url", item.getFriendUserAvatarUrl());
                    arrItem.put("friend_user_online_now", item.getFriendUserOnlineNow());
                    arrItem.put("friend_flags", item.getFriendFlags());
                    arrItem.put("friend_is_ignored", item.getFriendIsIgnored());
                    arrItem.put("friend_user_sfid", item.getFriendUserSfid());

                    arr.put(arrItem);
                }
                json.put("data", arr);
            }
            else
            {
                json.put("error_message", result.getErrorMessage());
            }

            context.dispatchStatusEventAsync("onWSRequestReceived", json.toString());
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
    }
}
